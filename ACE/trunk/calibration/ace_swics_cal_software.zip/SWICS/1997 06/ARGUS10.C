/* *********************************************************************** *
 *                                                                         *
 *    ARGUS10.C - Software for running automated CASYMS scans for          *
 *                calibrating ACE/SWICS.                                   *
 *                                                                         *
 *             Compile:    qcl /c argus.c                                  *
 *             Link:       qlink /stack:32000 argus+cascom ;               *
 *                                                                         *
 *       pdb : 19-Nov-95                                                   *
 *             20-Nov-95                                                   *
 *       rka : 22-Nov-95                                                   *
 *       pdb : 01-Dec-95                                                   *
 *             03-Dec-95   Added Background Scan capability from "ARGUS4"  *
 *             29-Jun-96                                                   *
 *       sel : 15-Jun-97   changed fPHARead and fCommand to FW's latest    *
 *                         versions, added questions for alpha & z, fixed  *
 *                         bug reading DPPS housekeeping, fixed Vf ref     *
 *                         HK conversions                                  *
 *                                                                         *
 *          ( NOTE: 0 <= iDVS <= 127 or 231 <= iDVS <= 255 )               *
 *                                                                         *
 * *********************************************************************** */

#include <math.h>
#include <sys\timeb.h>
#include <stdio.h>
#include <string.h>
#include <graph.h>
#include <time.h>
#include <stdlib.h>

#define ESC ((char) 0x1B )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define BYTE unsigned char
#define getrandom( min, max ) ((rand() % (int)(((max)+1) - (min))) + (min))

int   iHead=140, iPHA=6, iRates=22, iHK=42, iCmds=100, iDVS=0 ;
WORD  near wTOF, near wID, near wEGY, near wHK, wLev=0,
		near wSecReq=1, near wCmd, near wSec, near wSim=0, wLastSec=0,
		near wFSR, near wDCR, near wTCR, near wMSS, near wPROT, near wALFA ;
BYTE  szTitle[70], szName[40]="", szID[3]="ACE",
		szBegTime[10], szDate[10], szType[10] ;

void near fPHARead() ;
void near fCommand() ;
void near fRates() ;
void near fTime() ;

FILE *fp ;

int main( int argc, char *argv[] ) {

	time_t   ltime, ltime2, deltatime ;
	DWORD	dwRecorded=0, dwFSRsum, dwDCRsum, dwTCRsum, dwMSSsum,
			dwPROTsum, dwALFAsum, oldltime=0, dwTarget=0 ;

	WORD	i, j, c, wEvents=0, wRates=0, wPHACtr=0, wRecord=1, wCASYMS=0,
			wTarget=0, wRecTime=0 ;

	int   iCtr=0 ;

	REAL  rHK, rOutMin, rOutMax, rOutInc, rMidMin, rMidMax, rMidInc, rInnMin,
			rInnMax, rInnInc, out, mid, inn, a, b, th, z, e, rDVS=0,
			rRelMin, rRelMax, rRelInc,
			rGndCvt[12]={ 28./200., 20./200., 10./200., 5./200., -5./200.,
								1., 1., 1., 2., 1./5.1, 1./1.89, 1./1.65 },
			rGndOff[12]={ 0., 0., 0., 0., 0.,
								0., 0., 0., 0., 0., 0., 38./1.65 },
			rVfCvt[10]={ 1., .6714, .6714, .048, 1.96, .039, 1.98, 39.05, 150., 6.25 },
			rVfOff[10]={ 0., -128., -128., -6.16, -250.31, -11.12, -253.06, -4943.7, 0., 0. } ;

	BYTE	szText[80]="", szCommand[80]="", szAlpha[20]="", szBeta[20]="",
			szTheta[20]="", szZeta[20]="", szEIon[20]="", szCASYMS[120]="",
			szCmd[2]="CD", szGI[2]="GI", szHK[2]="HK", szRR[2]="RR", szPH[2]="PH",
			szBuffer[50]="", szTime[10], g, 
			szComment[120]="CASYMS Information Recorded - ",
			szBlank[80]="                                                      ",

			*szGndHK[12] = { "+28V      :%5.1f (%2x)",
				"20V AC    :%5.1f (%2x)", "+10V      :%5.1f (%2x)",
				"+ 5V      :%5.1f (%2x)", "- 5V      :%5.1f (%2x)",
				"                       ",
				"T1        :%5.1f (%2x)", "T2        :%5.1f (%2x)",
				"+28I (Pri):%5.1f (%2x)", "+28I (Sec):%5.1f (%2x)",
				"+ 5I      :%5.1f (%2x)", "20I AC    :%5.1f (%2x)" },

			*szVfHK[10] = { "Sync  :%5d (%2x)", "T1    :%5.1f (%2x)",
				"T2    :%5.1f (%2x)", "+ 5V  :%5d (%2x)", "+ 5I  :%5d (%2x)",
				"- 5V  :%5d (%2x)", "- 5I  :%5d (%2x)", "MCPPS :%5d (%2x)",
				"PAPS  :%5d (%2x)", "DPPS  :%5d (%2x)" } ;

/* -------------------- Command Line Arguments ------------------------- */

	_clearscreen(_GCLEARSCREEN) ;
	if( argc < 2 ) {
		_settextcolor(15) ;
		_settextposition(5,10) ;
		_outtext( "Usage:   " ) ;
		_settextposition(7,10) ;
		_settextcolor(14) ;
		_outtext( "ARGUS8 <seconds> ['sim']" ) ;
		_settextposition(9,10) ;
		_settextcolor(11) ;
		_outtext( "where <seconds> is the record-time for each point, and" ) ;
		_settextposition(10,10) ;
		_outtext( "the optional 'sim' argument calls the random-number generator." ) ;
		_settextposition(14,10) ;
		_settextcolor(7) ;
		_outtext( "Please try again.\n\n\n" ) ;
		_settextcolor(15) ;
		_settextposition(25,1) ;
		exit(-1) ;
	}
	else if( argc >= 2 ) {
		wRecTime = atoi( argv[1] ) + 1 ;
		if( argc>2 && !strncmp( strlwr(argv[2]), "sim", 3 ) ) {
			wSim = 1 ;
			srand( (unsigned)time( NULL ) ) ;
		}
	}

	time( &ltime ) ;
	oldltime = ltime ;

/* *************************** QUESTIONS ****************************** */

/*	_strtime( szBegTime ) ; */
	_strdate( szDate ) ;
	_clearscreen(_GCLEARSCREEN) ;
	fflush(stdin) ;

	_settextcolor(15) ;
	_settextposition(1,1) ;
	_outtext( "B" ) ;
	_settextcolor(14) ;
	_outtext( "ackground, " ) ;
	_settextcolor(15) ;
	_outtext( "g" ) ;
	_settextcolor(14) ;
	_outtext( "eometrical, e" ) ;
	_settextcolor(15) ;
	_outtext( "f" ) ;
	_settextcolor(14) ;
	_outtext( "ficiency, " ) ;
	_settextcolor(15) ;
	_outtext( "e" ) ;
	_settextcolor(14) ;
	_outtext( "nergy scan or e" ) ;
	_settextcolor(15) ;
	_outtext( "x" ) ;
	_settextcolor(14) ;
	_outtext( "it? [" ) ;
	_settextcolor(15) ;
	_outtext( "b/g/f/e/x" ) ;
	_settextcolor(14) ;
	_outtext( "]: " ) ;
	g = getch() ;
	com1_ini() ;
	wCASYMS = 1 ;

	switch( tolower(g) ) {

// Background Scan... Get Theta, Beta, and DVS limits

		case 'b' :
			fflush(stdin) ;
			_settextposition(2,1) ;
			_outtext( " Outer loop = Theta. Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rOutMin, &rOutMax, &rOutInc ) ;
			_settextposition(3,1) ;
			_outtext( "Middle loop = Beta.  Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rMidMin, &rMidMax, &rMidInc ) ;
			_settextposition(4,1) ;
			_outtext( " Inner loop = DVS.   Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rInnMin, &rInnMax, &rInnInc ) ;
// added by SEL
			_settextposition(5,1) ;
			_outtext( " Enter turntable alpha angle : ") ;
			fflush(stdin) ;
			gets( szAlpha ) ;
			_settextposition(6,1) ;
			_outtext( " Enter turntable Z value : ") ;
			fflush(stdin) ;
			gets( szZeta ) ;
			_settextposition(7,1) ;
			_outtext( " Enter beam energy : ") ;
			fflush(stdin) ;
			gets( szEIon ) ;
			_clearscreen(_GCLEARSCREEN) ;
			_settextposition(4,1) ;
			sprintf( szText, "%-5.2f <= Theta <= %-5.2f by %-5.2f", rOutMin, rOutMax,rOutInc) ;
			_outtext( szText );
			_settextposition(5,1) ;
			sprintf ( szText, "%-5.2f <= Beta <= %-5.2f by %-5.2f", rMidMin, rMidMax, rMidInc) ;
			_outtext( szText );
			_settextposition(6,1) ;
			sprintf( szText, "%d <= DVS <= %d by %d",
					  (short)rInnMin, (short)rInnMax, (short)rInnInc) ;
			_outtext( szText );
			_settextposition(7,1) ;
			sprintf( szText, "a: %s, Z: %s, Beam E: %s", szAlpha, szZeta, szEIon ) ;
			_outtext( szText) ;
		break ;

// Geometry Scan... Get Theta, Beta, and Energy limits

		case 'g' :
			fflush(stdin) ;
			_settextposition(2,1) ;
			_outtext( " Outer loop = Theta. Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rOutMin, &rOutMax, &rOutInc ) ;
			_settextposition(3,1) ;
			_outtext( "Middle loop = Beta. Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rMidMin, &rMidMax, &rMidInc ) ;
			_settextposition(4,1) ;
			_outtext( " Inner loop = Energy. Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rInnMin, &rInnMax, &rInnInc ) ;
// added by SEL
			_settextposition(5,1) ;
			_outtext( " Enter turntable alpha angle : ") ;
			fflush(stdin) ;
			gets( szAlpha ) ;
			_settextposition(6,1) ;
			_outtext( " Enter turntable Z value : ") ;
			fflush(stdin) ;
			gets( szZeta ) ;
			_settextposition(7,1) ;
			_outtext( " Enter DPPS Level : ") ;
			scanf( "%d", &wLev ) ;
			_clearscreen(_GCLEARSCREEN) ;
			_settextposition(4,1) ;
			sprintf( szText, "%-5.2f <= Theta <= %-5.2f by %-5.2f", rOutMin, rOutMax,rOutInc) ;
			_outtext( szText );
			_settextposition(5,1) ;
			sprintf ( szText, "%-5.2f <= Beta <= %-5.2f by %-5.2f", rMidMin, rMidMax, rMidInc) ;
			_outtext( szText );
			_settextposition(6,1) ;
			sprintf( szText, "%-6.1f <= Beam Voltage <= %-6.1f by %-6.1f", rInnMin, rInnMax, rInnInc) ;
			_outtext( szText );
			_settextposition(7,1) ;
			sprintf( szText, "a: %s, Z: %s, DPPS Step %d", szAlpha, szZeta, wLev ) ;
			_outtext( szText) ;
		break ;

// Efficiency Scan... Get Theta, Energy, and Relative Energy limits

		case 'f' :
			fflush(stdin) ;
			_settextposition(2,1) ;
			_outtext( " Outer loop = Theta. Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rOutMin, &rOutMax, &rOutInc ) ;
			_settextposition(3,1) ;
			_outtext( "Middle loop = Nominal Energy. Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rMidMin, &rMidMax, &rMidInc ) ;
			_settextposition(4,1) ;
			_outtext( " Inner loop = Relative Energy. Enter min (0.9), max (1.1), inc (0.02): " ) ;
			scanf( "%f, %f, %f", &rRelMin, &rRelMax, &rRelInc ) ;
// added by SEL
			_settextposition(5,1) ;
			_outtext( " Enter turntable beta angle : ") ;
			fflush(stdin) ;
			gets( szBeta ) ;
			_settextposition(6,1) ;
			_outtext( " Enter turntable alpha angle : ") ;
			fflush(stdin) ;
			gets( szAlpha ) ;
			_settextposition(7,1) ;
			_outtext( " Enter turntable Z value : ") ;
			fflush(stdin) ;
			gets( szZeta ) ;
			_clearscreen(_GCLEARSCREEN) ;
			_settextposition(4,1) ;
			sprintf( szText, "%-5.2f <= Theta <= %-5.2f by %-5.2f", rOutMin, rOutMax,rOutInc) ;
			_outtext( szText );
			_settextposition(5,1) ;
			sprintf ( szText, "%-6.1f <= Nominal Beam Energy <= %-6.1f by %-6.1f",
					  rMidMin, rMidMax, rMidInc) ;
			_outtext( szText );
			_settextposition(6,1) ;
			sprintf( szText, "%-5.3f <= Relative Beam Energy <= %-5.3f by %-5.3f",
					 rRelMin, rRelMax, rRelInc) ;
			_outtext( szText );
			_settextposition(7,1) ;
			sprintf( szText, "a: %s, b: %s, Z: %s", szAlpha, szBeta, szZeta ) ;
			_outtext( szText) ;
		break ;

// Energy Scan... Get Energy, Beta, and Relative Energy limits

		case 'e' :
			fflush(stdin) ;
			_settextposition(2,1) ;
			_outtext( " Outer loop = Nominal Energy. Enter min, max, inc: " ) ;
			scanf( "%f, %f, %f", &rOutMin, &rOutMax, &rOutInc ) ;
//       _settextposition(3,1) ;
//       _outtext( "Middle loop = Beta. Enter min, max, inc: " ) ;
//       scanf( "%f, %f, %f", &rMidMin, &rMidMax, &rMidInc ) ;
//       _settextposition(4,1) ;
//       _outtext( " Inner loop = Relative Energy. Enter min(.9), max(1.1), inc(.01): " ) ;
//       scanf( "%f, %f, %f", &rRelMin, &rRelMax, &rRelInc ) ;
			rRelMin=1.0 ;
			rRelMax=1.0 ;
			rRelInc=1.0 ;
			_settextposition(5,1) ;
			_outtext( " Enter theta location (real): " ) ;
			fflush(stdin) ;
			gets( szTheta ) ;
			_settextposition(6,1) ;
			_outtext( " Enter beta location (real): " ) ;
			fflush(stdin) ;
			gets( szBeta ) ;
		break ;

// Exit...
		case 'x' :
			exit(-2) ;
		break ;

	} // (scan type)

// Prepare to record data ...

	wRecord = 1 ;
	dwRecorded = 0 ;
	_settextposition(25,1) ;
	fflush( stdin ) ;
	_outtext( "Enter file name: " ) ;
	gets( szName ) ;
	_settextposition(25,1) ;
	_outtext( szBlank ) ;
	fflush( stdin ) ;
	_settextposition(25,1) ;
	_outtext( "Enter run title: " ) ;
	gets( szTitle ) ;
	fp = fopen( szName, "w+b" ) ;
	fwrite( szID, 3, 1, fp ) ;
	fwrite( &iHead, 2, 1, fp ) ;
	fwrite( &iPHA, 2, 1, fp ) ;
	fwrite( &iRates, 2, 1, fp ) ;
	fwrite( &iHK, 2, 1, fp ) ;
	fwrite( &iCmds, 2, 1, fp ) ;
	fwrite( szName, 40, 1, fp ) ;
	fwrite( szTitle, 70, 1, fp ) ;
	fwrite( szDate, 10, 1, fp ) ;
	fwrite( szGI, 2, 1, fp ) ;
	_strtime( szTime ) ;
	sprintf( szCASYMS, "a:%s b:%s th:%s z:%s E:%s DVS:%d @:%s",
			 szAlpha, szBeta, szTheta, szZeta, szEIon, wLev, szTime ) ;
	fwrite( szCASYMS, 120, 1, fp ) ;
	com1_ini() ;

/* ***************************** ANSWERS ****************************** */

		_settextposition(25,1) ;

// -------------------------- OUTER LOOP ---------------------------

		for( out=rOutMin; out<=rOutMax; out+=rOutInc ) {
			gcvt( out, 5, szBuffer ) ;
			switch( tolower(g) ) {

// ........... Background Scan Outer Loop: Set theta

				case 'b' :
					move_TT_theta( szBuffer ) ;
					strncpy( szTheta, szBuffer, 20 ) ;
					fTime() ;
					wTarget = wSec + 30 ;
					if( wTarget > 59 ) wTarget -= 60 ;
					while( wSec!=wTarget ) {
						fTime() ;
					}
				break ;

// ........... Geometry Scan Outer Loop: Set theta

				case 'g' :
					move_TT_theta( szBuffer ) ;
					strncpy( szTheta, szBuffer, 20 ) ;
					fTime() ;
					wTarget = wSec + 30 ;
					if( wTarget > 59 ) wTarget -= 60 ;
					while( wSec!=wTarget ) {
						fTime() ;
					}
				break ;

// ........... Efficiency Scan Outer Loop: Set theta

				case 'f' :
					move_TT_theta( szBuffer ) ;
					strncpy( szTheta, szBuffer, 20 ) ;
					fTime() ;
					wTarget = wSec + 30 ;
					if( wTarget > 59 ) wTarget -= 60 ;
					while( wSec!=wTarget ) {
						fTime() ;
					}
				break ;

// ........... Energy Scan Outer Loop: Set DVS; Calculate Elow and Ehigh

				case 'e' :
					rInnMin = rRelMin*out ;
					rInnMax = rRelMax*out ;
					rInnInc = rRelInc*out ;
//             rDVS = log(out/445.88) / log(1.03618) ;
//             wLev = (WORD)rDVS ;
//             if( wLev>127 ) wLev+=103 ;
//             if( wLev<256 ) {
//                wCmd = 0x0900 + wLev ;
//                fCommand() ;
//             }
//             else printf( "\a" ) ;
			break ;

			}

// ------------------------- MIDDLE LOOP ---------------------------

			for( mid=rMidMin; mid<=rMidMax; mid+=rMidInc ) {
				gcvt( mid, 5, szBuffer ) ;
				switch( tolower(g) ) {

// ........... Background Scan Middle Loop: Set beta

				case 'b' :
					move_TT_beta( szBuffer ) ;
					strncpy( szBeta, szBuffer, 20 ) ;
					fTime() ;
					wTarget = wSec + 10 ;
					if( wTarget > 59 ) wTarget -= 60 ;
					while( wSec!=wTarget ) {
						fTime() ;
					}
				break ;

// ........... Geometry Scan Middle Loop: Set beta

				case 'g' :
					move_TT_beta( szBuffer ) ;
					strncpy( szBeta, szBuffer, 20 ) ;
					fTime() ;
					wTarget = wSec + 10 ;
					if( wTarget > 59 ) wTarget -= 60 ;
					while( wSec!=wTarget ) {
						fTime() ;
					}
				break ;

// ........... Efficiency Scan Middle Loop: Set DVS; Calculate Elow, Ehigh

				case 'f' :
					rDVS = log(mid/445.88) / log(1.03618) ;
					wLev = (WORD)rDVS ;
					rInnMin = rRelMin*mid ;
					rInnMax = rRelMax*mid ;
					rInnInc = rRelInc*mid ;
					if( wLev>127 ) wLev+=103 ;
					if( wLev<256 ) {
						wCmd = 0x0900 + wLev ;
						fCommand() ;
					}
					else printf( "\a" ) ;
				break ;

// ........... Energy Scan Middle Loop: Set beta

				case 'e' :
//             move_TT_beta( szBuffer ) ;
//             strncpy( szBeta, szBuffer, 20 ) ;
//             fTime() ;
//             wTarget = wSec + 59 ;
//             if( wTarget > 59 ) wTarget -= 60 ;
//             while( wSec!=wTarget ) {
//                fTime() ;
//             }
				break ;

				}

// ------------------------- INNER LOOP ---------------------------

				for( inn=rInnMin; inn<=rInnMax; inn+=rInnInc ) {
					gcvt( inn, 5, szBuffer ) ;

// .............. For Background Scans: Set DVS

					if(  tolower(g) == 'b' ) {
						wLev = (WORD)inn ;
						if( wLev>127 ) wLev+=102 ;
						if( wLev<256 ) {
							wCmd = 0x0900 + wLev ;
							fCommand() ;
							sprintf (szCommand, "dpps %d", wLev) ;
							if( fwrite( szCmd, 2, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( szCommand, 20, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( szCommand, 20, 1, fp ) != 1 ) exit(-2) ;
							sprintf (szCommand, "0X%04X", wCmd) ;
							if( fwrite( szCommand, 20, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( szCommand, 20, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( szCommand, 20, 1, fp ) != 1 ) exit(-2) ;
						}
					}

// .............. For Geo., Eff., and Energy Scans: Set Ion Energy

					else {
						set_ion_energy( szBuffer ) ;
						strncpy( szEIon, szBuffer, 20 ) ;
					}

// Read CASYMS info every 60 minutes...

					deltatime = 3600 ;
					time( &ltime ) ;
					if( ltime>=oldltime+deltatime ) {
						oldltime = ltime ;
						BS_origin() ;
						for( j=0; j<3; j++ ) {
							read_BS_CEM() ;
							fTime() ;
							wTarget = wSec + 59 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
						}
						for( j=0; j<3; j++ ) {
							read_BS_Fara() ;
							fTime() ;
							wTarget = wSec + 6 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
						}
						read_Chamb_pT() ;
						read_source() ;
						BS_wait() ;
						fTime() ;
						wTarget = wSec + 30 ;
						if( wTarget > 59 ) wTarget -= 60 ;
						while( wSec!=wTarget ) {
							fTime() ;
						}
						fTime() ;
						wTarget = wSec + 59 ;
						if( wTarget > 59 ) wTarget -= 60 ;
						while( wSec!=wTarget ) {
							fTime() ;
						}
						_strtime( szTime ) ;
						send_time( szTime ) ;
						if( wRecord ) {
							strcat( szComment, szTime ) ;
							fwrite( szGI, 2, 1, fp ) ;
							fwrite( szComment, 120, 1, fp ) ;
							sprintf( szComment, "%s", "CASYMS Information Recorded - ") ;
						}
						move_TT_theta( szTheta ) ;
						move_TT_beta( szBeta ) ;
						fTime() ;
						wTarget = wSec + 59 ;
						if( wTarget > 59 ) wTarget -= 60 ;
						while( wSec!=wTarget ) {
							fTime() ;
						}

					}  // (casyms info readout)

					sprintf( szCASYMS, "a:%s b:%s th:%s z:%s E:%s DVS:%d @:%s",
								szAlpha, szBeta, szTheta, szZeta, szEIon, wLev, szTime ) ;
					_settextposition(25,1) ;
					_outtext( szBlank ) ;
					_settextposition(25,1) ;
					_outtext( szCASYMS ) ;
					if( wRecord ) {
						fwrite( szGI, 2, 1, fp ) ;
						fwrite( szCASYMS, 120, 1, fp ) ;
					}

// Wait 10 seconds...

					fTime() ;
					wTarget = wSec + 10 ;
					if( wTarget > 59 ) wTarget -= 60 ;
					while( wSec!=wTarget ) {
						fTime() ;
					}

// Reset accumulators...

					wCmd = 0xf000 ;
					fCommand() ;

// Collect and record data for <wRecTime> seconds...

					time( &ltime2 ) ;
					dwTarget = ltime2 + (double)wRecTime ;
					iCtr = 0 ;
					dwFSRsum=dwDCRsum=dwTCRsum=dwMSSsum=dwPROTsum=dwALFAsum=0 ;

					while( ltime2<dwTarget ) {
						if( kbhit() )
							if( (c=getch()) == 'x' ) exit(-1) ;

						fTime() ;
						if( !(wSec%wSecReq) && (wSec != wLastSec) ) {
							wLastSec = wSec ;
// Housekeeping...
							_settextcolor(10) ;
							if( wRecord )
								fwrite( szHK, 2, 1, fp ) ;

							for( i=0; i<12; i++ ) {
								wCmd = i ;
								fCommand() ;
								rHK = (REAL)(wHK) * rGndCvt[i] + rGndOff[i] ;
								if( wRecord && (i!=5) )
									fwrite( &wHK, 2, 1, fp ) ;
								if( i!=5 ) {
									sprintf( szText, szGndHK[i], rHK, wHK ) ;
									if( i>5 ) _settextposition(i+10,10) ;
									else _settextposition(i+11,10) ;
									_outtext( szText ) ;
								}
							}
							for( i=0; i<8; i++ ) {
								wCmd = 512+i ;
								fCommand() ;
								rHK = (REAL)(wHK) * rVfCvt[i] + rVfOff[i] ;
								if( wRecord )
									fwrite( &wHK, 2, 1, fp ) ;
								if( i==1 || i==2 ) {
									if( wHK>235 )
										rHK = (REAL)wHK * 4.117 - 949.85 ;
								}
								if( i==1 || i==2 ) sprintf( szText, szVfHK[i], rHK, wHK ) ;
								else  sprintf( szText, szVfHK[i], (WORD)rHK, wHK ) ;
								_settextposition(i+11,45) ;
								_outtext( szText ) ;
							}
							wCmd = 12 ;
							fCommand() ;
							rHK = (REAL)(wHK) * rVfCvt[8] + rVfOff[8] ;
							if( wRecord )
								fwrite( &wHK, 2, 1, fp ) ;
							sprintf( szText, szVfHK[8], (WORD)rHK, wHK ) ;
							_settextposition(8+11,45) ;
							_outtext( szText ) ;

							wCmd = 14 ;
							fCommand() ;
							rHK = (REAL)(wHK) * rVfCvt[9] + rVfOff[9] ;
							if( wRecord )
								fwrite( &wHK, 2, 1, fp ) ;
							sprintf( szText, szVfHK[9], (WORD)rHK, wHK ) ;
							_settextposition(9+11,45) ;
							_outtext( szText ) ;
// Rates...
							fRates() ;
							if( wRecord && iCtr ) {
								_strtime( szTime ) ;
								fwrite( szRR, 2, 1, fp ) ;
								fwrite( &wFSR, 2, 1, fp ) ;
								fwrite( &wDCR, 2, 1, fp ) ;
								fwrite( &wTCR, 2, 1, fp ) ;
								fwrite( &wMSS, 2, 1, fp ) ;
								fwrite( &wPROT, 2, 1, fp ) ;
								fwrite( &wALFA, 2, 1, fp ) ;
								fwrite( szTime, 10, 1, fp ) ;
							}
							if( iCtr ) {
								dwFSRsum += (DWORD)wFSR ;
								dwDCRsum += (DWORD)wDCR ;
								dwTCRsum += (DWORD)wTCR ;
								dwMSSsum += (DWORD)wMSS ;
								dwPROTsum += (DWORD)wPROT ;
								dwALFAsum += (DWORD)wALFA ;
							}
							iCtr++ ;
							_settextposition(9,1) ;
							_settextcolor(11) ;
//                   sprintf( szText, "%10u %10u %10u %10u %10u %10u\n", wFSR,
//                         wDCR, wTCR, wMSS, wPROT, wALFA ) ;
//                   _outtext( szText ) ;
						}
// PHA...
						fPHARead() ;
						if( wID < 4 ) {   //(Valid PHA)
							wPHACtr++ ;
							if( wRecord ) {
								fwrite( szPH, 2, 1, fp ) ;
								fwrite( &wEGY, 2, 1, fp ) ;
								fwrite( &wTOF, 2, 1, fp ) ;
								fwrite( &wID, 2, 1, fp ) ;
								dwRecorded++ ;
							}
						}
						time( &ltime2 ) ;
						_settextposition(11,37) ;
						_settextcolor(15) ;
						sprintf( szText, "%4ld", (dwTarget-ltime2) ) ;
						_outtext( szText ) ;

					} // (recording for <wRecTime> seconds...)

					_settextposition(8,1) ;
					_settextcolor(15) ;
					_outtext("      FSR        DCR        TCR        MSS       PROT       ALFA" ) ;
					_settextcolor(11) ;
					 _settextposition(9,1) ;
					sprintf( szText, "%10ld %10ld %10ld %10ld %10ld %10ld\n", dwFSRsum,
							dwDCRsum, dwTCRsum, dwMSSsum, dwPROTsum, dwALFAsum ) ;
					_outtext( szText ) ;

				} // inner
			} // middle
		} // outer

		wCASYMS = 0 ;
		wRecord = 0 ;
		exit_GI() ;

} // main

/* ******************* ROUTINES *************************************
	******************************************************************

	fPHARead -  Routine to read PHA data from SWICS using Fred Wire's
					DPU Simulator card.

				-  wID = 0,1,2,3 if valid data;
						 = 0x223 if timeout (i.e. no valid data)

	fcw : 22 jul 93
	pdb : 30 sep 94   (changed addresses from 30n -> 22n)
	fcw : 19 oct 94   (added code for:
								1) ignore data if cnt ok not set
								2) start amp is now 10bits for non PM data
	fcw : 16 oct 95   changed to read SWICS pha data
								10 bits TOF, 8 bits energy, 2 bits ID

	fcw : 30 jan 96   New PHA data format

 * ***************************************************************** */

void near fPHARead() {

	if( wSim ) {
		wID = getrandom( 0,3 ) ;
		if( wID == 0 ) {
			wEGY = getrandom( 0,255 ) ;
			wTOF = getrandom( 0,1023 ) ;
		}
		else if( wID == 1 ) {
			wEGY = getrandom( 0,80 ) ;
			wTOF = getrandom( 0,300 ) ;
		}
		else if( wID == 2 ) {
			wEGY = getrandom( 80,160 ) ;
			wTOF = getrandom( 300,600 ) ;
		}
		else if( wID == 3 ) {
			wEGY = getrandom( 160, 255 ) ;
			wTOF = getrandom( 600,1023 ) ;
		}
	}
	else {
	_asm {
			mov   dx, 0x223   ;  wait for pha data
			mov   wID, dx     ;  set no data flag

			in    al, (dx)
			mov   bl, al      ;save for clock pulse count check
			and   al, 4       ;check pha available bit
			jz    rdphaex     ;bye bye; no data available

rdphaok: mov   dx, 0x228   ;  read wTOF
			in    ax, (dx)
			and   ax, 0x3ff
			mov   wTOF, ax

			mov   dx, 0x229   ;  read wEGY & ID
			in    ax, (dx)
			shr   ax, 1       ;  shift over 2 places
			shr   ax, 1
			sub   bh, bh
			mov   bl, al
			mov   wEGY, bx

			shr   ah, 1       ;  shift 2 lsbits over 2 places
			shr   ah, 1
			and   ah, 3
			mov   wID, ah
			mov   wID+1, 0

			mov   dx, 0x22d   ;  clr pha available bit
			in    al, (dx)

rdphaex: nop
	}
	}
}

/* ******************************************************************
	fCommand -  Routine to send commands to MTOF using Fred Wire's DPU
					Simulator card, and return 8 bits of hk data.

	fcw : 20 jul 93
			18 mar 96   (added code for dual range dpps reading)
	sel : 15 jun 97 changed HK from byte (bHK) to word (wHK)
 * **************************************************************** */

void near fCommand() {

	if( wSim ) {
	 wHK = (BYTE)getrandom( 0, 255 ) ;
	}
	else {

	_asm {
		mov   dx, 0x223   ;read status (wait for ready)
lp0:  in    al, (dx)
		and   al, 1
		jz    lp0

		mov   dx, 0x220   ;cmd/data addr
		mov   ax, wCmd    ;get cmd
		out   (dx), ax    ;send cmd/data

		mov   dx, 0x223   ;read status (wait for status to go busy)
lp1:  in    al, (dx)
		and   al, 1
		jnz   lp1

;     read status (wait for status to go not busy)
lp2:  in    al, (dx)
		and   al, 1
		jz    lp2

;  read data and store

		mov   ax, wCmd    ;check for read dpps
		cmp   ax, 14      ;code for read dpps
		jz do_dpps

;     do reg hk read
		mov   dx, 0x221   ;mid hk byte
		in    al, (dx)
		sub   ah,ah
		jmp   store_hk

do_dpps:
		mov   dx, 0x220   ;lo & mid hk byte
		in    ax, (dx)
		xchg  al,ah
		mov   bl, 1
		and   ah, 0x80
		jz    do_mul
		mov   bl, 8
do_mul:
		mul   bl
store_hk:
		mov   wHK, ax

	}
	}
}

/* ******************************************************************
	fRates - Routine to read rate accumulator data from MTOF using
				Fred Wire's DPU Simulator card.

	fcw : 20 jul 93
	pdb : 22 jul 93   took out delays
	fcw : 02-aug-93   added reads of ufsr, mult starts, & mult dcr's
	fcw : 18 oct 95   modified to read swics rates

 * **************************************************************** */

void near fRates() {

	if( wSim ) {
		wFSR = getrandom( 0,32767 ) ;
		wDCR = getrandom( 0,32767 ) ;
		wTCR = getrandom( 0,32767 ) ;
		wMSS = getrandom( 0,32767 ) ;
		wPROT = getrandom( 0,32767 ) ;
		wALFA = getrandom( 0,100 ) ;
	}
	else {

	_asm {
		mov   dx, 0x220   ;send acc read and store cmd
		mov   ax, 0xf007
		out   (dx), ax

;  now wait 10msec for acc's to be read from bubble;
;  a command takes 580usec, so do 18 cmds, then read acc's

		mov   cx, 18

lp0:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp0

lp_wait_10ms:
		mov   ax, 0x0000  ;read a hk parameter and ignore data
		mov   dx, 0x220
		out   (dx), ax

lp1:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp1

		loop  lp_wait_10ms

;  now read acc's

;  1'st fsr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x0209
		out   (dx), ax

lp9:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp9

		mov   dx, 0x220   ;read nsr
		in    ax, (dx)
		mov   wFSR, ax

;  2'nd dcr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020a
		out   (dx), ax

lpa:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpa

		mov   dx, 0x220   ;read dcr
		in    ax, (dx)
		mov   wDCR, ax

;  3'rd tcr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020b
		out   (dx), ax

lpb:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpb

		mov   dx, 0x220   ;read tcr
		in    ax, (dx)
		mov   wTCR, ax

;  4'th mss rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020c
		out   (dx), ax

lpc:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpc

		mov   dx, 0x220   ;read mss rate
		in    ax, (dx)
		mov   wMSS, ax

;  5'th proton rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020d
		out   (dx), ax

lpd:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpd

		mov   dx, 0x220   ;read proton rate
		in    ax, (dx)
		mov   wPROT, ax

;  & last alpha rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020e
		out   (dx), ax

lpe:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpe

		mov   dx, 0x220   ;read alpha rate
		in    ax, (dx)
		mov   wALFA, ax

	}
	}
}

/* ******************************************************************
	fTime -  Routine to read real-time clock in order to have rates
				that are in counts/second.

	fcw : 21 jul 93
 * **************************************************************** */

void near fTime() {
	_asm {
	lp:   mov   ah, 2
			int   0x1a     ; get real-time clock second
			jc    lp
			mov   al, dh   ; change from bcd
			sub   ah, ah
			mov   bl, 16
			div   bl
			mov   bh, ah
			sub   ah, ah
			mov   bl, 10
			mul   bl
			add   al, bh
			mov   wSec, ax
	 }
}

