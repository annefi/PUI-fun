/* *********************************************************************

   SisDots.C - A histogram display program for the SISYPHUS software.

	pdb :	08-Nov-95
			31-Mar-96

   ********************************************************************* */

#include <stdio.h>
#include <string.h>
#include <graph.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>

#define ESC ( (char)0x1b )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define DREAL double
#define BYTE unsigned char

SisDots() {

	unsigned char font1[20] = "t'tms rmn'h8w6b" ;
	unsigned char font2[20] = "t'tms rmn'h12w9b" ;
	unsigned char font3[20] = "t'tms rmn'h16w12b" ;

	extern WORD		wDisplay, wXlow, wXhigh, wXinc, wLog, wEGY, wTOF,
						wID, wTlow, wThigh, wDont, wParam, wIDReq, wDots ;
	extern DREAL	drMass, drMpQ ;
	extern BYTE		szName[20], szTitle[70], szBegTime[10], szDate[10],
						*szTrends[32], szType[10] ;

	enum COLOR { black, blue, green, cyan, red, magenta, brown, white,
		dark_gray, light_blue, light_green, light_cyan,
		light_red, light_magenta, yellow, bright_white } ;

	DREAL	drVariance=0., drVarNum=0., drSigma=0., drFWHM=0., dcts, a ;

	DWORD	dwYtop, dwYval, dwBin=0, dwCts=0, decades=0, dwSum, dwNum,
			dwYmax=0, dwYmaxN=0, dwYmaxAuto=0, dwTotal=0, dwPeak=0 ;

	WORD	i, j, k, c, g, gg, wXrange, wXgrid, wLineStyle, wMode, wMlow,
			wMhigh, wXval, ix, iy, iarg, col ;

	int	iXpos, iYpos, iXpos0, iYpos0 ;

	REAL	rYhigh, rXslope, rYslope, rMean=0. ;

	BYTE	szText[80]="", ylabels[10]="",
			ysize[10]="", xlabels[10]="", szXinc[10]="", szFudge[10]="",
			szOffset[10], szTlow[10], szThigh[10], szNum[10] ;

	if( !wDisplay ) {
		wDisplay = 1 ;

/* ------------ Enter video mode and draw a border -------------- */

		_setvideomode(_VRES16COLOR) ;
		_rectangle( _GBORDER, 74,139,626,441 ) ;

/* -------------------------------------------------------------
   Draw background grid lines in dark grey
   ------------------------------------------------------------- */

		wLineStyle = _getlinestyle() ;
		for( ix=125; ix<=575; ix=ix+55 ) {
			_moveto( ix, 136 ) ;
			_lineto( ix, 139 ) ;
			_setcolor( dark_gray ) ;
			_setlinestyle( 0xAAAA ) ;
			_lineto( ix, 441 ) ;
			_setlinestyle( 0xFFFF ) ;
			_setcolor( light_red ) ;
			_lineto( ix, 444 ) ;
		}
		for( iy=180; iy<=400; iy=iy+40 ) {
			_moveto( 71, iy ) ;
			_lineto( 74, iy ) ;
			_setcolor( dark_gray ) ;
			_setlinestyle( 0xAAAA ) ;
			_lineto( 626, iy ) ;
			_setlinestyle( 0xFFFF ) ;
			_setcolor( light_red ) ;
			_lineto( 629, iy ) ;
		}
		_setlinestyle( wLineStyle ) ;

		rXslope = 550./1100. ;
		rYslope = 1. ;

/* -------------------------------------------------------------
   register all available fonts
   ------------------------------------------------------------- */

		if(_registerfonts( "tmsrb.fon" ) == -1 )
			printf( "\aFONTS are not available" ) ;
		else {

/* -------------------------------------------------------------
   add tic mark labels
   ------------------------------------------------------------- */

			_setfont( font2 ) ;
			_setcolor( light_red ) ;
			for( g=0; g<=10; g++ ) {
				wXval = g*110 ;
				itoa( wXval, xlabels, 10 ) ;
				_moveto( (g*55)+76-(3*strlen( xlabels )), 445 ) ;
				_outgtext( xlabels ) ;
			}
			for( gg=0; gg<=10; gg++ ) {
				dwYval = 300 - (gg*30) ;
				ltoa( dwYval, ylabels, 10 ) ;
				_moveto( ( 70 - 5 * strlen( ylabels ) ), 135+(gg*30) ) ;
				_outgtext( ylabels ) ;
			}

/* -------------------------------------------------------------
   put current date in lower right corner
   ------------------------------------------------------------- */

			_setcolor( light_cyan );
			sprintf( szText, "%8s on %8s", szBegTime, szDate ) ;
			_moveto( 500, 462 );
			_outgtext( szText );

/* -------------------------------------------------------------
   put title along the top and add the X- and Y-axis labels
   ------------------------------------------------------------- */

			_setfont( font3 ) ;
			_setcolor( bright_white );
			_moveto( 75, 120 );
			_outgtext( szTitle ) ;

			_moveto( 250, 460 );
         if( !strncmp( strlwr(szType), "e", 1 ) ) _outgtext( "TOF Channel" ) ;
			else _outgtext( "M/Q Channel" ) ;
			_moveto( 10, 317 );
			if( !strncmp( strlwr(szType), "e", 1 ) ) _outgtext( "E Ch" );
			else _outgtext( "M Ch" ) ;

			_setcolor( light_cyan ) ;
			_moveto( 75, 460 );
			_outgtext( szName ) ;

			_unregisterfonts() ;
		}
	}

/* -------------------------------------------------------------
   Now draw dotplot...
   ------------------------------------------------------------- */

	if( !strncmp( strlwr(szType), "e", 1 ) ) {
		iXpos = ( (int)( (REAL)(wTOF) * rXslope ) + 75 ) ;
		iYpos = ( 440 - (int)( (REAL)wEGY * rYslope ) ) ;
	}
	else {
		iXpos = ( (int)( (drMpQ*100.) * rXslope ) + 75 ) ;
		iYpos = ( 440 - (int)( (drMass*10.) * rYslope ) ) ;
	}
	col = _getpixel( iXpos, iYpos ) ;
	if( col < 15 )	_setcolor( ++col ) ;
	_setpixel( iXpos, iYpos ) ;

}
