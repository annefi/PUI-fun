/* ******************************************************************

   DAEDALUS.C - Replay program for ICARUS software.

   pdb : 01-Sep-93
			12-Dec-94	Added PM items to histogram capabilities...
			13-Dec-94	Trends...
			14-Dec-94	More trends...
			16-Dec-94	Added serial line output for testing
			17-Dec-94	Variable display rate (1,3,5 seconds, or 0 for fast)
							Changed ISR and ISR2 (per fmi)
			19-Dec-94	Trend update only every 10 counts
			02-JAN-95   deleted check for non-zero sums in PHA averages (SEL)
			10-JAN-95   added Position range selection for TOF histograms  SEL
   		11-Jan-95   changed ion position to k2 / (k1 + k2)  SEL
			12-Jan-95   Changed wIDReq to global for Icahist's use SEL
			6-Feb-95		Extended temperature tables to cover full range  PDB
			8-Feb-95		Changed PME/Q conversion to match Icarus,
					swapped ISR2 & PMR labels on trend plot options screen SEL
			22-Feb-95	Implemented new VfPS algorithm  PDB
			01-Mar-95	The Yellow Line appears...
			30-Jun-95	Time and old commands  PDB
			16-Jul-95   use upper position limit of 1001 to allow tof for 
							events with K1+K2 = 0 in tof histogram

 * ******************************************************************/

#include <stdio.h>
#include <string.h>
#include <graph.h>
#include <time.h>
#include <bios.h>
#include <conio.h>

#define ESC	((char) 0x1B )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define BYTE unsigned char

DWORD	dwCounts[4200], dwFSR, dwNSR, dwISR, dwNDCR, dwIDCR,
		dwSTPUR, dwMSRT, dwMDCR, dwISR2, dwPMR, dwYmaxNew=0,
		dwRecorded=0, dwEvReq=0, dwHistCtr=0, dwTrendCtr=0,
		near dwFSRtot=0, near dwNSRtot=0, near dwISRtot=0,
		near dwNDCRtot=0, near dwIDCRtot=0, near dwMSRTtot=0,
		near dwMDCRtot=0, near dwISR2tot=0, near dwPMRtot=0,
		dwRate[9] ;
WORD	wTOF, wK1, wK2, wStart, wID, wCmd, near wSec=0, wLastSec=0, wLog=0,
		wSource=1, wXlow=0, wXhigh=4100, wTlow, wThigh, wXinc=1, wScan=0,
		wDisplay=0, wHist=0, wTrend=0, wPHA=0, wRate=0, wOpts=1,
		wDont=0, wVax=0, wSecReq=1, wParam=0, wIDReq=0 ;
BYTE	bHK, szVersion[19]="Version: 24-Feb-95", szName[40], szTitle[80],
		szText[80]="", szText2[80]="", szBuffer[100]="", szRate[80]="",
		szBegTime[10], szDate[10],
		*szTrends[48] = {	
		"  0 = +28V           ", " 16 = +28V           ", " 32 = FSR             ",
		"  1 = + 9V           ", " 17 = + 9V           ", " 33 = NSR             ",
		"  2 = + 5V           ", " 18 = + 6V           ", " 34 = ISR             ",
		"  3 = - 5V           ", " 19 = + 5V           ", " 35 = NDCR            ",
		"  4 = -12V           ", " 20 = - 5V           ", " 36 = IDCR            ",
		"  5 = T1 (pm baffle) ", " 21 = -12V           ", " 37 = MSRT            ",
		"  6 = T2 (wave e/qps)", " 22 = T1 (fcw bd)    ", " 38 = MDCR            ",
		"  7 = <unused>       ", " 23 = T2 (Vee)       ", " 39 = ISR2            ",
		"  8 = +28I (main)    ", " 24 = +28I           ", " 40 = PMR             ",
		"  9 = +28I (sec)     ", " 25 = + 6I           ", "                      ",
		" 10 = + 5I           ", " 26 = + 5I           ", "                      ",
		" 11 = <unused>       ", " 27 = - 5I           ", "                      ",
		" 12 = PM MCPPS       ", " 28 =   Start MCPPS  ", "                      ",
		" 13 = PM   E/Q       ", " 29 = Neutral MCPPS  ", "                      ",
		" 14 = WAVE E/Q       ", " 30 =     Ion MCPPS  ", "                      ",
		" 15 = VfPS           ", " 31 =       HPS      ", "                      " } ;
REAL	rFudge=1., rOffset=0., rHK, rAvFSR=0., rAvNSR=0., rAvISR=0.,
		rAvNDCR=0., rAvIDCR=0.,	rAvMSRT=0., rAvMDCR=0., rAvISR2=0.,
		rAvPMR=0., rRatCnt=0., rXpos=0., rAverageQ=0., rAverageK=0.,
		rRadius=0., rTheta=0.;

void IcaHist() ;
void Reset() ;
void RateAverage() ;
void near fTime() ;

FILE *infile, *pha, *h ;

int main( int argc, char *argv[] ) {

	WORD	i, j, c, wEvents=0, wCmdNum=0, wNow=0, wFirstTime=0,
         wGndHK[16], wVfHK[16], wGHK[16], wVHK[16], wHK, wLev,
			wCalVoltage, wCalLev, wPHACtr=0, wRecord=0, wFile=0, wRefresh=0,
			wManual=0, wXpos=0, wPosHigh = 2000, wPosLow = -1, status ;

	REAL	rGndCvt[16]={ (28./200.), (9./200.), (5./200.), (-5./200.),
							(-12./200.), 1., 1., 1.,
							2., .25, 1., 1., 15., 15.9, 47.6, 44.775 },
			rGndOff[16]={ 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
							0., 0., 0., -5544. },
			rVfCvt[16]={ (28./200.), (9./200.), (6./200.), (5./200.),
							(-5./200.), (-12./200.), 1., 1.,
							.25, 1., 1., 1., 15., 15., 15., 150. },
			rVfOff[16]={ 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
							0., 0., 0., 0. },
			rTemp[256]={160.0, 154.7, 125.9, 110.6, 100.4, 92.8, 86.7, 81.8,
							77.5, 73.9, 70.6, 67.7, 65.1, 62.7, 60.6, 58.5,
							56.7, 54.9, 53.3, 51.7,
							50.3, 48.9, 47.6, 46.3, 45.1, 44.0, 42.9, 41.8,
							40.8, 39.8, 38.9, 38.0, 37.1, 36.3, 35.4, 34.6,
							33.8, 33.1, 32.4, 31.6, 30.9, 30.2, 29.6, 28.9,
							28.3, 27.7, 27.1, 26.5, 25.9, 25.3, 24.7, 24.2,
							23.6, 23.1, 22.6, 22.1, 21.6, 21.1, 20.6, 20.1,
							19.6, 19.2, 18.7, 18.2, 17.8, 17.3, 16.9, 16.5,
							16.0, 15.6, 15.2, 14.8, 14.4, 14.0, 13.6, 13.2,
							12.8, 12.4, 12.0, 11.7, 11.3, 10.9, 10.5, 10.2,
							9.8, 9.5, 9.1, 8.8, 8.4, 8.1, 7.7, 7.4,
							7.0, 6.7, 6.4, 6.0, 5.7, 5.4, 5.1, 4.7,
							4.4, 4.1, 3.8, 3.5, 3.2, 2.9, 2.5, 2.2,
							1.9, 1.6, 1.3, 1.0, 0.7, 0.4, 0.1, -0.2,
							-0.5, -0.8, -1.0, -1.3, -1.6, -1.9, -2.2, -2.5,
							-2.8, -3.1, -3.4, -3.6, -3.9, -4.2, -4.5, -4.8,
							-5.0, -5.3, -5.6, -5.9, -6.2, -6.4, -6.7, -7.0,
							-7.3, -7.5, -7.8, -8.1, -8.4, -8.6, -8.9, -9.2,
							-9.5, -9.7, -10.0, -10.3, -10.6, -10.8, -11.1, -11.4,
							-11.7, -11.9, -12.2, -12.5, -12.8, -13.0, -13.3, -13.6,
							-13.9, -14.1, -14.4, -14.7, -15.0, -15.3, -15.5, -15.8,
							-16.1, -16.4, -16.7, -16.9, -17.2, -17.5, -17.8, -18.1,
							-18.4, -18.7, -19.0, -19.2, -19.5, -19.8, -20.1, -20.4,
							-20.7, -21.0, -21.3, -21.6, -21.9, -22.2, -22.5, -22.8,
							-23.1, -23.5, -23.8, -24.1, -24.4, -24.7, -25.0, -25.4,
							-25.7, -26.0, -26.4, -26.7, -27.0, -27.4, -27.7, -28.1,
							-28.4, -28.8, -29.1, -29.5, -29.9, -30.2, -30.6, -31.0,
							-31.4, -31.8, -32.1, -32.5, -32.9, -33.4, -33.8, -34.2,
							-34.6, -35.1, -35.5, -35.9, -36.4, -36.9, -37.3, -37.8,
							-38.3, -38.8, -39.3, -39.9, -40.4, -41.0, -41.5, -42.1,
							-42.7, -43.3, -44.0, -44.6, -45.3, -46.0, -46.7, -47.5,
							-48.2, -49.1, -49.9, -50.8 } ;

	BYTE	szCommand[80], bYorN, *szString,
			szType[10]="", szHType[10]="", szPHFile[20],
			szLev[5], szHist[40]="", szFlag[2]="", szTime2[10],
			szBlank[80]="                                                      ",
			szOldCommand1[20]="", szOldCommand2[20]="", szOldCommand3[20]="",
			szOldCommand4[20]="", szOldCommand5[20]="", szTime[10],
			szHome[15]="BEDTIME!!",
			szLunch[15]="LUNCHTIME!!",
			szDinner[15]="DINNERTIME!!!",
			*szGndHK[16] = {	"+28V (sec): %4.1f", "+ 9V      : %4.1f",
			"+ 5V      : %4.1f",	"- 5V      : %4.1f",	"-12V      : %4.1f",
			"T (PM)    : %4.1f",	"T (W E/Q) : %4.1f",	"                 ",
			"+28I (pri): %4.1f",	"+28I (sec): %4.1f",	"+ 5I      : %4.1f",
			"                 ", "PM MCP    : %5d", "PM E/Q    : %5d",
			"WAVE E/Q  : %5d", "Vf        : %5d" },

			*szVfHK[16] = {	"+28V       : %4.1f", "+ 9V       : %4.1f",
			"+ 6V       : %4.1f", "+ 5V       : %4.1f", "- 5V       : %4.1f",
			"-12V       : %4.1f", "T (FCW bd) : %4.1f", "T (Vee)    : %4.1f",
			"+28I       : %4.1f", "+ 6I       : %4.1f", "+ 5I       : %4.1f",
			"- 5I       : %4.1f",
			"Start MCPPS: %5d (%3d)", "Neut. MCPPS: %5d (%3d)",
			"Stop  MCPPS: %5d (%3d)", "HVPS (30kV): %5d (%3d)"  } ;

// ------------------------------------------------------------------------

	_clearscreen(_GCLEARSCREEN) ;
	if( argc < 2 ) {
		printf( "Usage is: DAEDALUS <filename> .  Try again.\n" ) ;
		exit(-1) ;
	}
	if( !strncmp( argv[2], "-", 1 ) ) wDont = 1 ;
	if( (infile = fopen( argv[1], "rb" )) == NULL ) {
		printf( "Error opening file: %40s", argv[1] ) ;
		exit(-1) ;
	}

//	Read name and title...

	fread( szName, 40, 1, infile ) ;
	fread( szTitle, 80, 1, infile ) ;
	_settextcolor(15) ;
	_settextposition(1,1) ;
	sprintf( szText, "File name: %s\n", szName ) ;
	_outtext( szText ) ;
	sprintf( szText, "Run title: %s\n\n\n", szTitle ) ;
	_outtext( szText ) ;

	_strtime( szTime2 ) ;
	_settextcolor(15) ;
	_settextposition(24,30) ;
	if( !strncmp( szTime2, "19", 2 ) )
		_outtext( szDinner ) ;
	else if( !strncmp( szTime2, "12", 2 ) )
		_outtext( szLunch ) ;
	else if( !strncmp( szTime2, "23", 2 ) )
		_outtext( szHome ) ;

/* ------------------ Main Loop ---------------------------------- */

	while( 1 ) {
		fflush( stdin ) ;
		if( kbhit() ) {
			c = getch() ;
			switch( tolower(c) ) {

/* ----------------------- PHA -> ascii -------------------------- */

			case 'p' :
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
				printf( "Enter name of PHA file: " ) ;
				gets( szPHFile ) ;
				printf( "Number of events to put into file? [0=all]: " ) ;
				scanf( "%ld", &dwEvReq ) ;
				if( !dwEvReq ) dwEvReq = 1000000. ;
				pha = fopen( szPHFile, "w+" ) ;
				fprintf( pha, "%s\n%s\n", szName, szTitle ) ;
				wPHA = 1 ;
				wPHACtr = 0 ;
			break ;

/* ----------------------- Histogram ---------------------------- */

			case 'h' :
				wScan = 0 ;
				for( i=0; i<4200; i++ )
					dwCounts[i] = 0 ;
				_clearscreen(_GCLEARSCREEN) ;
				wHist = 1 ;
				dwHistCtr = 0 ;
				fflush( stdin ) ;
				_settextposition( 24,1 ) ;
				_outtext( szBlank ) ;
				_settextposition( 24,1 ) ;
				_outtext( "Neutral, Ion, PM, or ID=1 events? [n, i, p, or 1]: " ) ;
				gets( szHType ) ;
				if( !strncmp( strlwr(szHType), "n", 1 ) ) {
					wIDReq = 2 ;
				}
				else if( !strncmp( strlwr(szHType), "i", 1 ) ) {
					wIDReq = 3 ;
				}
				else if( !strncmp( strlwr(szHType), "p", 1 ) ) {
					wIDReq = 0 ;
					wXhigh = 1000 ;
				}
				else if( !strncmp( strlwr(szHType), "1", 1 ) ) {
					wIDReq = 1 ;
				}
				else {
					printf( "Invalid entry.  Try again.\n" ) ;
					wHist = 0 ;
				}
				_settextposition( 24,1 ) ;
				_outtext( szBlank ) ;
				_settextposition( 24,1 ) ;
				_outtext( "Type of histogram? [pos/tof/k1/k2/start/stop/rad/th/q1/q2/q3/q123]: " ) ;
				wSource = 1;
				gets( szType ) ;
				if( !strncmp( strlwr(szType), "pos", 3 ) ) wSource = 0 ;
				else if( !strncmp( strlwr(szType), "tof", 3 ) ) wSource = 1 ;
				else if( !strncmp( strlwr(szType), "k1", 2 ) ) wSource = 2 ;
				else if( !strncmp( strlwr(szType), "k2", 2 ) ) wSource = 3 ;
				else if( !strncmp( strlwr(szType), "sta", 3 ) ) wSource = 4 ;
				else if( !strncmp( strlwr(szType), "sto", 3 ) ) wSource = 5 ;
				else if( !strncmp( strlwr(szType), "r", 1 ) ) wSource = 6 ;
				else if( !strncmp( strlwr(szType), "th", 2 ) ) wSource = 7 ;
				else if( !strncmp( strlwr(szType), "q123", 4 ) ) wSource = 11 ;
				else if( !strncmp( strlwr(szType), "q1", 2 ) ) wSource = 8 ;
				else if( !strncmp( strlwr(szType), "q2", 2 ) ) wSource = 9 ;
				else if( !strncmp( strlwr(szType), "q3", 2 ) ) wSource = 10 ;
				_settextposition( 24,1 ) ;
				_outtext( szBlank ) ;
				_settextposition( 24,20 ) ;
				_outtext( szBlank ) ;
				_settextposition( 24,1 ) ;
				_outtext( "Number of events? [0=all]: " ) ;
				scanf( "%ld", &dwEvReq ) ;
				if( !dwEvReq ) dwEvReq = 1000000. ;
				fflush( stdin ) ;
				if( wSource != 1 && wSource < 6 ) {
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "TOF window? [TOFlow, TOFhigh]: " ) ;
					scanf( "%d, %d", &wTlow, &wThigh ) ;
					fflush( stdin ) ;
				}
				if( wSource == 1 ) {
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Position window? [Low, High (0 to 1000 (1001 so see K1+K2=0 TOFs))]: " ) ;
					scanf( "%d, %d", &wPosLow, &wPosHigh ) ;
					fflush( stdin ) ;
				}
				_clearscreen(_GCLEARSCREEN) ;
			break ;

/* ------------------ Trend PLot --------------------------------- */

			case 't' :
				for( i=0; i<4200; i++ )
					dwCounts[i] = 0 ;
				_clearscreen(_GCLEARSCREEN) ;
				wSource = 12 ;
				wTrend = 1 ;
				dwTrendCtr = 0 ;
				fflush( stdin ) ;
				_settextposition(1,1) ;
				_settextcolor(15) ;
				_outtext( "                       TREND PLOTS" ) ;
				_settextposition(3,1) ;
				_settextcolor(13) ;
				_outtext( "Ground-referenced HK   Vf-referenced HK         Rates" ) ;
				_settextcolor(11) ;
				for( j=0; j<3; j++ ) {
					for( i=0; i<16; i++ ) {
						_settextposition(i+5,j*24) ;
						sprintf( szText, szTrends[3*i+j] ) ;
						_outtext( szText ) ;
					}
				}
				_settextposition(22,1) ;
				_outtext( "Enter parameter number: " ) ;
				scanf("%d", &wParam ) ;
				fflush( stdin ) ;
				printf( "\nNumber of readings? [0=all (up to 4000 that is)]: " ) ;
				scanf( "%ld", &dwEvReq ) ;
				if( !dwEvReq ) dwEvReq = 4000 ;
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
			break ;

/* ---------- Display histogram or trend plot NOW ---------------- */

			case 'd' :
				wNow = 1 ;
			break ;

/* ------------------------ Clear screen ------------------------- */

			case 'n' :
				_clearscreen(_GCLEARSCREEN) ;
			break ;

/* ---------------------- Display options ------------------------ */

			case 'o' :
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
				wOpts = 1 ;
			break ;

/* -------------------- Refresh rate averages --------------------- */

			case 'a' :
				fflush( stdin ) ;
				dwFSRtot=dwNSRtot=dwISRtot=dwNDCRtot=dwIDCRtot=0 ;
				dwMSRTtot=dwMDCRtot=dwPMRtot=dwISR2tot=0 ;
				rAvFSR=rAvNSR=rAvISR=rAvNDCR=rAvIDCR=rAvMSRT=rAvMDCR=0. ;
				rAvPMR=rAvISR2=rRatCnt = 0. ;
			break ;

/* ---------------- Toggle log/linear display -------------------- */

			case 'l' :
				_setvideomode(_DEFAULTMODE) ;
				if( wLog ) wLog = 0 ;
				else	wLog = 1 ;
				IcaHist() ;
			break ;

/* ---------------- Toggle rates -> vax mode --------------------- */

			case 'v' :
				if( wVax ) wVax = 0 ;
				else	wVax = 1 ;
			break ;

/* ---------------- Change display update rate ------------------- */

			case '0' :
				wSecReq = 0 ;
			break ;

			case '1' :
				wSecReq = 1 ;
			break ;

			case '3' :
				wSecReq = 3 ;
			break ;

			case '5' :
				wSecReq = 5 ;
			break ;

			case '9' :
				wSecReq = 9 ;
			break ;

/* ------ Save histogram in ascii file or Scan Data --------------- */

			case 's' :
				fflush( stdin ) ;
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Enter file name for histogram data: " ) ;
					gets( szHist ) ;
					h = fopen( szHist, "w+" ) ;
					fprintf( h, "%s\n", szHist ) ;
					for( i=0; i<4200; i++ )
						fprintf( h, "%4d   %7ld\n", i, dwCounts[i] ) ;
					printf( "Histogram recorded.\a" ) ;
					IcaHist() ;
				}
				else {
					if( wScan ) wScan = 0 ;
					else	{
						_clearscreen(_GCLEARSCREEN) ;
						wScan = 1 ;
					}
				}
			break ;

/* ---------------------- Rewind File --------------------------- */

			case 'r' :
				if( !wDisplay ) {
					Reset() ;
					_settextposition(24,1) ;
					_settextcolor(15) ;
					_outtext( "File rewound...\n" ) ;
				}
			break ;

/* ------------------- Change Channels/Bin ----------------------- */

			case 'b' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					_outtext( "Enter new channels/bin: " ) ;
					scanf( "%d", &wXinc ) ;
					IcaHist() ;
				}
			break ;

/* ------------------- Clear histogram ---------------------------- */

			case ESC :
				_setvideomode(_DEFAULTMODE) ;
				wHist = 0 ;
				wTrend = 0 ;
				wDisplay = 0 ;
				dwHistCtr = 0 ;
				dwTrendCtr = 0 ;
				wXlow = 0 ;
				wXhigh = 4100 ;
				wXinc = 1 ;
				wNow = 0 ;
				wOpts = 1 ;
				for( i=0; i<4200; i++ )
					dwCounts[i] = 0 ;
			break ;

/* -------------- Rescale in X or Exit Program -------------------- */

			case 'x' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Enter Xlow and Xhigh: " ) ;
					scanf( "%d, %d", &wXlow, &wXhigh ) ;
					IcaHist() ;
				}
				else {
					_clearscreen(_GCLEARSCREEN) ;
					exit(0) ;
				}
			break ;

/* ----------------------- Rescale in Y ------------------------- */

			case 'y' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Enter new maximum Y value: " ) ;
					scanf( "%ld", &dwYmaxNew ) ;
					if( dwYmaxNew ) dwYmaxNew-- ;
					IcaHist() ;
				}
			break ;

			}
		}

/* ----------------- Display Options ----------------------------- */

		if( wOpts ) {
			wOpts = 0 ;
			_settextcolor(15) ;
			_settextposition(1,1) ;
			_outtext( "File name: " ) ;
			_settextcolor(11) ;
			sprintf( szText, "%s\n", szName ) ;
			_outtext( szText ) ;
			_settextcolor(15) ;
			_outtext( "Run title: " ) ;
			_settextcolor(11) ;
			sprintf( szText, "%s\n\n\n", szTitle ) ;
			_outtext( szText ) ;
			_settextcolor(10) ;
			_settextposition(4,30) ;
			_outtext( "USER OPTIONS\n" ) ;
			_settextposition(5,30) ;
			_settextcolor(7) ;
			sprintf( szText, __DATE__ ) ;
			_outtext( szText ) ;
			_settextcolor(15) ;
			_settextposition(7,1) ;
			_outtext( "     h - " ) ;
			_settextcolor(14) ;
			_outtext( "Histogram of pos/tof/k1/k2/start/stop/rad/th/q1/q2/q3/q123\n" ) ;
			_settextcolor(10) ;
			_outtext( "          d - " ) ;
			_settextcolor(14) ;
			_outtext( "display histogram early\n" ) ;
			_settextcolor(10) ;
			_outtext( "          b - " ) ;
			_settextcolor(14) ;
			_outtext( "change # channels/bin\n" ) ;
			_settextcolor(10) ;
			_outtext( "          x - " ) ;
			_settextcolor(14) ;
			_outtext( "rescale x axis\n" ) ;
			_settextcolor(10) ;
			_outtext( "          y - " ) ;
			_settextcolor(14) ;
			_outtext( "rescale y axis" ) ;
			_settextcolor(10) ;
			_outtext( " (0 reverts to automatic scaling)\n          l - " ) ;
			_settextcolor(14) ;
			_outtext( "toggle between log and linear y-scale\n" ) ;
			_settextcolor(10) ;
			_outtext( "          s - " ) ;
			_settextcolor(14) ;
			_outtext( "save histogram into an ascii file\n" ) ;
			_settextcolor(10) ;
			_outtext( "        <esc> - " ) ;
			_settextcolor(14) ;
			_outtext( "clear histogram display\n" ) ;
			_settextcolor(15) ;
			_outtext( "     t - " ) ;
			_settextcolor(14) ;
			_outtext( "trend plot of HK or Rates\n" ) ;
			_settextcolor(10) ;
			_outtext( "          (same sub-options as with h apply)\n" ) ;
			_settextcolor(15) ;
			_outtext( "     p - " ) ;
			_settextcolor(14) ;
			_outtext( "save PHA data into ascii file\n" ) ;
			_settextcolor(15) ;
			_outtext( "     s - " ) ;
			_settextcolor(14) ;
			_outtext( "toggle scan mode on/off\n" ) ;
			_settextcolor(15) ;
			_outtext( "     r - " ) ;
			_settextcolor(14) ;
			_outtext( "rewind file\n" ) ;
			_settextcolor(15) ;
			_outtext( "     n - " ) ;
			_settextcolor(14) ;
			_outtext( "new (clear) screen\n" ) ;
			_settextcolor(15) ;
			_outtext( "     o - " ) ;
			_settextcolor(14) ;
			_outtext( "show these options\n" ) ;
			_settextcolor(15) ;
			_outtext( "     x - " ) ;
			_settextcolor(14) ;
			_outtext( "exit program.\n" ) ;
			_settextcolor(15) ;
		}

/* --------------- PHA or HISTOGRAMS ----------------------------- */

		if( wPHA || wHist ) {

// Read data...

			fread( szFlag, 2, 1, infile ) ;
			if( feof( infile ) )	Reset() ;

			if( !strncmp( szFlag, "rR", 2 ) ) {
				for( i=0; i<9; i++ ) {
					fread( &dwRate[i], 4, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
				fread( szTime, 10, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				if( !wFirstTime ) {
					wFirstTime=1 ;
					strcpy( szBegTime, szTime ) ;
				}
			}
			else if( !strncmp( szFlag, "PH", 2 ) ) {
				fread( &wTOF, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				fread( &wK1, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				fread( &wK2, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				fread( &wStart, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				fread( &wID, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				wPHACtr++ ;

// Histograms...

				if( wHist && (wID==wIDReq) ) {
					if( (wSource==0) && (wK1+wK2) ) {
						if ( wIDReq == 3 )
							rXpos = (REAL)wK2 / ( (REAL)wK1 + (REAL)wK2 ) ;
						else
							rXpos = (REAL)wK1 / ( (REAL)wK1 + (REAL)wK2 ) ;
						rXpos = rXpos * rFudge - rOffset ;
						wXpos = (WORD)( rXpos * 1000. + 0.5 ) ;
						if( wTOF <= wThigh && wTOF >= wTlow ) {
							dwCounts[wXpos]++ ;
							dwHistCtr++ ;
						}
					}
					else if( wSource==1 ) {
						wXpos = -1;
					   if( (wK1+wK2) ) {
							if ( wIDReq == 3 )
								rXpos = (REAL)wK2 / ( (REAL)wK1 + (REAL)wK2 ) ;
							else
								rXpos = (REAL)wK1 / ( (REAL)wK1 + (REAL)wK2 ) ;
							rXpos = rXpos * rFudge - rOffset ;
							wXpos = (WORD)( rXpos * 1000. + 0.5 ) ;
						}
						else
							if (wPosHigh == 1001)
								wXpos = 1001;
						if ( (wXpos <= wPosHigh) && (wXpos >= wPosLow)) {
							dwCounts[wTOF]++ ;
							dwHistCtr++ ;
						}
					}
					else if( wSource==2 ) {
						if( wTOF <= wThigh && wTOF >= wTlow ) {
							dwCounts[wK1]++ ;
							dwHistCtr++ ;
						}
					}
					else if( wSource==3 ) {
						if( wTOF <= wThigh && wTOF >= wTlow ) {
							dwCounts[wK2]++ ;
							dwHistCtr++ ;
						}
					}
					else if( wSource==4 ) {
						if( wTOF <= wThigh && wTOF >= wTlow ) {
							dwCounts[wStart]++ ;
							dwHistCtr++ ;
						}
					}
					else if( wSource==5 ) {
						if( wTOF <= wThigh && wTOF >= wTlow ) {
							rAverageK = (wK1+wK2) / 2. ;
							dwCounts[(WORD)rAverageK]++ ;
							dwHistCtr++ ;
						}
					}
					else if( (wSource==6) && (wK1+wK2+wTOF) ) {
						rRadius = 1000. * (REAL)wK1 / ( (REAL)wK1 + (REAL)wK2 + (REAL)wTOF ) ;
						dwCounts[(WORD)rRadius]++ ;
						dwHistCtr++ ;
					}
					else if( (wSource==7) && (wK1+wK2+wTOF) ) {
						rTheta = 1000. * (REAL)wK2 / ( (REAL)wK1 + (REAL)wK2 + (REAL)wTOF ) ;
						dwCounts[(WORD)rTheta]++ ;
						dwHistCtr++ ;
					}
					else if( wSource==8 ) {
						dwCounts[wK1]++ ;
						dwHistCtr++ ;
					}
					else if( wSource==9 ) {
						dwCounts[wK2]++ ;
						dwHistCtr++ ;
					}
					else if( wSource==10 ) {
						dwCounts[wTOF]++ ;
						dwHistCtr++ ;
					}
					else if( wSource==11 ) {
						rAverageQ = (wK1+wK2+wTOF) / 3. ;
						dwCounts[(WORD)rAverageQ]++ ;
						dwHistCtr++ ;
					}

// Show number of events collected so far...

					if( !(dwHistCtr%10) ) {
						_settextposition(14,41) ;
						_settextcolor(14) ;
						sprintf( szText, "Hist: %7ld", dwHistCtr ) ;
						_outtext( szText ) ;
						_settextposition(15,43) ;
						_settextcolor(6) ;
						_outtext( szTime ) ;
					}

// Display histogram when ready...

					if( (dwHistCtr > dwEvReq) || wNow ) {
						IcaHist() ;
						wHist = 0 ;
					}

				} //hist

/* -------------------- PHA -> ASCII ----------------------------- */

				else if( wPHA ) {
					if( dwRecorded++ < dwEvReq ) {
						fprintf( pha, "%d %d %d %d %d\n", wTOF, wK1, wK2, wStart, wID ) ;
					}
					else {
						wPHA = 0 ;
						printf( "\a\aPHA file completed!!\n" ) ;
						fclose( pha ) ;
						Reset() ;
					}
				} //pha

			}
		} //pha or histogram

/* ---------------------- SCAN THROUGH FILE ----------------------- */

		if( wScan ) {

// Read and display PHA data...

			fread( szFlag, 2, 1, infile ) ;
			if( feof( infile ) )	Reset() ;

			if( !strncmp( szFlag, "PH", 2 ) ) {
				_settextcolor(15) ;
				_settextposition(1,57) ;
				_outtext( " TOF   K1   K2 Start ID" ) ;
				_settextcolor(10) ;
				fread( &wTOF, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				fread( &wK1, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				fread( &wK2, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				fread( &wStart, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				fread( &wID, 2, 1, infile ) ;
				if( feof( infile ) )	Reset() ;
				wPHACtr++ ;

				if( wPHACtr > 15 ) {
					wPHACtr = 0 ;
					_settextposition(17,57) ;
					_settextcolor(10) ;						//new
					_outtext( szText2 ) ;					//new
				}
				_settextposition(1+wPHACtr,57) ;
				_settextcolor(10) ;
				_outtext( szText2 ) ;
				_settextposition(2+wPHACtr,57) ;
				_settextcolor(14) ;
				sprintf( szText, "%4d %4d %4d %4d %3d",
									wTOF, wK1, wK2, wStart, wID ) ;
				_outtext( szText ) ;
				strcpy( szText2, szText ) ;
			}

// Read and display RATE data...

			else if( !strncmp( szFlag, "RR", 2 ) || !strncmp( szFlag, "rr", 2 ) || !strncmp( szFlag, "rR", 2 ) ) {
				for( i=0; i<7; i++ ) {
					fread( &dwRate[i], 4, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
				dwFSR = dwRate[0] ;
				dwNSR = dwRate[1] ;
				dwISR = dwRate[2] ;
				dwNDCR = dwRate[3] ;
				dwIDCR = dwRate[4] ;
				dwMSRT = dwRate[5] ;
				dwMDCR = dwRate[6] ;
				rRatCnt++ ;
				if( !strncmp( szFlag, "rr", 2 ) || !strncmp( szFlag, "rR", 2 ) ) {
					for( i=0; i<2; i++ ) {
						fread( &dwRate[i+7], 4, 1, infile ) ;
						if( feof( infile ) ) Reset() ;
					}
					dwISR2 = dwRate[7] ;
					dwPMR = dwRate[8] ;
				}
				if( !strncmp( szFlag, "rR", 2 ) ) {
					fread( szTime, 10, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
				_settextcolor(12) ;
				_settextposition(1,43) ;
				_outtext( szTime ) ;
				RateAverage() ;

				if( wSecReq ) {
					while( (wSec%wSecReq) || (wLastSec==wSec) ) {
						fTime() ;
					}
					wLastSec = wSec ;
				}
			}

// Read and display old commands...

			else if( !strncmp( szFlag, "CD", 2 ) ) {
				fread( szOldCommand1, 20, 1, infile ) ;
				fread( szOldCommand2, 20, 1, infile ) ;
				fread( szOldCommand3, 20, 1, infile ) ;
				fread( szOldCommand4, 20, 1, infile ) ;
				fread( szOldCommand5, 20, 1, infile ) ;
				_settextcolor(7) ;
				_settextposition(2,39) ;
				_outtext( szOldCommand1 ) ;
				_settextposition(3,39) ;
				_outtext( szOldCommand2 ) ;
				_settextposition(4,39) ;
				_outtext( szOldCommand3 ) ;
				_settextposition(5,39) ;
				_outtext( szOldCommand4 ) ;
				_settextposition(6,39) ;
				_outtext( szOldCommand5 ) ;
			}

// Read and display HK data...

			else if( !strncmp( szFlag, "HK", 2 ) ) {
				_settextcolor(15) ;
				_settextposition(1,1) ;
				_outtext( "   Ground HK   " ) ;
				_settextcolor(13) ;
				for( i=0; i<16; i++ ) {
					fread( &wHK, 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
					wGHK[i] = wHK ;
					rHK = (REAL)(wHK) * rGndCvt[i] + rGndOff[i] ;

					if( (i<12) && (i!=5) && (i!=6) )
						sprintf( szText, szGndHK[i], rHK ) ;
					else if( i>11 )
						sprintf( szText, szGndHK[i], (WORD)rHK ) ;

					if( (i==5) || (i==6) ) {
						sprintf( szText, szGndHK[i], rTemp[wHK] ) ;
					}

					_settextposition(i+2,1) ;
					_outtext( szText ) ;
				}
				_settextcolor(15) ;
				_settextposition(1,20) ;
				_outtext( "   Vf-referenced" ) ;
				_settextcolor(13) ;
				for( i=0; i<16; i++ ) {
					fread( &wHK, 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
					wVHK[i] = wHK ;
					rHK = (REAL)(wHK) * rVfCvt[i] + rVfOff[i] ;

					if( i < 12 )
						sprintf( szText, szVfHK[i], rHK ) ;
					else if( i >= 12 )
						sprintf( szText, szVfHK[i], (WORD)rHK, wHK ) ;

					if( (i==6) || (i==7) ) {
						sprintf( szText, szVfHK[i], rTemp[wHK] ) ;
					}

					_settextposition(i+2,20) ;
					_outtext( szText ) ;
				}
				_settextposition(12,41) ;
				_settextcolor(12) ;
				_outtext( szName ) ;
			}
		} //scan

/* ------------------------- TRENDS ---------------------------------- */

		if( wTrend ) {

			fread( szFlag, 2, 1, infile ) ;
			if( feof( infile ) )	Reset() ;

			if( wParam <= 15 ) {
				if( !strncmp( szFlag, "HK", 2 ) ) {
					for( i=0; i<16; i++ ) {
						fread( &wHK, 2, 1, infile ) ;
						if( feof( infile ) ) Reset() ;
						rHK = (REAL)(wHK) * rGndCvt[i] + rGndOff[i] ;
						if( rHK<0. ) rHK = rHK * -1. ;
						if( i==5 || i==6 ) rHK = rTemp[wHK] ;
						if( i==wParam ) dwCounts[dwTrendCtr++] = (DWORD)rHK ;
					}
				}
			}
			else if( wParam >=16 && wParam <=31 ) {
				if( !strncmp( szFlag, "HK", 2 ) ) {
					for( i=0; i<16; i++ ) {
						fread( &wHK, 2, 1, infile ) ;
						if( feof( infile ) ) Reset() ;
					}
					for( i=0; i<16; i++ ) {
						fread( &wHK, 2, 1, infile ) ;
						if( feof( infile ) ) Reset() ;
						rHK = (REAL)(wHK) * rVfCvt[i] ;
						if( rHK<0. ) rHK = rHK * -1. ;
						if( i==6 || i==7 ) rHK = rTemp[wHK] ;
						j = i+16 ;
						if( j==wParam ) {
							dwCounts[dwTrendCtr++] = (DWORD)rHK ;
						}
					}
				}
			}
			else if( wParam > 31 ) {
				if( !strncmp( szFlag, "RR", 2 ) || !strncmp( szFlag, "rr", 2 ) || !strncmp( szFlag, "rR", 2 ) ) {
					for( i=0; i<7; i++ ) {
						fread( &dwRate[i], 4, 1, infile ) ;
						if( feof( infile ) ) Reset() ;
					}
					dwFSR = dwRate[0] ;
					dwNSR = dwRate[1] ;
					dwISR = dwRate[2] ;
					dwNDCR = dwRate[3] ;
					dwIDCR = dwRate[4] ;
					dwMSRT = dwRate[5] ;
					dwMDCR = dwRate[6] ;
					rRatCnt++ ;

					if( !strncmp( szFlag, "rr", 2 ) || !strncmp( szFlag, "rR", 2 ) ) {
						for( i=0; i<2; i++ ) {
							fread( &dwRate[i+7], 4, 1, infile ) ;
							if( feof( infile ) ) Reset() ;
						}
						dwISR2 = dwRate[7] ;
						dwPMR = dwRate[8] ;
					}
					if( !strncmp( szFlag, "rR", 2 ) ) {
						fread( szTime, 10, 1, infile ) ;
						if( feof( infile ) ) Reset() ;
					}
					for( i=0; i<9; i++ ) {
						if( wParam == (i+32) )
							dwCounts[dwTrendCtr++] = dwRate[i] ;
					}
				}
			}

			if( !(dwTrendCtr%10) ) {
				_settextposition(13,25) ;
				_settextcolor(13) ;
				sprintf( szText, "Trend Plot: %7ld", dwTrendCtr ) ;
				_outtext( szText ) ;
			}

			if( (dwTrendCtr>dwEvReq) || wNow ) {
				IcaHist() ;
				wTrend = 0 ;
				wScan = 0 ;
			}

		} //trend

	} //while(1)

}

void Reset() {

	extern WORD	wHist, wTrend, wRate, wPHA, wScan ;
	extern BYTE	szName[40], szTitle[80] ;

	printf( "\a" ) ;
	rewind( infile ) ;
	fread( szName, 40, 1, infile ) ;
	fread( szTitle, 80, 1, infile ) ;
	if( wHist || wTrend ) IcaHist() ;
	wRate = wPHA = wTrend = wHist = wScan = 0 ;

}

void RateAverage() {

	int i, status ;

	_settextcolor(15) ;
	_settextposition(18,4) ;
	sprintf( szText, "Rate Averages (%ld samples)   ",
			(DWORD)rRatCnt ) ;
	_outtext( szText ) ;

	_settextcolor(7) ;
	_settextposition(18,63) ;
	sprintf( szText, __DATE__ ) ;
	_outtext( szText ) ;
	_settextcolor(11) ;

	dwFSRtot += dwFSR ;
	rAvFSR = ( rAvFSR * (rRatCnt-1.) + (float)dwFSR ) / rRatCnt ;
	_settextposition(19,1) ;
	sprintf( szText, " FSR: %6ld  ( Avg = %9.3f  Tot = %9ld )  ",
			dwFSR, rAvFSR, dwFSRtot ) ;
	_outtext( szText ) ;

	dwNSRtot += dwNSR ;
	rAvNSR = ( rAvNSR * (rRatCnt-1.) + (float)dwNSR ) / rRatCnt ;
	_settextposition(20,1) ;
	sprintf( szText, " NSR: %6ld  ( Avg = %9.3f  Tot = %9ld )  ",
			dwNSR, rAvNSR, dwNSRtot ) ;
	_outtext( szText ) ;

	dwISR2tot += dwISR2 ;
	rAvISR2 = ( rAvISR2 * (rRatCnt-1.) + (float)dwISR2 ) / rRatCnt ;
	_settextposition(21,1) ;
	sprintf( szText, " ISR: %6ld  ( Avg = %9.3f  Tot = %9ld )  ",
			dwISR2, rAvISR2, dwISR2tot ) ;
	_outtext( szText ) ;

	dwNDCRtot += dwNDCR ;
	rAvNDCR = ( rAvNDCR * (rRatCnt-1.) + (float)dwNDCR ) / rRatCnt ;
	_settextposition(22,1) ;
	sprintf( szText, "NDCR: %6ld  ( Avg = %9.3f  Tot = %9ld )  ",
			dwNDCR, rAvNDCR, dwNDCRtot ) ;
	_outtext( szText ) ;

	dwIDCRtot += dwIDCR ;
	rAvIDCR = ( rAvIDCR * (rRatCnt-1.) + (float)dwIDCR ) / rRatCnt ;
	_settextposition(23,1) ;
	sprintf( szText, "IDCR: %6ld  ( Avg = %9.3f  Tot = %9ld )  ",
			dwIDCR, rAvIDCR, dwIDCRtot ) ;
	_outtext( szText ) ;

	dwMSRTtot += dwMSRT ;
	rAvMSRT = ( rAvMSRT * (rRatCnt-1.) + (float)dwMSRT ) / rRatCnt ;
	_settextposition(24,1) ;
	sprintf( szText, "MSRT: %6ld  ( Avg = %9.3f  Tot = %9ld )  ",
			dwMSRT, rAvMSRT, dwMSRTtot ) ;
	_outtext( szText ) ;

	dwMDCRtot += dwMDCR ;
	rAvMDCR = ( rAvMDCR * (rRatCnt-1.) + (float)dwMDCR ) / rRatCnt ;
	_settextposition(25,1) ;
	sprintf( szText, "MDCR: %6ld  ( Avg = %9.3f  Tot = %9ld )  ",
			dwMDCR, rAvMDCR, dwMDCRtot ) ;
	_outtext( szText ) ;

	dwISRtot += dwISR ;
	rAvISR = ( rAvISR * (rRatCnt-1.) + (float)dwISR ) / rRatCnt ;
	_settextposition(20,53) ;
	sprintf( szText, "  ISR2: %6ld ( %8.3f )", dwISR, rAvISR   ) ;
	_outtext( szText ) ;

	dwPMRtot += dwPMR ;
	rAvPMR = ( rAvPMR * (rRatCnt-1.) + (float)dwPMR ) / rRatCnt ;
	_settextposition(21,53) ;
	sprintf( szText, "   PMR: %6ld ( %8.3f )", dwPMR, rAvPMR   ) ;
	_outtext( szText ) ;

//   Send out rates to vax if requested...

	if( wVax ) {

		_bios_serialcom( _COM_INIT, 1,
						  _COM_4800 | _COM_CHR8 | _COM_NOPARITY | _COM_STOP1 ) ;

		sprintf( szBuffer, "MTOF " ) ;

		for( i=0; i<9; i++ ) {
			sprintf( szRate, "%9.9lu ", dwRate[i] ) ;
			strcat( szBuffer, szRate ) ;
		}
		strcat( szBuffer, "\n" ) ;

		for( i=0; i<100; i++ ) {
			status = _bios_serialcom( _COM_SEND, 1, szBuffer[i] ) ;
		}
	}

}
/* ******************************************************************
	fTime -	Routine to read real-time clock in order to have rates
				that are in counts/second.

	fcw : 21 jul 93
 * **************************************************************** */

void near fTime() {
	_asm {
	lp:   mov   ah, 2
			int   0x1a		; get real-time clock second
			jc 	lp
			mov   al, dh	; change from bcd
			sub   ah, ah
			mov   bl, 16
			div   bl
			mov   bh, ah
			sub   ah, ah
			mov   bl, 10
			mul   bl
			add   al, bh
			mov   wSec, ax
	 }
}
