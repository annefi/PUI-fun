/* ******************************************************************

	dpusim.C - Driver routines for Fred Wire's DPU Simulator card.

	FCW :	14 apr 96	modified to read swims PHA
							took out DPPS hk code
 * ***************************************************************** */

/*

WORD  near wHK ;
WORD	near wTOF, near wK1, near wK2, near wSTRTAMP ;
dwORD	near dwFSR, near dwA, near dwB, near dwAB, near dwDCR, near dwRSR,
		near dwMFSR, near dwMDCR ;

void near fPHARead() ;
void near fCommand() ;
void near fRates() ;
void near fTime() ;

*/


/* ******************* ROUTINES *************************************
	******************************************************************

	fPHARead -  Routine to read PHA data from SWIMS using Fred Wire's
					new ACTEL based DPU Simulator card.

				-  wID = 0 if valid data;
						 = 0x223 if timeout (i.e. no valid data)

	fcw : 22 jul 93
	pdb : 30 sep 94   (changed addresses from 30n -> 22n)
	fcw : 19 oct 94   (added code for:
								1) ignore data if cnt ok not set
								2) start amp is now 10bits for non PM data
	fcw : 16 oct 95   changed to read SWICS pha data
								10 bits TOF, 8 bits energy, 2 bits ID
	fcw : 30 jan 96   New PHA data format
	fcw : 14 apr 96	SWIMS pha format: 12 start amp, 12 k1, 12 k2, 12 tof
 * ***************************************************************** */

void near fPHARead() {

	if( wSim ) {
		wTOF     = getrandom( 0,4095 ) ;
		wK1      = getrandom( 0,4095 ) ;
		wK2      = getrandom( 0,4095 ) ;
		wSTRTAMP = getrandom( 0,4095 ) ;
	}
	else {
	_asm {
			mov   dx, 0x223   ;  wait for pha data
			mov   wID, dx     ;  set no data flag

			in    al, (dx)
			mov   bl, al      ;  save for clock pulse count check
			and   al, 4       ;  check pha available bit
			jz    rdphaex     ;  bye bye; no data available

			mov	dx, 0x22e	;  read clk cnt reg
			in		al, (dx)
			cmp	al, 48		;  should be 48 clocks
			jz		rdphaok
			mov	dx, 0x22d	;  clr new pha bit
			in		al, (dx)
			jmp	rdphaex

rdphaok: mov   dx, 0x228   ;  read wTOF
			in    ax, (dx)
			and   ax, 0xfff
			mov   wTOF, ax

			mov   dx, 0x229   ;  read wK1
			in    ax, (dx)
			mov	cl, 4       ;  shift over 4 places
			shr   ax, cl
			mov   wK1, ax

			mov   dx, 0x22b   ;  read wK2
			in    ax, (dx)
			and	ax, 0xfff
			mov   wK2, ax

			mov   dx, 0x22c   ;  read wSTRTAMP
			in    ax, (dx)
			mov	cl, 4       ;  shift over 4 places
			shr   ax, cl
			mov   wSTRTAMP, ax

			mov	ax, 0			;  set new data flag
			mov	wID, ax

rdphaex: nop
	}
	}
}

/* ******************************************************************
	fCommand -  Routine to send commands to MTOF using Fred Wire's DPU
					Simulator card, and return 8 bits of hk data.

	fcw : 20 jul 93
			18 mar 96   (added code for dual range dpps reading)
			15 apr 96	changed to read swims vf (deleted dual range dpps)
 * **************************************************************** */

void near fCommand() {

	if( wSim ) {
		wHK = wCmd ;
	}
	else {

	_asm {
		mov   dx, 0x223   ;read status (wait for ready)
lp0:  in    al, (dx)
		and   al, 1
		jz    lp0

		mov   dx, 0x220   ;cmd/data addr
		mov   ax, wCmd    ;get cmd
		out   (dx), ax    ;send cmd/data

		mov   dx, 0x223   ;read status (wait for status to go busy)
lp1:  in    al, (dx)
		and   al, 1
		jnz   lp1

;     read status (wait for status to go not busy)
lp2:  in    al, (dx)
		and   al, 1
		jz    lp2

;  read data and store

		mov   ax, wCmd    ;check for read vf
		cmp   ax, 0xf     ;code for read vf
		jz		do_vf

;     do reg hk read
		mov   dx, 0x221   ;mid hk byte
		in    al, (dx)
		sub   ah,ah
		jmp   store_hk

do_vf:
		mov   dx, 0x220   ;lo & mid hk byte
		in    ax, (dx)
		mov	cl, 4
		shr	ax, cl
store_hk:
		mov   wHK, ax

	}
	}
}

/* ******************************************************************
	fRates - Routine to read rate accumulator data from swims using
				Fred Wire's DPU Simulator card.

	fcw : 20 jul 93
	pdb : 22 jul 93   took out delays
	fcw : 02-aug-93   added reads of ufsr, mult starts, & mult dcr's
	fcw : 18 oct 95   modified to read swics rates
	fcw : 14 apr 96   modified to read swims rates

 * **************************************************************** */

void near fRates() {

	if( wSim ) {
		wFSR  = getrandom( 0,32767 ) ;
		wA    = getrandom( 0,32767 ) ;
		wB    = getrandom( 0,32767 ) ;
		wAB   = getrandom( 0,32767 ) ;
		wDCR  = getrandom( 0,32767 ) ;
		wRSR  = getrandom( 0,32767 ) ;
		wMFSR = getrandom( 0,32767 ) ;
		wMDCR = getrandom( 0,32767 ) ;
	}
	else {

	_asm {
		jmp	rd_fsr

send_cmd:
		mov   dx, 0x223   ;read status (wait for ready)
lp0:  in    al, (dx)
		and   al, 1
		jz    lp0

		mov   dx, 0x220   ;cmd/data addr
		mov   ax, bx		;get cmd
		out   (dx), ax    ;send cmd/data

		mov   dx, 0x223   ;read status (wait for status to go busy)
lp1:  in    al, (dx)
		and   al, 1
		jnz   lp1

;     read status (wait for status to go not busy)
lp2:  in    al, (dx)
		and   al, 1
		jz    lp2
		ret

rd_fsr:
		mov   bx, 0x101   ;  send acc read and store cmd
		call	send_cmd
		mov   dx, 0x220   ;  read FSR
		in    ax, (dx)
		mov   dwFSR, ax	;  store 2 lsbytes
		mov	dx, 0x222
		in		al, (dx)
		and	ax, 0x7f
		mov	dwFSR+2, ax	;  store ms 7 bits

		mov   bx, 0x100   ;  send acc read cmd
		call	send_cmd
		mov   dx, 0x220   ;  read A rate
		in    ax, (dx)
		mov   dwA, ax		;  store 2 lsbytes
		mov	dx, 0x222
		in		al, (dx)
		and	ax, 0x7f
		mov	dwA+2, ax	;  store ms 7 bits

		mov   bx, 0x100   ;  send acc read cmd
		call	send_cmd
		mov   dx, 0x220   ;  read B rate
		in    ax, (dx)
		mov   dwB, ax		;  store 2 lsbytes
		mov	dx, 0x222
		in		al, (dx)
		and	ax, 0x7f
		mov	dwB+2, ax	;  store ms 7 bits

		mov   bx, 0x100   ;  send acc read cmd
		call	send_cmd
		mov   dx, 0x220   ;  read AB rate
		in    ax, (dx)
		mov   dwAB, ax		;  store 2 lsbytes
		mov	dx, 0x222
		in		al, (dx)
		and	ax, 0x7f
		mov	dwAB+2, ax	;  store ms 7 bits

		mov   bx, 0x100   ;  send acc read cmd
		call	send_cmd
		mov   dx, 0x220   ;  read DCR rate
		in    ax, (dx)
		mov   dwDCR, ax	;  store 2 lsbytes
		mov	dx, 0x222
		in		al, (dx)
		and	ax, 0x7f
		mov	dwDCR+2, ax	;  store ms 7 bits

		mov   bx, 0x100   ;  send acc read cmd
		call	send_cmd
		mov   dx, 0x220   ;  read RSR
		in    ax, (dx)
		mov   dwRSR, ax	;  store 2 lsbytes
		mov	dx, 0x222
		in		al, (dx)
		and	ax, 0x7f
		mov	dwRSR+2, ax	;  store ms 7 bits

		mov   bx, 0x100   ;  send acc read cmd
		call	send_cmd
		mov   dx, 0x220   ;  read MFSR
		in    ax, (dx)
		mov   dwMFSR, ax	;  store 2 lsbytes
		mov	dx, 0x222
		in		al, (dx)
		and	ax, 0x7f
		mov	dwMFSR+2, ax	;  store ms 7 bits

		mov   bx, 0x100   ;  send acc read cmd
		call	send_cmd
		mov   dx, 0x220   ;  read MDCR
		in    ax, (dx)
		mov   dwMDCR, ax	;  store 2 lsbytes
		mov	dx, 0x222
		in		al, (dx)
		and	ax, 0x7f
		mov	dwMDCR+2, ax	;  store ms 7 bits

	}
	}
}

/* ******************************************************************
	fTime -  Routine to read real-time clock in order to have rates
				that are in counts/second.

	fcw : 21 jul 93
 * **************************************************************** */

void near fTime() {
	_asm {
	lp:   mov   ah, 2
			int   0x1a     ; get real-time clock second
			jc    lp
			mov   al, dh   ; change from bcd
			sub   ah, ah
			mov   bl, 16
			div   bl
			mov   bh, ah
			sub   ah, ah
			mov   bl, 10
			mul   bl
			add   al, bh
			mov   wSec, ax
	 }
}
