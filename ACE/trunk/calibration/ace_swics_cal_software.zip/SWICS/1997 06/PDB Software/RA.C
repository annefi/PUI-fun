/* *****************************************************************

	RA.C   Program to replay GSE files.

	pdb : 03-Jul-95
			31-Jan-96

 * ***************************************************************** */

#include <stdio.h>
#include <errno.h>
#include <graph.h>
#include <stdlib.h>
#include <string.h>

#define WORD unsigned int
#define WORD unsigned int
#define DWORD unsigned long
#define BYTE unsigned char
#define REAL float

typedef struct EDB {
	BYTE Header[6] ;
	BYTE D_Tlm[30] ;
	BYTE Data[3020] ;
} EDB ;

typedef struct Get6Type {
	unsigned Dummy1 ;
	unsigned Bit6a7 ;
} Get6Type ;

typedef struct Get4M4EType {
	unsigned Mant4 ;
	unsigned Exp4 ;
} Get4M4EType ;

typedef struct Get3M5EType {
	unsigned Mant3 ;
	unsigned Exp5 ;
} Get3M5EType ;

typedef struct MPHAWORD {
	unsigned TOF ;
	unsigned K2 ;
	unsigned K1 ;
	unsigned StartAmp ;
	unsigned ID ;
} MPHAWORD ;

typedef struct MTOFRATES {
	long PR1 ;
	long PR2 ;
	long PR3 ;
	long FSR ;
	long NSR ;
	long ISR ;
	long NDCR ;
	long IDCR ;
	long ISR2 ;
	long MFSR ;
	long MDCR ;
	long NDE1 ;
	long NDE2 ;
	long NDE3 ;
	long NDE4 ;
	long BR1 ;
	long BR2 ;
	long BR3 ;
	long ERR ;
} MTOFRATES ;

BYTE	abyData[5000], szText[80]="" ;
WORD	wSize=0, wNewBytes=0 ;
DWORD	dwBytes=0 ;

MPHAWORD *sMPHA[500] ;
MTOFRATES MRates ;

void fSimHkPkt() ;
void fSimScPkt() ;
void fEDB() ;
void fEnd() ;
void fSVMHK1() ;
void fDummyEDB() ;
void fRecCmt() ;
void fDSpare() ;
void fSwapBytes( BYTE *abyData, int byte1, int byte2 ) ;
long fDecompA( BYTE bCompressed ) ;
long fDecompC( BYTE bCompressed ) ;
long shpow2( long Exp ) ;

FILE *fp ;

main( int argc, char *argv[] ) {

	int i, iptr=0 ;
	WORD	wWord, wVersion, wNull=0, wBodyID=0, wBodyCount=0,
			wLen[10], wStamp, wLastStamp[10], wBlockType[10]={ 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0 } ;
	DWORD	dwTime ;
	BYTE	byID[5], byValidID[5] = { 0xEB, 0x90, 'G', 'S', 'E' },
			szProject[19], acID[2], szName[26]="" ;

// Open file named in command line

	if( ( fp = fopen( argv[1], "r+b" ) ) == NULL ) {
		fEnd() ;
	}

// Read main ID and quit if it isn't correct

	dwBytes += fread( byID, 1, 5, fp ) ;
	if( feof(fp) ) fEnd() ;
	for( i=0; i<5; i++ ) {
		if( byID[i] != byValidID[i] ) {
			printf( "Invalid ID.  Try new file...\n" ) ;
			exit(0) ;
		}
	}

// Read the rest of the File Header

	dwBytes += fread( &wVersion, 1, 2, fp ) ;
	if( feof(fp) ) fEnd() ;
	printf( "Version: %4x\n", wVersion ) ;
	dwBytes += fread( szProject, 1, 19, fp ) ;
	if( feof(fp) ) fEnd() ;
	printf( "Project: %s\n", szProject ) ;
	dwBytes += fread( &dwTime, 1, 4, fp ) ;
	if( feof(fp) ) fEnd() ;
	printf( "Time: %ld\n", dwTime ) ;
	dwBytes += fread( &wNull, 1, 2, fp ) ;
	if( feof(fp) ) fEnd() ;
	printf( "File Header seems okay...\n\n" ) ;

	iptr = 0 ;
	while( 1 ) {

// Read next word...

		dwBytes += fread( acID, 1, 2, fp ) ;
		printf( "%2.2s - ", acID ) ;
		if( feof(fp) ) fEnd() ;

// If next word is "DE", read Block Header...

		if( !strncmp( acID, "DE", 2 ) ) {
			dwBytes += fread( &wBodyID, 1, 2, fp ) ;
			if( feof(fp) ) fEnd() ;
			dwBytes += fread( szName, 1, 26, fp ) ;
			if( feof(fp) ) fEnd() ;
			dwBytes += fread( &wLen[iptr], 1, 2, fp ) ;
			if( feof(fp) ) fEnd() ;

			if( !strncmp( szName, "EDB", 3 ) ) wBlockType[wBodyID]=0 ;
			else if( !strncmp( szName, "SimHkPkt", 8 ) ) wBlockType[wBodyID]=1 ;
			else if( !strncmp( szName, "RecComment", 10 ) ) wBlockType[wBodyID]=2 ;
			else if( !strncmp( szName, "D_Spare", 7 ) ) wBlockType[wBodyID]=3 ;
			else if( !strncmp( szName, "DummyEDB", 8 ) ) wBlockType[wBodyID]=4 ;
			else if( !strncmp( szName, "SVMHK1", 8 ) ) wBlockType[wBodyID]=5 ;
			else if( !strncmp( szName, "SimScPkt", 8 ) ) wBlockType[wBodyID]=6 ;
			else wBlockType[wBodyID]=7 ;
			printf( "BodyID %u is for BlockType %u (%s).\n",
											wBodyID, wBlockType[wBodyID], szName ) ;
			iptr++ ;
		}

// If it is "TA", then read Block Body...

		else if( !strncmp( acID, "TA", 2 ) ) {
			dwBytes += fread( &wBodyID, 1, 2, fp ) ;
			if( feof(fp) ) fEnd() ;
			dwBytes += fread( &wStamp, 1, 2, fp ) ;
			if( feof(fp) ) fEnd() ;

//			if( wStamp != (wLastStamp[wBodyID]+1) ) {
//				printf( "Data gap??\n" ) ;
//				fEnd() ;
//			}
//			else wLastStamp[wBodyID] = wStamp ;

			dwBytes += fread( &wSize, 1, 2, fp ) ;
			if( feof(fp) ) fEnd() ;
			dwBytes += fread( &dwTime, 1, 4, fp ) ;
			if( feof(fp) ) fEnd() ;
			dwBytes += fread( abyData, 1, wSize, fp ) ;
			if( feof(fp) ) fEnd() ;
			dwBytes += fread( &wLen[iptr], 1, 2, fp ) ;
			printf( "   Block length: %u\n", wLen[iptr] ) ;
			if( feof(fp) ) fEnd() ;

			printf( "BlockType %u; Stamp = %u; Size %u; Time %lu; Len %u\n",
							wBlockType[wBodyID], wStamp, wSize, dwTime, wLen[iptr] ) ;

			if( wBlockType[wBodyID] == 0 ) fEDB() ;
			else if( wBlockType[wBodyID] == 1 ) fSimHkPkt() ;
			else if( wBlockType[wBodyID] == 2 ) fRecCmt() ;
			else if( wBlockType[wBodyID] == 3 ) fDSpare() ;
			else if( wBlockType[wBodyID] == 4 ) fDummyEDB() ;
			else if( wBlockType[wBodyID] == 5 ) fSVMHK1() ;
			else if( wBlockType[wBodyID] == 6 ) fSimScPkt() ;
			else {
				printf( "\awBlockType(wBodyID) = %u ! Unknown type.\n", wBlockType[wBodyID] ) ;
//				fEnd() ;
			}
		}
		else {
			printf("Something wrong... \n" ) ;
			getch() ;
		}
	}
}

void fSimScPkt() {
	printf( "   SimScPkt data...\n" ) ;
}

void fSimHkPkt() {
	printf( "   SimHKPkt data...\n" ) ;
}

void fEDB() {

	int i=0, j=0, iNPHA=0 ;
	int ioff_m=0, ioff_s=0, ioff_c=0 ;
	unsigned T_DTlm, i_DTlm ;
	unsigned T_DSpare, i_DSpare ;
	unsigned T_MPha, i_MPha ;
	unsigned T_SPha, i_SPha ;
	unsigned T_CPha, i_CPha ;
	unsigned T_SDiag, i_SDiag ;
	unsigned T_SStatus, i_SStatus ;
	unsigned T_SMR, i_SMR ;
	unsigned T_SME, i_SME ;
	unsigned T_SRates, i_SRates ;
	unsigned T_HMR, i_HMR ;
	unsigned T_HME, i_HME ;
	unsigned T_MStatus, i_MStatus ;
	unsigned T_MTOF, i_MTOF ;
	unsigned T_MRates, i_MRates ;
	unsigned T_P2RT, i_P2RT ;
	unsigned T_P1T, i_P1T ;
	unsigned T_P1R, i_P1R ;
	unsigned T_PRates, i_PRates ;
	unsigned T_CStatus, i_CStatus ;

	struct EDB *sbyEDB ;

	if( abyData[0] == 0xEB && abyData[1] == 0x90 && abyData[2] == 0xDA ) {
		printf( "Valid EDB data...  Hit a key to see some PHA.\n" ) ;
		getch() ;
	}
	else exit(-1) ;

	sbyEDB = (EDB *)abyData ;

	T_DTlm = sbyEDB->D_Tlm[0] ;
	T_DSpare = 256 * sbyEDB->D_Tlm[1] + sbyEDB->D_Tlm[2] ;
	T_SPha = 256 * sbyEDB->D_Tlm[3] + sbyEDB->D_Tlm[4] ;
	T_MPha = 256 * sbyEDB->D_Tlm[5] + sbyEDB->D_Tlm[6] ;
	T_CPha = 256 * sbyEDB->D_Tlm[7] + sbyEDB->D_Tlm[8] ;
	T_SDiag = sbyEDB->D_Tlm[9] ;
	T_SStatus = sbyEDB->D_Tlm[10] ;
	T_SMR = 256 * sbyEDB->D_Tlm[11] + sbyEDB->D_Tlm[12] ;
	T_SME = sbyEDB->D_Tlm[13] ;
	T_SRates = sbyEDB->D_Tlm[14] ;
	T_HMR = 256 * sbyEDB->D_Tlm[15] + sbyEDB->D_Tlm[16] ;
	T_HME = sbyEDB->D_Tlm[17] ;
	T_MStatus = sbyEDB->D_Tlm[18] ;
	T_MTOF = sbyEDB->D_Tlm[19] ;
	T_MRates = sbyEDB->D_Tlm[20] ;
	T_P2RT = sbyEDB->D_Tlm[21] ;
	T_P1T = sbyEDB->D_Tlm[22] ;
	T_P1R = sbyEDB->D_Tlm[23] ;
	T_PRates = sbyEDB->D_Tlm[24] ;

	i_DSpare = 0 ;
	i_SPha = i_DSpare + T_DSpare ;
	i_MPha = i_SPha + T_SPha ;
	i_CPha = i_MPha + T_MPha ;
	i_SDiag = i_CPha + T_CPha ;
	i_SStatus = i_SDiag + T_SDiag ;
	i_SMR = i_SStatus + T_SStatus ;
	i_SME = i_SMR + T_SMR ;
	i_SRates = i_SME + T_SME ;
	i_HMR = i_SRates + T_SRates ;
	i_HME = i_HMR + T_HMR ;
	i_MStatus = i_HME + T_HME ;
	i_MTOF = i_MStatus + T_MStatus ;
	i_MRates = i_MTOF + T_MTOF ;
	i_P2RT = i_MRates + T_MRates ;
	i_P1T = i_P2RT + T_P2RT ;
	i_P1R = i_P1T + T_P1T ;
	i_PRates = i_P1R + T_P1R ;

	ioff_s = T_DSpare + T_SPha % 7 ;
	ioff_m = T_DSpare + T_SPha + T_MPha % 6 ;
	ioff_c = T_DSpare + T_SPha + T_MPha + T_CPha % 3 ;

	iNPHA = T_MPha / 6 ;
	for( i=0; i<iNPHA; i++ ) {
		fSwapBytes( (BYTE *)&(sbyEDB->Data), ioff_m+6*i, ioff_m+6*i+5 ) ;
		fSwapBytes( (BYTE *)&(sbyEDB->Data), ioff_m+6*i+1, ioff_m+6*i+4 ) ;
		fSwapBytes( (BYTE *)&(sbyEDB->Data), ioff_m+6*i+2, ioff_m+6*i+3 ) ;
	}
//	for( i=0; i<iNPHA; i++ ) {
//		sMPHA[i] = (MPHAWORD *)&( sbyEDB->Data[ioff_m+6*i] ) ;
//		printf( "PHA[%d] : ", i ) ;
//		printf( "%u\t", sMPHA[i]->TOF ) ;
//		printf( "%u\t", sMPHA[i]->StartAmp ) ;
//		printf( "%u\t", sMPHA[i]->K1 ) ;
//		printf( "%u\t", sMPHA[i]->K2 ) ;
//		printf( "%u\n", sMPHA[i]->ID ) ;
//		if( !(i%20) ) getch() ;
//	}
	MRates.ERR = (long)sbyEDB->Data[i_MRates+0] ;
	MRates.BR3 = (long)sbyEDB->Data[i_MRates+1] ;
	MRates.BR2 = (long)sbyEDB->Data[i_MRates+2] ;
	MRates.BR1 = (long)sbyEDB->Data[i_MRates+3] ;
	MRates.NDE4 = (long)sbyEDB->Data[i_MRates+4] ;
	MRates.NDE3 = (long)sbyEDB->Data[i_MRates+5] ;
	MRates.NDE2 = (long)sbyEDB->Data[i_MRates+6] ;
	MRates.NDE1 = (long)sbyEDB->Data[i_MRates+7] ;
	MRates.MDCR = (long)sbyEDB->Data[i_MRates+8] ;
	MRates.MFSR = (long)sbyEDB->Data[i_MRates+9] ;
	MRates.ISR2 = (long)sbyEDB->Data[i_MRates+10] ;
	MRates.IDCR = (long)sbyEDB->Data[i_MRates+11] ;
	MRates.NDCR = (long)sbyEDB->Data[i_MRates+12] ;
	MRates.ISR = (long)sbyEDB->Data[i_MRates+13] ;
	MRates.NSR = (long)sbyEDB->Data[i_MRates+14] ;
	MRates.FSR = (long)sbyEDB->Data[i_MRates+15] ;
	MRates.PR3 = (long)sbyEDB->Data[i_PRates+0] ;
	MRates.PR2 = (long)sbyEDB->Data[i_PRates+1] ;
	MRates.PR1 = (long)sbyEDB->Data[i_PRates+2] ;

	MRates.ERR = fDecompA( (BYTE)MRates.ERR ) ;
	MRates.BR3 = fDecompA( (BYTE)MRates.BR3 ) ;
	MRates.BR2 = fDecompA( (BYTE)MRates.BR2 ) ;
	MRates.BR1 = fDecompA( (BYTE)MRates.BR1 ) ;
	MRates.NDE4 = fDecompA( (BYTE)MRates.NDE4 ) ;
	MRates.NDE3 = fDecompA( (BYTE)MRates.NDE3 ) ;
	MRates.NDE2 = fDecompA( (BYTE)MRates.NDE2 ) ;
	MRates.NDE1 = fDecompA( (BYTE)MRates.NDE1 ) ;
	MRates.MDCR = fDecompC( (BYTE)MRates.MDCR ) ;
	MRates.MFSR = fDecompC( (BYTE)MRates.MFSR ) ;
	MRates.ISR2 = fDecompC( (BYTE)MRates.ISR2 ) ;
	MRates.IDCR = fDecompC( (BYTE)MRates.IDCR ) ;
	MRates.NDCR = fDecompC( (BYTE)MRates.NDCR ) ;
	MRates.ISR = fDecompC( (BYTE)MRates.ISR ) ;
	MRates.NSR = fDecompC( (BYTE)MRates.NSR ) ;
	MRates.FSR = fDecompC( (BYTE)MRates.FSR ) ;
	MRates.PR3 = fDecompC( (BYTE)MRates.PR3 ) ;
	MRates.PR2 = fDecompC( (BYTE)MRates.PR2 ) ;
	MRates.PR1 = fDecompC( (BYTE)MRates.PR1 ) ;

	printf( "FSR: %ld\n", MRates.FSR ) ;
	printf( "NSR: %ld\n", MRates.NSR ) ;
	printf( "ISR: %ld\n", MRates.ISR ) ;
	printf( "NDCR: %ld\n", MRates.NDCR ) ;
	printf( "IDCR: %ld\n", MRates.IDCR ) ;
	printf( "ISR2: %ld\n", MRates.ISR2 ) ;

	getch() ;
}

long fDecompC( BYTE bCompressed ) {

	long test=0, Exp4=0, Exp5=0, Mant3=0, Mant4=0, Bit6a7=0 ;
	char stemp[64] ;
	Get6Type *Get6 ;
	Get4M4EType *Get4M4E ;
	Get3M5EType *Get3M5E ;

	if( bCompressed > 254 ) {
		return(0) ;
	}

	Get6 = (Get6Type *)&bCompressed ;
	Get4M4E = (Get4M4EType *)&bCompressed ;
	Get3M5E = (Get3M5EType *)&bCompressed ;

	Mant4 = Get4M4E->Mant4 ;
	Exp4 = Get4M4E->Exp4 ;
	Mant3 = Get3M5E->Mant3 ;
	Exp5 = Get3M5E->Exp5 ;
	Bit6a7 = Get6->Bit6a7 ;

	test = (Bit6a7 < 3) * ( (Exp4==0) * Mant4 + ( (Exp4>=1) && (Exp4<=12) ) *
			( 16 + Mant4 ) * shpow2( Exp4 - 1 ) ) + ( Bit6a7==3 ) *
			( 8 + Mant3 ) * shpow2( Exp5 - 12 ) ;
	return( test ) ;

}

long fDecompA( BYTE bCompressed ) {

	long test=0, Exp4=0, Mant4=0 ;
	Get4M4EType *Get4M4E ;

	if( bCompressed > 254 ) {
		return(0) ;
	}

	Get4M4E = (Get4M4EType *)&bCompressed ;

	Mant4 = Get4M4E->Mant4 ;
	Exp4 = Get4M4E->Exp4 ;

	test = (Exp4==0) * Mant4 + (Exp4>=1) * ( 16 + Mant4 ) * shpow2( Exp4 - 1 ) ;
	return( test ) ;

}

long shpow2( long Exp ) {
	if( Exp == 0 ) return(1) ;
	if( Exp >= 0 ) return( pow( 2.0, (double)Exp ) ) ;
	return(0) ;
}

void fSVMHK1() {
	printf( "  SVMHK1 data ..." ) ;
}

void fRecCmt() {
	printf( "  RecComment data ..." ) ;
}

void fDummyEDB() {
	printf( "  DummyEDB data ..." ) ;
}

void fDSpare() {
	printf( "  DSpare data ..." ) ;
}

void fEnd() {
	printf( "%lu bytes read in all.\n", dwBytes ) ;
	exit(1) ;
}

void fSwapBytes( BYTE item[], int byte1, int byte2 ) {

	BYTE b ;

	b = item[byte1] ;
	item[byte1] = item[byte2] ;
	item[byte2] = b ;

}
