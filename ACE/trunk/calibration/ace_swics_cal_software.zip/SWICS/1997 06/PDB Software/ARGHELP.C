/* *********************************************************************

	ICAHELP.C - Help file for the ICARUS software.

   pdb : 27-Jun-95
			29-Jun-95

   ********************************************************************* */

#include <stdio.h>
#include <graph.h>
#include <stdlib.h>

#define ESC ( (char)0x1b )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define DREAL double
#define BYTE unsigned char

ArgHelp() {

	extern WORD		wHelp ;

	_clearscreen(_GCLEARSCREEN) ;

	switch( wHelp ) {
		case 1 :
			_settextposition(1,25) ;
			_settextcolor(15) ;
			_outtext( "ICARUS Runtime Options\n\n") ;
			_settextcolor(14);
			_outtext( "Simply press the key indicated (no need to press <enter> afterwards)\n\n" ) ;
			_settextcolor(15) ;
			_outtext( "<F1>  - " ) ;
			_settextcolor(11) ;
			_outtext( "Display this or the following help screens...\n" ) ;
			_settextcolor(15) ;
			_outtext( "  h   - " ) ;
			_settextcolor(11) ;
			_outtext( "Histogram of pos/tof/k1/k2/start/stop/rad/th/q1/q2/q3/q123\n" ) ;
			_settextcolor(9) ;
			_outtext( "         d - " ) ;
			_settextcolor(11) ;
			_outtext( "Display histogram early\n" ) ;
			_settextcolor(9) ;
			_outtext( "         b - " ) ;
			_settextcolor(11) ;
			_outtext( "change Binning of channels\n" ) ;
			_settextcolor(9) ;
			_outtext( "         x - " ) ;
			_settextcolor(11) ;
			_outtext( "rescale X axis\n" ) ;
			_settextcolor(9) ;
			_outtext( "         y - " ) ;
			_settextcolor(11) ;
			_outtext( "rescale Y axis\n" ) ;
			_settextcolor(9) ;
			_outtext( "         l - " ) ;
			_settextcolor(11) ;
			_outtext( "toggle between Log and Linear y-scale\n" ) ;
			_settextcolor(9) ;
			_outtext( "         s - " ) ;
			_settextcolor(11) ;
			_outtext( "Save histogram into an ascii file\n" ) ;	
			_settextcolor(9) ;
			_outtext( "        <esc> - " ) ;
			_settextcolor(11) ;
			_outtext( "clear histogram display\n" ) ;
			_settextcolor(15) ;
			_outtext( "  c   - " ) ;
			_settextcolor(11) ;
			_outtext( "Command sensor" ) ;
			_settextcolor(9) ;
			_outtext( "  (Press <F1> for list of commands...)\n" ) ;
			_settextcolor(15) ;
			_outtext( "  p   - " ) ;
			_settextcolor(11) ;
			_outtext( "toggle display of PHA data on/off\n" ) ;
			_settextcolor(15) ;
			_outtext( "  r   - " ) ;
			_settextcolor(11) ;
			_outtext( "Record a file" ) ;
			_settextcolor(9) ;
			_outtext( "  (Asks for file name and run title...)\n" ) ;
			_settextcolor(15) ;
			_outtext( "  s   - " ) ;
			_settextcolor(11) ;
			_outtext( "Stops recording a file (if not in histogram display mode)\n" ) ;
			_settextcolor(15) ;
			_outtext( "  a   - " ) ;
			_settextcolor(11) ;
			_outtext( "Refresh rate average collection\n" ) ;
			_settextcolor(15) ;
			_outtext( "1 (or 5 or 30) - " ) ;
			_settextcolor(11) ;
			_outtext( "Set HK update rate to 1 sec, 5 sec, or 30 secs\n" ) ;
			_settextcolor(15) ;
			_outtext( "  n   - " ) ;
			_settextcolor(11) ;
			_outtext( "New (clear) screen\n" ) ;
			_settextcolor(15) ;
			_outtext( "<ESC> - " ) ;
			_settextcolor(11) ;
			_outtext( "return to program from thishelp screen...\n" ) ;
			_settextcolor(15) ;
			_outtext( "  x   - " ) ;
			_settextcolor(11) ;
			_outtext( "eXit program.\n\n" ) ;
			_settextcolor(12) ;
			_outtext( "     Press <F1> for more HELP, <ESC> to return to program..." ) ;
		break ;

		case 2 :
			_settextcolor(15) ;
			_settextposition(1,25) ;
			_outtext( "ICARUS Text Commands - Page 1 of 2...\n\n" ) ;
			_settextcolor(14) ;
			_outtext( "     These commands may be entered after runtime option 'c'\n\n" ) ;
			_settextcolor(15) ;
			_outtext( "mcps  - " ) ;
			_settextcolor(11) ;
			_outtext( "set S-I-N MCPPS to same step (asks for level)\n" ) ;
			_settextcolor(15) ;
			_outtext( "init  - " ) ;
			_settextcolor(11) ;
			_outtext( "set all PSs to level 0 (VfPS to level 128) \n\n" ) ;
			_settextcolor(15) ;
			_outtext( "enable high  - " ) ;
			_settextcolor(11) ;
			_outtext( "enable S-I-N MCPPSs and HPS;                0x8c0f\n" ) ;
			_settextcolor(15) ;
			_outtext( "enable low   - " ) ;
			_settextcolor(11) ;
			_outtext( "enable PM MCPPS, both E/QPSs, and VfPS;     0x0c0f\n" ) ;
			_settextcolor(15) ;
			_outtext( "enable mcps  - " ) ;
			_settextcolor(11) ;
			_outtext( "enable S-I-N MCPPSs (disables HPS)          0x8c07\n" ) ;
			_settextcolor(15) ;
			_outtext( "enable pm    - " ) ;
			_settextcolor(11) ;
			_outtext( "enable PM MCPPS and E/QPS (disables others) 0x0c03\n" ) ;
			_settextcolor(15) ;
			_outtext( "enable hps [or vfps, or start, ...] - " ) ;
			_settextcolor(11) ;
			_outtext( "disables all others!\n" ) ;
			_settextcolor(15) ;
			_outtext( "disable high - " ) ;
			_settextcolor(11) ;
			_outtext( "disable S-I-N MCPPSs and HPS                0x8c00\n" ) ;
			_settextcolor(15) ;
			_outtext( "disable low  - " ) ;
			_settextcolor(11) ;
			_outtext( "disable PMMCPPS, both E/QPSs, and VfPS;     0x0c00\n\n" ) ;
			_settextcolor(15) ;
			_outtext( "start - " ) ;
			_settextcolor(11) ;
			_outtext( "set Start MCPPS step (asks for level);     0x8800 + level\n" ) ;
			_settextcolor(15) ;
			_outtext( "neut  - " ) ;
			_settextcolor(11) ;
			_outtext( "set Neutral MCPPS step (asks for level);   0x8900 + level\n" ) ;
			_settextcolor(15) ;
			_outtext( "ion   - " ) ;
			_settextcolor(11) ;
			_outtext( "set Ion MCPPS step (asks for level);       0x8a00 + level\n" ) ;
			_settextcolor(15) ;
			_outtext( "hps   - " ) ;
			_settextcolor(11) ;
			_outtext( "set HPS step (asks for level);             0x8b00 + level\n" ) ;
			_settextcolor(15) ;
			_outtext( "pmmcp - " ) ;
			_settextcolor(11) ;
			_outtext( "set PM MCPPS step (asks for level);        0x0800 + level\n" ) ;
			_settextcolor(15) ;
			_outtext( "pmeq  - " ) ;
			_settextcolor(11) ;
			_outtext( "set PM E/QPS step (asks for level);        0x0900 + level\n" ) ;
			_settextcolor(15) ;
			_outtext( "weq   - " ) ;
			_settextcolor(11) ;
			_outtext( "set WAVE E/QPS step (asks for level);      0x0a00 + level\n" ) ;
			_settextcolor(15) ;
			_outtext( "vfps  - " ) ;
			_settextcolor(11) ;
			_outtext( "set VfPS step (asks for level);            0x0b00 + level\n" ) ;
			_settextcolor(12) ;
			_outtext( "     Press <F1> for more text commands, <ESC> to return to program..." ) ;
		break ;

		case 3 :
			_settextposition(1,25) ;
			_settextcolor(15) ;
			_outtext( "ICARUS Text Commands - Page 2 of 2\n\n" ) ;
			_settextcolor(14) ;
			_outtext( "     These commands may be entered after runtime option 'c'\n\n" ) ;
			_settextcolor(15) ;
			_outtext( "neutral preamp on - " ) ;
			_settextcolor(11) ;
			_outtext( "Neutral preamp on alone                 0x8301\n" ) ;
			_settextcolor(15) ;
			_outtext( "ion preamp on     - " ) ;
			_settextcolor(11) ;
			_outtext( "Ion preamp on alone                     0x8302\n" ) ;
			_settextcolor(15) ;
			_outtext( "both preamps on   - " ) ;
			_settextcolor(11) ;
			_outtext( "both preamps on                         0x8303\n" ) ;
			_settextcolor(15) ;
			_outtext( "pmthresh          - " ) ;
			_settextcolor(11) ;
			_outtext( "set threshold (asks for level);  0x0f00 + level\n" ) ;
			_settextcolor(15) ;
			_outtext( "cal ion           - " ) ;
			_settextcolor(11) ;
			_outtext( "sends 0x8eff, 0x8302, 0x8d0e, and 0x8f15 \n" ) ;
			_settextcolor(15) ;
			_outtext( "cal neutral       - " ) ;
			_settextcolor(11) ;
			_outtext( "sends 0x8eff, 0x8301, 0x8d0a, and 0x8f05 \n" ) ;
			_settextcolor(15) ;
			_outtext( "cal pm            - " ) ;
			_settextcolor(11) ;
			_outtext( "sends 0x0eff, 0x0f00, and 0x0d0a \n" ) ;
			_settextcolor(15) ;
			_outtext( "cal off           - " ) ;
			_settextcolor(11) ;
			_outtext( "sends 0x0d00, 0x8d00, and 0x8303\n\n" ) ;
			_settextcolor(12) ;
			_outtext( "     Press <F1> for more HELP, <ESC> to return to program..." ) ;
		break ;

		default :
			printf( "\a") ;
		break ;
	}
}
