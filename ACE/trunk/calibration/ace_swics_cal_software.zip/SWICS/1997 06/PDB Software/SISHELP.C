/* *********************************************************************

	SisHelp.C - Help file for the SISYPHUS software.

   pdb : 27-Jun-95
			28-Mar-96

   ********************************************************************* */

#include <stdio.h>
#include <graph.h>
#include <stdlib.h>

#define ESC ( (char)0x1b )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define DREAL double
#define BYTE unsigned char

SisHelp() {

	extern WORD		wHelp ;

	_clearscreen(_GCLEARSCREEN) ;

	switch( wHelp ) {
		case 1 :
			_settextposition(1,25) ;
			_settextcolor(15) ;
			_outtext( "SISYPHUS Runtime Options\n\n") ;
			_settextcolor(14);
			_outtext( "Simply press the key indicated (no need to press <enter> afterwards)\n\n" ) ;
			_settextcolor(15) ;
			_outtext( "<F1>  - " ) ;
			_settextcolor(11) ;
			_outtext( "Display this or the following help screens...\n" ) ;
			_settextcolor(15) ;
			_outtext( "  h   - " ) ;
			_settextcolor(11) ;
			_outtext( "Histogram of Energy or Tof\n" ) ;
			_settextcolor(9) ;
			_outtext( "         d - " ) ;
			_settextcolor(11) ;
			_outtext( "Display histogram early\n" ) ;
			_settextcolor(9) ;
			_outtext( "         b - " ) ;
			_settextcolor(11) ;
			_outtext( "change Binning of channels\n" ) ;
			_settextcolor(9) ;
			_outtext( "         x - " ) ;
			_settextcolor(11) ;
			_outtext( "rescale X axis\n" ) ;
			_settextcolor(9) ;
			_outtext( "         y - " ) ;
			_settextcolor(11) ;
			_outtext( "rescale Y axis\n" ) ;
			_settextcolor(9) ;
			_outtext( "         l - " ) ;
			_settextcolor(11) ;
			_outtext( "toggle between Log and Linear y-scale\n" ) ;
			_settextcolor(9) ;
			_outtext( "         s - " ) ;
			_settextcolor(11) ;
			_outtext( "Save histogram into an ascii file\n" ) ;	
			_settextcolor(9) ;
			_outtext( "        <esc> - " ) ;
			_settextcolor(11) ;
			_outtext( "clear histogram display\n" ) ;
			_settextcolor(15) ;
			_outtext( "  c   - " ) ;
			_settextcolor(11) ;
			_outtext( "Command sensor" ) ;
			_settextcolor(9) ;
			_outtext( "  (Press <F1> for list of commands...)\n" ) ;
			_settextcolor(15) ;
			_outtext( "  p   - " ) ;
			_settextcolor(11) ;
			_outtext( "toggle display of PHA data on/off\n" ) ;
			_settextcolor(15) ;
			_outtext( "  r   - " ) ;
			_settextcolor(11) ;
			_outtext( "Record a file" ) ;
			_settextcolor(9) ;
			_outtext( "  (Asks for file name and run title...)\n" ) ;
			_settextcolor(15) ;
			_outtext( "  s   - " ) ;
			_settextcolor(11) ;
			_outtext( "Stops recording a file (if not in histogram display mode)\n" ) ;
			_settextcolor(15) ;
			_outtext( "  a   - " ) ;
			_settextcolor(11) ;
			_outtext( "Refresh rate average collection\n" ) ;
			_settextcolor(15) ;
			_outtext( "1 (or 5 or 30) - " ) ;
			_settextcolor(11) ;
			_outtext( "Set HK update rate to 1 sec, 5 sec, or 30 secs\n" ) ;
			_settextcolor(15) ;
			_outtext( "  n   - " ) ;
			_settextcolor(11) ;
			_outtext( "New (clear) screen\n" ) ;
			_settextcolor(15) ;
			_outtext( "<ESC> - " ) ;
			_settextcolor(11) ;
			_outtext( "return to program from thishelp screen...\n" ) ;
			_settextcolor(15) ;
			_outtext( "  x   - " ) ;
			_settextcolor(11) ;
			_outtext( "eXit program.\n\n" ) ;
			_settextcolor(12) ;
			_outtext( "     Press <F1> for more HELP, <ESC> to return to program..." ) ;
		break ;

		case 2 :
			_settextcolor(15) ;
			_settextposition(1,25) ;
			_outtext( "SISYPHUS Text Commands - Page 1 of 2...\n\n" ) ;
			_settextcolor(14) ;
			_outtext( "     These commands may be entered after runtime option 'c'\n\n" ) ;
			_settextcolor(15) ;
			_outtext( "init            - " ) ;
			_settextcolor(11) ;
			_outtext( "set all PSs to level 0 (and disables); all dets on, ... \n" ) ;
			_settextcolor(15) ;
			_outtext( "enable high     - " ) ;
			_settextcolor(11) ;
			_outtext( "enable DPPS and PAPS to 30kV;          \n" ) ;
			_settextcolor(15) ;
			_outtext( "enable paps     - " ) ;
			_settextcolor(11) ;
			_outtext( "enable PAPS to 30kV range (disables DPPS)     \n" ) ;
			_settextcolor(15) ;
			_outtext( "enable 15kV     - " ) ;
			_settextcolor(11) ;
			_outtext( "enable PAPS to 15kV range (disables DPPS)     \n" ) ;
			_settextcolor(15) ;
			_outtext( "enable dpps     - " ) ;
			_settextcolor(11) ;
			_outtext( "enable DPPS  (disables PAPS)                 \n" ) ;
			_settextcolor(15) ;
			_outtext( "enable mcps     - " ) ;
			_settextcolor(11) ;
			_outtext( "enable MCPPS (no voltage yet);         \n" ) ;
			_settextcolor(15) ;
			_outtext( "paps            - " ) ;
			_settextcolor(11) ;
			_outtext( "set PAPS to a particular step (asks for level)\n" ) ;
			_settextcolor(15) ;
			_outtext( "dpps            - " ) ;
			_settextcolor(11) ;
			_outtext( "set DPPS to a particular step (asks for level)\n" ) ;
			_settextcolor(15) ;
			_outtext( "mcps            - " ) ;
			_settextcolor(11) ;
			_outtext( "set MCPPS to a particular step (asks for level)\n" ) ;
			_settextcolor(15) ;
			_outtext( "disable all     - " ) ;
			_settextcolor(11) ;
			_outtext( "disable PAPS and DPPS                    \n" ) ;
			_settextcolor(15) ;
			_outtext( "disable mcps    - " ) ;
			_settextcolor(11) ;
			_outtext( "disable MCPPS  \n" ) ;
			_settextcolor(15) ;
			_outtext( "all dets on     - " ) ;
			_settextcolor(11) ;
			_outtext( "turn on all 4 SSDs                    \n" ) ;
			_settextcolor(15) ;
			_outtext( "all dets off    - " ) ;
			_settextcolor(11) ;
			_outtext( "turn off all 4 SSDs                    \n" ) ;
			_settextcolor(15) ;
			_outtext( "main on         - " ) ;
			_settextcolor(11) ;
			_outtext( "turn on only the MAIN SSDs           \n" ) ;
			_settextcolor(15) ;
			_outtext( "aux on          - " ) ;
			_settextcolor(11) ;
			_outtext( "turn on only the auxiliary (p/He) SSD    \n" ) ;
			_settextcolor(15) ;
			_outtext( "mss1 on         - " ) ;
			_settextcolor(11) ;
			_outtext( "turn on MSS1; (can also type mss2 or mss3)\n" ) ;
			_settextcolor(15) ;
			_outtext( "tac slope -10%  - " ) ;
			_settextcolor(11) ;
			_outtext( "set tac slope to -10%; (also -5%, 0%, +5%, +10% )\n" ) ;
			_settextcolor(15) ;
			_outtext( "high thresh     - " ) ;
			_settextcolor(11) ;
			_outtext( "set aux detector threshold high\n" ) ;
			_settextcolor(15) ;
			_outtext( "e or t          - " ) ;
			_settextcolor(11) ;
			_outtext( "set trigger condition to E .or. T\n" ) ;
			_settextcolor(15) ;
			_outtext( "e and t         - " ) ;
			_settextcolor(11) ;
			_outtext( "set trigger condition to E .and. T\n" ) ;
			_settextcolor(15) ;
			_outtext( "e only          - " ) ;
			_settextcolor(11) ;
			_outtext( "set trigger condition to E only\n" ) ;
			_settextcolor(15) ;
			_outtext( "t only          - " ) ;
			_settextcolor(11) ;
			_outtext( "set trigger condition to T only\n\n" ) ;
			_settextcolor(12) ;
			_outtext( "     Press <ESC> to return to program..." ) ;
		break ;

		default :
			printf( "\a") ;
		break ;
	}
}
