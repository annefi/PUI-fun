#include <stdio.h>

#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define BYTE unsigned char

FILE *fp ;

main( int argc, char *argv[] ) {

	WORD	i, c ;
	BYTE	szName[40]="", szTitle[70]="", szDummy[80]="" ;
	int	iX, iY ;

	printf( "%i   %s   %s\n\n", argc, argv[0], argv[1] ) ;
	if( (fp = fopen( argv[1], "r+t" ) ) == NULL ) {
		printf( "Cannot open file %s\n", argv[1] ) ;
		exit(-1) ;
	}
	fscanf( fp, "%s\n", szName ) ;
	printf( "Name: %s\n", szName ) ;
	fscanf( fp, "%s", szTitle ) ;
	printf( "Title: %s\n", szTitle ) ;
	fscanf( fp, "%s", szDummy ) ;
	printf( "Dummy: %s\n", szDummy ) ;

}
