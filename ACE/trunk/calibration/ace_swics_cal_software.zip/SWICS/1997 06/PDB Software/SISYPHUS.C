/* ******************************************************************

	SISYPHUS.C - Driver routine for testing ACE/SWICS
					 using Fred Wire's DPU Simulator card.

		*  To compile and link this software:                           *
		*     qcl /c sisyphus.c                                         *
		*     qcl /c sishist.c                                          *
		*     qcl /c sisdots.c                                          *
		*     qcl /c sishelp.c                                          *
		*     qcl /c cascom.c                                           *
		*  qlink /stack:32000 sisyphus+sishist+sisdots+sishelp+cascom;  *

	pdb : 17-Jul-93   (as ICARUS.C)
	fcw : 16-Oct-95   Changed pharead for swics pha format
	fcw : 18-Oct-95   Fixed masking bug in pharead
							Modified fRATES for SWICS data
	pdb : 20-Nov-95
			21-Nov-95   (on plane from CH)
			22-Nov-95
			12-Dec-95
	fcw : 13 feb 96   (added assembly driver for ramp test with EG&G9650)
		 : 15 feb 96   (added code to set baud rate to 19200)
		 : 18 mar 96   (added code in hk read for dual range DPPS )
		 : 20 mar 96   (fixed code in hk read for dual range DPPS )
	pdb : 28-Mar-96   DV cycling? More help.
			03-Apr-96

 * ***************************************************************** */

#include <stdio.h>
#include <string.h>
#include <graph.h>
#include <math.h>
#include <io.h>
#include <dos.h>
#include <time.h>

#define ESC ((char) 0x1B )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define DREAL double
#define BYTE unsigned char
#define getrandom( min, max ) ((rand() % (int)(((max)+1) - (min))) + (min))

DWORD dwCounts[1200], dwYmaxNew=0 ;
WORD  near wHK, near wTOF, near wID, near wEGY, wMass, wMPQ, wSource=0,
		near wSecReq=1, near wCmd, near wSec, near wSim=0, wLap=0,
		wLastSec=0, wLog=0, wDont=0, wIDReq=0, wHelp=0, wDisplay=0, wParam,
		wPlow, wPhigh, wPulser, wCharge=1, wPAPS=0, wDVSStep=0, wEBeam=0, wMCPs=0,
		wTlow, wThigh, wElow, wEhigh, wXlow=0, wXhigh=1100, wXinc=1, wDots=0,
		near wFSR, near wDCR, near wTCR, near wMSS, near wPROT, near wALFA ;
int   iHead=140, iPHA=6, iRates=22, iHK=42, iCmds=100 ;
BYTE  szTitle[70], szName[40]="", *szTrends[32], szID[3]="ACE",
		szBegTime[10], szDate[10], szType[10], szTime[10] ;
DREAL drMass=0., drMpQ=0., drEpQ=0., drTOF=0., drEGY=0., drPAPS=0.,
		drMlow=0., drMpQlow=0., drMhigh=1000., drMpQhigh=1000.,
		drPAPSLimit=16500. ;

void near fPHARead() ;
void near fCommand() ;
void near fRates() ;
void near fTime() ;
void near fSetCOM2() ;
void near fSetTof() ;
void SisHist() ;
void SisDots() ;
void SisHelp() ;

FILE *fp, *h, *tfile, *cFile ;

int main( int argc, char *argv[] ) {

	DWORD dwRecorded=0, dwEvReq=0, dwHistCtr=0,
			dwFSRtot=0, dwDCRtot=0, dwTCRtot=0, dwMSStot=0, dwPROTtot=0,
			dwALFAtot=0 ;

	int   iDVS=-1, iDVSCalc=-1 ;

	WORD  i, j, d='n', c, wEvents=0, wHist=0, wRates=0, wCmdNum=0,
			wGndHK[12], wVfHK[10], wHKcvt, wLev, wCalVoltage, wCalLev,
			wPHACtr=0, wRecord=0, wFile=0, wRefresh=0, wParam=0, wXpos=0,
			wPHA=1, wBeep=0, wHilite=50, wNow=0, wReadouts=1, wDVCycle=0,
			wMCP=0xd000, wNoPHA=0, wDone=0, wDVlow=0, wDVhigh=0,
			wDVreads=0 ;

	REAL  rHK, rAvFSR=0., rAvDCR=0., rAvTCR=0., rAvMSS=0., rAvPROT=0.,
			rAvALFA=0., rDCRFSR=-1., rTCRDCR=-1., rRatCnt=0., rXpos=0.,
			rPHACnt=0., rAvEGY=0., rAvTOF=0., rAvID=0., rTCRMSS=0.,
			rTCRFSR=0., rAvMass=0., rAvMpQ=0.,
			rEGYCnt=0., rTOFCnt=0., rMassCnt=0., rMpQCnt=0.,
			rThmin, rThmax, rThinc, rBmin, rBmax, rBinc, rEmin, rEmax, rEinc,
			rAmin, rAmax, rAinc, rZmin, rZmax, rZinc, a, b, z, th, e,
			rGndCvt[12]={ 28./200., 20./200., 10./200., 5./200., -5./200.,
					1., 1., 1., 2., 1./5.1, 1./1.89, 1./1.65 },
			rGndOff[12]={ 0., 0., 0., 0., 0.,
					0., 0., 0., 0., 0., 0., 38./1.65 },
			rGHKLow[12]={ 27., 20., 9.5, 4.5, -5.5,
					0., 0., 0., 0.,   0., 0., 0. },
			rGHKHigh[12]={ 32., 23., 10.5, 5.5, -4.5,
					255., 255., 255., 255., 255., 255., 255. },
			rVHKLow[10]={ 0., 0., 0., 4.5, 0., -5.5, 0., 0., 0., 0. },
			rVHKHigh[10]={ 255., 255., 255., 5.5, 255.,
					-4.5, 255., 3000., 28000., 9000. },
			rVfCvt[10]={ 1., .6714, .6714, .048, 1.96, .039, 1.98, 39.05, 150., 6.25 },
			rVfOff[10]={ 0., -128., -128., -6.16, -250.31, -11.12, -253.06, -4943.7, 0., 0. } ;

	BYTE  szText[80]="", szCommand[80], bYorN, *szString,
			szDType[10]="", szLev[5], g, szAlpha[20]="", szBeta[20]="",
			szTheta[20]="", szZeta[20]="", szEIon[20]="", bMorA,
			szCASYMS[120]="", szBuffer[50]="",
			szBlank[80]="                                                      ",
			szText2[80]="", szText3[80]="", szCmd[2]="CD", szGI[2]="GI",
			szHist[40]="", szHK[2]="HK", szRR[2]="RR", szPH[2]="PH",

			*szGndHK[12] = { "+28V      :%5.1f (%2x)",
				"20V AC    :%5.1f (%2x)", "+10V      :%5.1f (%2x)",
				"+ 5V      :%5.1f (%2x)", "- 5V      :%5.1f (%2x)",
				"                       ",
				"T1        :%5.1f (%2x)", "T2        :%5.1f (%2x)",
				"+28I (Pri):%5.1f (%2x)", "+28I (Sec):%5.1f (%2x)",
				"+ 5I      :%5.1f (%2x)", "20I AC    :%5.1f (%2x)" },

			*szVfHK[10] = { "Sync : %5d (%2x)", "T1   : %5.1f (%2x)",
				"T2   : %5.1f (%2x)", "+ 5V : %5.1f (%2x)", "+ 5I : %5.1f (%2x)",
				"- 5V : %5.1f (%2x)", "- 5I : %5.1f (%2x)", "MCPPS: %5d (%2x)",
				"PAPS : %5d (%2x)", "DPPS : %5d (%2x)" },

			szPHARec[20]="",
			szOldCommand1[20]="", szOldCommand2[20]="", szOldCommand3[20]="",
			szOldCommand4[20]="", szOldCommand5[20]="",
			*szLog[5] = { "                    ", "                    ",
			"                    ", "                    ",
			"                    " } ;

	struct   diskfree_t dinfo ;

/* set pha bit counter in hardware */
	_asm{
		mov   dx, 0x22e
		mov   al, 22
		out   (dx), al
	}

/* set baud rate to 19200 for EG&G9650 delay generator */
	fSetCOM2() ; 

	_clearscreen(_GCLEARSCREEN) ;
	if( argc > 1 ) wSim = 1 ;
	srand( (unsigned)time( NULL ) ) ;

/* ------------------ Main Loop ---------------------------------- */

	_strtime( szBegTime ) ;
	_strdate( szDate ) ;
	while( 1 ) {
		fflush( stdin ) ;
		if( kbhit() ) {
			c = getch() ;
			switch( tolower(c) ) {

/* ---------------- Function keys - Help or DV Cycling ----------- */

			case 0 :
				c = getch() ;
				if( c == 0x3b ) {                // <F1>
					wHelp++ ;
					if( wHelp>2 ) wHelp = 1 ;
					SisHelp() ;
				}
				else if( c == 0x3f ) {           // <F5>
					wDVCycle = 1 ;
					_clearscreen(_GCLEARSCREEN) ;
					fflush( stdin ) ;
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Enter low, high dpps step, and # readouts/step: " ) ;
					scanf( "%d, %d, %d", &wDVlow, &wDVhigh, &wReadouts ) ;
					iDVS = wDVlow - 1 ;
					_clearscreen(_GCLEARSCREEN) ;
					wRefresh = 1 ;
				}
			break ;

/* ------------------ Watchdog ---------------------------------- */

			case 'w' :
					fflush( stdin ) ;
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					sprintf( szText, "Current watchdog limit for PAPS is: %f", drPAPSLimit ) ;
					_outtext( szText ) ;
					_settextposition(25,1) ;
					_outtext( szBlank ) ;
					_settextposition(25,1) ;
					_outtext( "Enter new limit: " ) ;
					scanf( "%f", &drPAPSLimit ) ;
			break ;

/* ------------------ Histogram --------------------------------- */

			case 'h' :
				if( !wDisplay ) {
					_clearscreen(_GCLEARSCREEN) ;
					wHist = 1 ;
					dwHistCtr = 0 ;
					fflush( stdin ) ;

					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Type of histogram? [e, t, m, q, or r(amp)]: " ) ;
					gets( szType ) ;

					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Which SSD? [1, 2, 3, U, or X (don't care)]: " ) ;
					gets( szDType ) ;
					if( !strncmp( strlwr(szDType), "1", 1 ) ) {
						wIDReq = 1 ;
					}
					else if( !strncmp( strlwr(szDType), "2", 1 ) ) {
						wIDReq = 2 ;
					}
					else if( !strncmp( strlwr(szDType), "3", 1 ) ) {
						wIDReq = 3 ;
					}
					else if( !strncmp( strlwr(szDType), "u", 1 ) ) {
						wIDReq = 0 ;
					}
					else if( strncmp( strlwr(szDType), "x", 1 ) ) {
						printf( "Invalid entry.  Try again.\n" ) ;
					}
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Number of events? [0=all]: " ) ;
					scanf( "%ld", &dwEvReq ) ;
					if( !dwEvReq ) dwEvReq = 1000000. ;
					fflush( stdin ) ;
					if( !strncmp( strlwr(szType), "e", 1 ) ) {
						wSource = 0 ;
						_settextposition( 24,1 ) ;
						_outtext( szBlank ) ;
						_settextposition( 24,1 ) ;
						_outtext( "TOF window - Enter TOFlow, TOFhigh [0..1100]: " ) ;
						scanf( "%d, %d", &wTlow, &wThigh ) ;
						fflush( stdin ) ;
						wXlow = 0 ;
						wXhigh = 300 ;
					}
					if( !strncmp( strlwr(szType), "t", 1 ) ) {
						wSource = 1 ;
						_settextposition( 24,1 ) ;
						_outtext( szBlank ) ;
						_settextposition( 24,1 ) ;
						_outtext( "Energy window - Enter Elow, Ehigh [0..300]: " ) ;
						scanf( "%d, %d", &wElow, &wEhigh ) ;
						fflush( stdin ) ;
						wXlow = 0 ;
						wXhigh = 1100 ;
					}
					if( !strncmp( strlwr(szType), "r", 1 ) ) {
						wSource = 1 ;
						_settextposition( 24,1 ) ;
						_outtext( szBlank ) ;
						_settextposition( 24,1 ) ;
						_outtext( "Energy window - Enter Elow, Ehigh [0..300]: " ) ;
						scanf( "%d, %d", &wElow, &wEhigh ) ;
						fflush( stdin ) ;
						_settextposition( 24,1 ) ;
						_outtext( szBlank ) ;
						_settextposition( 24,1 ) ;
						_outtext( "Pulser range - Enter Plow, Phigh [0..2000]: " ) ;
						scanf( "%d, %d", &wPlow, &wPhigh ) ;
						fflush( stdin ) ;
						wXlow = 0 ;
						wXhigh = 1100 ;
						wPulser = wPlow ;
						wTOF = wPulser ;
						fSetTof() ;
					}
					if( !strncmp( strlwr(szType), "m", 1 ) ) {
						wSource = 2 ;
						_settextposition( 24,1 ) ;
						_outtext( szBlank ) ;
						_settextposition( 24,1 ) ;
						_outtext( "M/Q window - Enter MpQlow, MpQhigh [0..1100]: " ) ;
						scanf( "%f, %f", &drMpQlow, &drMpQhigh ) ;
						fflush( stdin ) ;
						wXlow = 0 ;
						wXhigh = 1100 ;
					}
					if( !strncmp( strlwr(szType), "q", 1 ) ) {
						wSource = 3 ;
						_settextposition( 24,1 ) ;
						_outtext( szBlank ) ;
						_settextposition( 24,1 ) ;
						_outtext( "Mass window - Enter Mlow, Mhigh [0..300]: " ) ;
						scanf( "%f, %f", &drMlow, &drMhigh ) ;
						fflush( stdin ) ;
						wXlow = 0 ;
						wXhigh = 1100 ;
					}
					_clearscreen(_GCLEARSCREEN) ;
					wRefresh = 1 ;
				}
			break ;

/* ------------------------ Dotplots ---------------------------- */

			case 'd' :
				if( !wHist ) {
					_clearscreen(_GCLEARSCREEN) ;
					wDots = 1 ;
					fflush( stdin ) ;

					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Type of dotplot? [e or m]: " ) ;
					gets( szType ) ;

					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Which SSD? [1, 2, 3, U, or X (don't care)]: " ) ;
					gets( szDType ) ;
					if( !strncmp( strlwr(szDType), "1", 1 ) ) {
						wIDReq = 1 ;
					}
					else if( !strncmp( strlwr(szDType), "2", 1 ) ) {
						wIDReq = 2 ;
					}
					else if( !strncmp( strlwr(szDType), "3", 1 ) ) {
						wIDReq = 3 ;
					}
					else if( !strncmp( strlwr(szDType), "u", 1 ) ) {
						wIDReq = 0 ;
					}
					else if( !strncmp( strlwr(szDType), "x", 1 ) ) {
						wIDReq = 4 ;
					}
					else {
						printf( "Invalid entry.  Try again.\n" ) ;
					}
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					fflush( stdin ) ;
					_clearscreen(_GCLEARSCREEN) ;
					wRefresh = 1 ;
				}
				else {
					wNow = 1 ;
				}
			break ;

			case 'e' :
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
				_settextposition(24,1) ;
				_outtext( "Enter item to enhance: " ) ;
				scanf( "%d", &wHilite ) ;
			break ;

			case 'p' :
				if( wPHA ) wPHA = 0 ;
				else wPHA = 1 ;
			break ;

			case '1' :
				wSecReq = 1 ;
			break ;

			case '3' :
				wSecReq = 30 ;
			break ;

			case '5' :
				wSecReq = 5 ;
			break ;

/* ---------------------- Commands ------------------------------- */

			case 'c' :
				_setvideomode(_DEFAULTMODE) ;
				_settextcolor(12) ;
				_settextposition(1,32) ;
				_outtext( szOldCommand1 ) ;
				_settextposition(2,32) ;
				_outtext( szOldCommand2 ) ;
				_settextposition(3,32) ;
				_outtext( szOldCommand3 ) ;
				_settextposition(4,32) ;
				_outtext( szOldCommand4 ) ;
				_settextposition(5,32) ;
				_outtext( szOldCommand5 ) ;

				fflush( stdin ) ;
				_settextcolor(15) ;
				_settextposition(7,1) ;
				_outtext( "Enter command string: " ) ;
				gets( szCommand ) ;

				if( !strncmp( strlwr(szCommand), "enable paps", 11 ) )
					wCmd = 0x0c01 ;
				else if( !strncmp( strlwr(szCommand), "disable all", 11 ) )
					wCmd = 0x0c00 ;
				else if( !strncmp( strlwr(szCommand), "enable 15kv", 11 ) )
					wCmd = 0x0c03 ;
				else if( !strncmp( strlwr(szCommand), "enable dpps", 11 ) )
					wCmd = 0x0c04 ;
				else if( !strncmp( strlwr(szCommand), "enable high", 11 ) )
					wCmd = 0x0c05 ;
				else if( !strncmp( strlwr(szCommand), "paps", 4 ) ) {
					printf( "Enter PAPS level (0..255 decimal): " ) ;
					scanf( "%d", &wLev ) ;
					itoa( wLev, szLev, 10 ) ;
					strcat( szCommand, " " ) ;
					strcat( szCommand, szLev ) ;
					wCmd = 0x0800 + wLev ;
				}
				else if( !strncmp( strlwr(szCommand), "dpps", 4 ) ) {
					printf( "Enter DPPS level (0..152 decimal): " ) ;
					scanf( "%d", &wLev ) ;
					itoa( wLev, szLev, 10 ) ;
					strcat( szCommand, " " ) ;
					strcat( szCommand, szLev ) ;
					if( wLev > 127 ) wLev += 102 ;
					if( wLev > 255 ) break ;
					iDVS = wLev ;
					wCmd = 0x0900 + wLev ;
				}
				else if( !strncmp( strlwr(szCommand), "tac slope -10%", 14 ) )
					wCmd = 0x900a ;
				else if( !strncmp( strlwr(szCommand), "tac slope -5%", 13 ) )
					wCmd = 0x900b ;
				else if( !strncmp( strlwr(szCommand), "tac slope 0%", 11 ) )
					wCmd = 0x9008 ;
				else if( !strncmp( strlwr(szCommand), "tac slope +5%", 13 ) )
					wCmd = 0x9009 ;
				else if( !strncmp( strlwr(szCommand), "tac slope +10%", 14 ) )
					wCmd = 0x900e ;
				else if( !strncmp( strlwr(szCommand), "all dets on", 11 ) )
					wCmd = 0x8001 ;
				else if( !strncmp( strlwr(szCommand), "all dets off", 12 ) )
					wCmd = 0x800e ;
				else if( !strncmp( strlwr(szCommand), "main on", 7 ) )
					wCmd = 0x8000 ;
				else if( !strncmp( strlwr(szCommand), "aux on", 6 ) )
					wCmd = 0x800f ;
				else if( !strncmp( strlwr(szCommand), "mss1 on", 7 ) )
					wCmd = 0x8006 ;
				else if( !strncmp( strlwr(szCommand), "mss2 on", 7 ) )
					wCmd = 0x800a ;
				else if( !strncmp( strlwr(szCommand), "mss3 on", 7 ) )
					wCmd = 0x800c ;
				else if( !strncmp( strlwr(szCommand), "high thresh", 11 ) )
					wCmd = 0xc002 ;
				else if( !strncmp( strlwr(szCommand), "e or t", 6 ) )
					wCmd = 0xe000 ;
				else if( !strncmp( strlwr(szCommand), "e and t", 7 ) )
					wCmd = 0xe004 ;
				else if( !strncmp( strlwr(szCommand), "e only", 6 ) )
					wCmd = 0xe008 ;
				else if( !strncmp( strlwr(szCommand), "t only", 6 ) )
					wCmd = 0xe00c ;
				else if( !strncmp( strlwr(szCommand), "init", 4 ) ) {
					wCmd = 0x0800 ;
					printf( "Command %x ready to go, \n", wCmd ) ;
					fCommand() ;
					wCmd = 0x0900 ;
					printf( "Command %x ready to go, \n", wCmd ) ;
					fCommand() ;
					wCmd = 0x0C00 ;
					printf( "Command %x ready to go, \n", wCmd ) ;
					fCommand() ;
					wCmd = 0x8001 ;
					printf( "Command %x ready to go, \n", wCmd ) ;
					fCommand() ;
					wCmd = 0x9008 ;
					printf( "Command %x ready to go, \n", wCmd ) ;
					fCommand() ;
					wCmd = 0xA000 ;
					printf( "Command %x ready to go, \n", wCmd ) ;
					fCommand() ;
					wCmd = 0xB000 ;
					printf( "Command %x ready to go, \n", wCmd ) ;
					fCommand() ;
					wCmd = 0xC000 ;
					printf( "Command %x ready to go, \n", wCmd ) ;
					fCommand() ;
					wCmd = 0xD000 ;
					printf( "Command %x ready to go,\n", wCmd ) ;
					fCommand() ;
					wCmd = 0xE000 ;
					printf( "Command %x ready to go,\n", wCmd ) ;
					fCommand() ;
					wCmd = 0xF000 ;
				}
				else if( !strncmp( strlwr(szCommand), "enable mcpps", 10 ) ) {
					wMCP = 0xd008 ;
					break ;
				}
				else if( !strncmp( strlwr(szCommand), "disable mcpps", 11 ) ) {
					wMCP = 0xd000 ;
					wCmd = wMCP ;
				}
				else if( !strncmp( strlwr(szCommand), "mcpps", 3 ) ) {
					if( wMCP != 0xd008 ) {
						printf( "MCPPS must be enabled first.\a\n" ) ;
						break ;
					}
					else {
						printf( "Enter MCPPS level (0..7): " ) ;
						scanf( "%d", &wLev ) ;
						itoa( wLev, szLev, 10 ) ;
						strcat( szCommand, " " ) ;
						strcat( szCommand, szLev ) ;
						wCmd = wMCP + wLev ;
					}
				}
				else if( !strncmp( strlwr(szCommand), "0x", 2 ) ) {
					wCmd = (WORD)strtoul( szCommand, szString, 0 ) ;
				}
				else {
					printf( "\a\a" ) ;
					_clearscreen(_GCLEARSCREEN) ;
					break ;
				}
				printf( "Command %x ready to go.  Okay?\n", wCmd ) ;
				bYorN = getch() ;

				if( tolower(bYorN) == 'y' ) {
					fCommand() ;
					strcpy( szOldCommand5, szOldCommand4 ) ;
					strcpy( szOldCommand4, szOldCommand3 ) ;
					strcpy( szOldCommand3, szOldCommand2 ) ;
					strcpy( szOldCommand2, szOldCommand1 ) ;
					strcpy( szOldCommand1, szCommand ) ;
				}

				_clearscreen(_GCLEARSCREEN) ;
				wRefresh = 1 ;

			break ;

/* ------------------------ Clear screen ------------------------- */

			case 'n' :
				_clearscreen(_GCLEARSCREEN) ;
				rAvEGY=rAvTOF=rAvID=rAvMass=rAvMpQ=rPHACnt=rEGYCnt=rTOFCnt=rMassCnt=rMpQCnt = 0. ;
			break ;

/* ---------------------- Control CASYMS -------------------------- */

			case 'g' :
				_setvideomode(_DEFAULTMODE) ;
				_settextcolor(15) ;
				_settextposition(1,30) ;
				_outtext( "CASYMS CONTROL" ) ;
				fflush( stdin ) ;
				_settextcolor(10) ;
				while(!wDone) {
					_clearscreen(_GCLEARSCREEN) ;
					_settextposition(1,30) ;
					_settextcolor(15) ;
					_outtext( "MANUAL CONTROL OF CASYMS" ) ;
					com1_ini() ;
					fflush(stdin) ;
					_settextcolor(10) ;
					_settextposition(5,1) ;
					_outtext( "Change Alpha, Beta, Theta, Zeta, E, or eXit? [a/b/t/z/e/x]: " ) ;
					g = getch() ;
					switch( tolower(g) ) {
						case 'a' :              // alpha
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change alpha to what value? [eg. 5.3]: " ) ;
							gets( szAlpha ) ;
							move_TT_alpha( szAlpha ) ;
						break ;
						case 'b' :              // beta
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change beta to what value? [eg. 5.3]: " ) ;
							gets( szBeta ) ;
							move_TT_beta( szBeta ) ;
						break ;
						case 't' :              // theta
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change theta to what value? [eg. 5.3]: " ) ;
							gets( szTheta ) ;
							move_TT_theta( szTheta ) ;
						break ;
						case 'z' :              // zeta
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change zeta to what value? [eg. 5.3]: " ) ;
							gets( szZeta ) ;
							move_TT_z( szZeta ) ;
						break ;
						case 'e' :              // ion energy
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change ion energy to what value? [eg. 35.21]: " ) ;
							gets( szEIon ) ;
							set_ion_energy( szEIon ) ;
						break ;
						case 'x' :              // exit
							wDone = 1 ;
						break ;
					}
				}

// read CASYMS information

				read_BS_Fara() ;
				read_Chamb_pT() ;
				read_source() ;
				BS_wait() ;
				_strtime( szTime ) ;
				send_str_vax( szTime ) ;
				_clearscreen(_GCLEARSCREEN) ;
				_settextposition(25,1) ;
				_settextcolor(1) ;
				sprintf( szCASYMS, "a:%s b:%s th:%s z:%s E:%s @:%s",
						szAlpha, szBeta, szTheta, szZeta, szEIon, szTime ) ;
				_outtext( szCASYMS ) ;
				wDone = 0 ;

			break ;

/* -------------------- Refresh rate averages --------------------- */

			case 'a' :
				wRefresh = 1 ;
				rAvEGY=rAvTOF=rAvID=rAvMass=rAvMpQ=rPHACnt=rEGYCnt=rTOFCnt=rMassCnt=rMpQCnt = 0. ;
			break ;

/* ---------------- Toggle log/linear display -------------------- */

			case 'l' :
				_setvideomode(_DEFAULTMODE) ;
				if( wLog ) wLog = 0 ;
				else  wLog = 1 ;
				wDisplay = 0 ;
				SisHist() ;
			break ;

/* ---------------- Save histogram in ascii file ----------------- */

			case 's' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition(24,1) ;
					_outtext( "Enter file name for histogram data: " ) ;
					gets( szHist ) ;
					h = fopen( szHist, "w+" ) ;
					fprintf( h, "%s\n", szHist ) ;
					for( i=0; i<1200; i++ )
						fprintf( h, "%4d   %7ld\n", i, dwCounts[i] ) ;
					printf( "Histogram recorded.\a" ) ;
					wDisplay = 0 ;
					SisHist() ;
				}
				else {
					if( wFile ) {
						wFile = 0 ;
						wRecord = 0 ;
						d = 'n' ;
						fclose( fp ) ;
					}
				}
			break ;

/* ---------------- Toggle recording on/off ------------------- */

			case 'r' :
				if( !wDisplay ) {
					if( wRecord ) wRecord = 0 ;
					else {
						wRecord = 1 ;
						if( !wFile ) {
							dwRecorded = 0. ;
							wFile = 1 ;
							_clearscreen(_GCLEARSCREEN) ;
							while( tolower(d) != 'y' ) {
								_settextposition(24,1) ;
								_outtext( szBlank ) ;
								_settextposition(25,1) ;
								_outtext( szBlank ) ;
								fflush( stdin ) ;
								_settextposition(24,1) ;
								_outtext( "Enter file name: " ) ;
								gets( szName ) ;
								if( !access( szName, 0 ) ) {
									printf( "%s already exists.  Overwrite? [y/n]: ", szName ) ;
									d = getch() ;
								}
								else d = 'y' ;
							}
							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "Beam Energy (in volts): " ) ;
							scanf( "%d", &wEBeam ) ;

							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "Enter species: " ) ;
							gets( szTitle ) ;

							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "Charge state: " ) ;
							scanf( "%d", &wCharge ) ;
							fflush(stdin) ;

							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "PAPS (in volts): " ) ;
							scanf( "%d", &wPAPS ) ;

							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "DV step: " ) ;
							scanf( "%d", &wDVSStep ) ;

							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "MCP level: " ) ;
							scanf( "%d", &wMCPs ) ;

							fp = fopen( szName, "w+b" ) ;
							if( fwrite( szID, 3, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( &wEBeam, 2, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( &wPAPS, 2, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( &wDVSStep, 2, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( &wMCPs, 2, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( &wCharge, 2, 1, fp ) != 1 ) exit(-2) ;

							if( fwrite( szName, 40, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( szTitle, 70, 1, fp ) != 1 ) exit(-2) ;
							if( fwrite( szDate, 10, 1, fp ) != 1 ) exit(-2) ;
							_clearscreen(_GCLEARSCREEN) ;
							wRefresh = 1 ;
						}
					}
				}
			break ;

/* -------------- Exit or Scale histogram X axis ------------------ */

			case 'x' :
				if( !wDisplay ) {
					_clearscreen(_GCLEARSCREEN) ;
					printf( "Normal termination." ) ;
					exit(0) ;
				}
				else {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition(24,1) ;
					_outtext( "Enter new Xlow and Xhigh: " ) ;
					scanf( "%d, %d", &wXlow, &wXhigh ) ;
					wDisplay = 0 ;
					SisHist() ;
				}
			break ;

/* -------------- Scale histogram Y axis ------------------ */

			case 'y' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition(24,1) ;
					_outtext( "Enter new maximum Y value: " ) ;
					scanf( "%ld", &dwYmaxNew ) ;
					wDisplay = 0 ;
					SisHist() ;
				}
			break ;

/* ------------------- Change Channels/Bin ----------------------- */

			case 'b' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					_outtext( "Enter new channels/bin: " ) ;
					scanf( "%d", &wXinc ) ;
					wDisplay = 0 ;
					SisHist() ;
				}
			break ;

/* ------------------- Clear histogram or dotplot ------------------ */

			case ESC :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					wDots = 0 ;
					wDisplay = 0 ;
					dwHistCtr = 0 ;
					wXlow = 0 ;
					wXhigh = 1100 ;
					wXinc = 1 ;
					wNow = 0 ;
					for( i=0; i<1200; i++ )
						dwCounts[i] = 0 ;
					wRefresh = 1 ;
				}
				else if( wHelp ) {
					_setvideomode(_DEFAULTMODE) ;
					wHelp = 0 ;
				}
			break ;

			}       //switch
		}       //kbhit

/* ---------------------- DISPLAY DATA --------------------------- */

		if( !wDisplay && !wHelp ) {

			fTime() ;
			if( !(wSec%wSecReq) && (wSec != wLastSec) ) {
				wLastSec = wSec ;

				_dos_getdiskfree( 0, &dinfo ) ;
				_settextposition(25,18) ;
				_settextcolor(4) ;
				sprintf( szText, "%5.1f Mb free", (double)(((long)dinfo.avail_clusters *
						dinfo.sectors_per_cluster * dinfo.bytes_per_sector) / 1000000.) ) ;
				_outtext( szText ) ;

/* ---------------------- OLD COMMANDS --------------------------- */

				_settextcolor(7) ;
				_settextposition(3,41) ;
				_outtext( szOldCommand1 ) ;
				_settextposition(4,41) ;
				_outtext( szOldCommand2 ) ;
				_settextposition(5,41) ;
				_outtext( szOldCommand3 ) ;
				_settextposition(6,41) ;
				_outtext( szOldCommand4 ) ;
				_settextposition(7,41) ;
				_outtext( szOldCommand5 ) ;

/* --------------------- DV Cycling ----------------------------- */

				if( wDVCycle ) {
					wDVreads++ ;
					if( wDVreads == 1 ) {
						wLev = (unsigned)(iDVS + 1) ;
						if( wLev > wDVhigh ) {
							wDVreads = 0 ;
							wDVCycle = 0 ;
						}
						else {
							if( wLev > 127 ) wLev += 102 ;
							if( wLev > 255 ) break ;
							iDVS = wLev ;
							wCmd = 0x0900 + wLev ;
							fCommand() ;
						}
					}
					else if( wDVreads >= wReadouts ) {
						wDVreads = 0 ;
					}
				}

/* ---------------------- HOUSEKEEPING --------------------------- */

				_settextcolor(5) ;

				if( wRecord ) {
					if( fwrite( szCmd, 2, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( szOldCommand1, 20, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( szOldCommand2, 20, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( szOldCommand3, 20, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( szOldCommand4, 20, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( szOldCommand5, 20, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( szHK, 2, 1, fp ) != 1 ) exit(-2) ;
				}
				for( i=0; i<12; i++ ) {                // ground-ref HK
					wCmd = i ;
					fCommand() ;
					rHK = (REAL)(wHK) * rGndCvt[i] + rGndOff[i] ;
					if( wRecord && (i!=5) )
						if( fwrite( &wHK, 2, 1, fp ) != 1 ) exit(-2) ;

					if( i!=5 ) {
						sprintf( szText, szGndHK[i], rHK, wHK ) ;
						if( rHK < rGHKLow[i] || rHK > rGHKHigh[i] ) _settextcolor(29) ;
						if( i == wHilite-1 ) _settextcolor(14) ;
						if( i>5 ) _settextposition(i+1,1) ;
						else _settextposition(i+2,1) ;
						_outtext( szText ) ;
						_settextcolor(13) ;
					}
				}

				for( i=0; i<8; i++ ) {                 // Vf-ref HK
					wCmd = 512+i ;
					fCommand() ;
					rHK = (REAL)(wHK) * rVfCvt[i] + rVfOff[i] ;
					if( wRecord )
						if( fwrite( &wHK, 2, 1, fp ) != 1 ) exit(-2) ;

					if( i==1 || i==2 ) {
						if( wHK>235 ) {
							rHK = (REAL)wHK * 4.117 - 949.85 ;
						}
					}
					if( i>0 && i<7 ) sprintf( szText, szVfHK[i], rHK, wHK ) ;
					else  sprintf( szText, szVfHK[i], (WORD)rHK, wHK ) ;
					if( rHK < rVHKLow[i] || rHK > rVHKHigh[i] ) _settextcolor(29) ;
					_settextposition(i+2,23) ;
					_outtext( szText ) ;
					_settextcolor(13) ;
				}
				wCmd = 12 ;          // paps
				fCommand() ;
				rHK = (REAL)(wHK) * rVfCvt[8] + rVfOff[8] ;
				drPAPS = (double)rHK ;
				if( wRecord )
					if( fwrite( &wHK, 2, 1, fp ) != 1 ) exit(-2) ;

				sprintf( szText, szVfHK[8], (WORD)rHK, wHK ) ;
				if( drPAPS > drPAPSLimit ) {
					wCmd = 0x0800 ;
					fCommand() ;
				}
				if( rHK < rVHKLow[8] || rHK > rVHKHigh[8] ) _settextcolor(29) ;
				_settextposition(8+2,23) ;
				_outtext( szText ) ;
				_settextcolor(13) ;

				wCmd = 14 ;          // dpps
				fCommand() ;
				rHK = (REAL)(wHK) * rVfCvt[9] + rVfOff[9] ;
				if( rHK>0 ) iDVSCalc = (int)( log10( (double)(rHK/44.588) ) / log10(1.03618) ) ;
				if( wRecord )
					if( fwrite( &wHK, 2, 1, fp ) != 1 ) exit(-2) ;

				sprintf( szText, szVfHK[9], (WORD)rHK, wHK ) ;
				if( rHK < rVHKLow[9] || rHK > rVHKHigh[9] ) _settextcolor(29) ;
				_settextposition(9+2,23) ;
				_outtext( szText ) ;
				_settextcolor(13) ;
				sprintf( szText, "DVS  : %3d  (%3d)", iDVSCalc, iDVS ) ;
				_settextposition(12,23) ;
				_outtext( szText ) ;

/* ----------------------- RATES --------------------------------- */

				_strtime( szTime ) ;
				_settextcolor(12) ;
				_settextposition(1,58) ;
				_outtext( szTime ) ;
				_settextposition(1,68) ;
				_outtext( szDate ) ;

				_settextcolor(8) ;
				_settextposition(13,14) ;
				_outtext( "S/W: " ) ;
				_settextposition(13,19) ;
				_outtext( __DATE__ ) ;

				fRates() ;
				if( wRecord ) {
					if( fwrite( szRR, 2, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( &wFSR, 2, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( &wDCR, 2, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( &wTCR, 2, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( &wMSS, 2, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( &wPROT, 2, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( &wALFA, 2, 1, fp ) != 1 ) exit(-2) ;
					if( fwrite( szTime, 10, 1, fp ) != 1 ) exit(-2) ;
				}
				rRatCnt++ ;

				if( wRecord ) {
					_settextcolor(12) ;
					if( wPHA==0 )
						sprintf( szPHARec, "(No PHA recorded)" ) ;
					else
						sprintf( szPHARec, "(PHA recorded)   " ) ;
				}
				else {
					_settextcolor(8) ;
					sprintf( szPHARec, "                 " ) ;
				}
				_settextposition(22,18) ;
				_outtext( szName ) ;
				_settextposition(23,18) ;
				_outtext( szPHARec ) ;
				_settextposition(24,18) ;
				if( dwRecorded != 0 ) {
					sprintf( szText, "%ld", dwRecorded ) ;
					_outtext( szText ) ;
				}

				_settextcolor(15) ;
				_settextposition(14,10) ;
				sprintf( szText, "Rate Averages (%ld samples)   ",
					(DWORD)rRatCnt ) ;
				_outtext( szText ) ;
				_settextcolor(11) ;

				dwFSRtot += (long)wFSR ;
				rAvFSR = ( rAvFSR * (rRatCnt-1.) + (float)wFSR ) / rRatCnt ;
				dwDCRtot += (long)wDCR ;
				rAvDCR = ( rAvDCR * (rRatCnt-1.) + (float)wDCR ) / rRatCnt ;
				dwTCRtot += (long)wTCR ;
				rAvTCR = ( rAvTCR * (rRatCnt-1.) + (float)wTCR ) / rRatCnt ;
				dwMSStot += (long)wMSS ;
				rAvMSS = ( rAvMSS * (rRatCnt-1.) + (float)wMSS ) / rRatCnt ;
				dwPROTtot += (long)wPROT ;
				rAvPROT = ( rAvPROT * (rRatCnt-1.) + (float)wPROT ) / rRatCnt ;
				dwALFAtot += (long)wALFA ;
				rAvALFA = ( rAvALFA * (rRatCnt-1.) + (float)wALFA ) / rRatCnt ;
				if( rAvFSR>0.0 ) {
					rDCRFSR = rAvDCR / rAvFSR ;
					rTCRFSR = rAvTCR / rAvFSR ;
				}
				else {
					rDCRFSR = -1. ;
					rTCRFSR = -1. ;
				}
				if( rAvDCR>0.0 ) rTCRDCR = rAvTCR / rAvDCR ;
				else rTCRDCR = -1. ;
				if( rAvMSS>0.0 ) rTCRMSS = rAvTCR / rAvMSS ;
				else rTCRMSS = -1. ;

				_settextposition(15,1) ;
				sprintf( szText, " FSR   : %6u  ( Avg = %9.3f  Tot = %9ld ) ",
						wFSR, rAvFSR, dwFSRtot ) ;
				_outtext( szText ) ;
				_settextposition(16,1) ;
				sprintf( szText, " DCR   : %6u  ( Avg = %9.3f  Tot = %9ld ) ",
						wDCR, rAvDCR, dwDCRtot ) ;
				_outtext( szText ) ;
				_settextposition(17,1) ;
				sprintf( szText, " TCR   : %6u  ( Avg = %9.3f  Tot = %9ld ) ",
						wTCR, rAvTCR, dwTCRtot ) ;
				_outtext( szText ) ;
				_settextposition(18,1) ;
				sprintf( szText, " MSS   : %6u  ( Avg = %9.3f  Tot = %9ld ) ",
						wMSS, rAvMSS, dwMSStot ) ;
				_outtext( szText ) ;
				_settextposition(19,1) ;
				sprintf( szText, "PROT   : %6u  ( Avg = %9.3f  Tot = %9ld ) ",
						wPROT, rAvPROT, dwPROTtot ) ;
				_outtext( szText ) ;
				_settextposition(20,1) ;
				sprintf( szText, "ALFA   : %6u  ( Avg = %9.3f  Tot = %9ld ) ",
						wALFA, rAvALFA, dwALFAtot ) ;
				_outtext( szText ) ;
				_settextposition(22,1) ;
				sprintf( szText, "DCR/FSR: %6.3f", rDCRFSR ) ;
				_outtext( szText ) ;
				_settextposition(23,1) ;
				sprintf( szText, "TCR/DCR: %6.3f", rTCRDCR ) ;
				_outtext( szText ) ;
				_settextposition(24,1) ;
				sprintf( szText, "TCR/MSS: %6.3f", rTCRMSS ) ;
				_outtext( szText ) ;
				_settextposition(25,1) ;
				sprintf( szText, "TCR/FSR: %6.3f", rTCRFSR ) ;
				_outtext( szText ) ;

				if( wRefresh == 1 ) {
					wRefresh = 0 ;
//             fRates() ;
					dwFSRtot=dwDCRtot=dwTCRtot=dwMSStot=dwPROTtot=dwALFAtot=0 ;
					rAvFSR=rAvDCR=rAvTCR=rAvMSS=rAvPROT=rAvALFA=0. ;
					rDCRFSR=rTCRDCR=rTCRFSR=-1. ;
					rRatCnt = 0. ;
				}
			}       //wsec...

/* ------------------ PHA (and HISTOGRAMS) ----------------------- */

			_settextcolor(14) ;
			_settextposition(1,5) ;
			_outtext( "SISYPHUS - The Giessen Edition" ) ;
			_settextcolor(15) ;
			_settextposition(2,55) ;
			_outtext( "EGY  TOF ID   MASS  M/Q" ) ;
			_settextcolor(10) ;
		}

		fPHARead() ;
		if( wID < 4 ) {               // no PHA ready if ID=0x223
			wPHACtr++ ;
			rPHACnt++ ;
			if( wPHACtr > 17 ) {
				wPHACtr=1 ;
				if( !wDisplay && !wHelp ) {
					_settextposition(20,55) ;
					_settextcolor(10) ;
					_outtext( szText2 ) ;
					_outtext( szText3 ) ;
				}
			}
			if( !wDisplay && !wHelp ) {

// Calculate E in keV and TOF in ns...

				if( wID == 1 ) drEGY = ( (double)wEGY-2.63 ) / 0.41 ;
				else if( wID == 2 ) drEGY = ( (double)wEGY-4.00 ) / 0.41 ;
				else if( wID == 3 ) drEGY = ( (double)wEGY-3.32 ) / 0.41 ;
				else if( wID == 0 ) drEGY = ( (double)wEGY+2.06 ) / 0.79 ;
				else {
					printf( "Whoa!  wID=%u !!\a", wID ) ;
//             getch() ;
				}
				drTOF = ( (double)wTOF - 11.775 ) / 4.86 ;
				drEpQ = 0.4271 * (float)pow( 1.036547, (double)iDVSCalc ) ;
				drMpQ = 1.9159E-5 * ( drEpQ + (drPAPS/1000.) - 1.5 ) * drTOF * drTOF ;

// Calculate Mass...

				if( drEGY>0.0 && drTOF>0.0 ) {
					drMass = exp( 5.8109 - 1.50052*log(drEGY) - 3.01352*log(drTOF)
							+ 0.471113*log(drEGY)*log(drTOF)
							+ 0.0804588*log(drEGY)*log(drEGY)
							+ 0.0731559*log(drTOF)*log(drTOF)*log(drTOF) ) ;
				}
				else drMass = -1. ;

				if( drMass > 100. ) drMass = 100. ;
				if( drMpQ > 9.99 ) drMpQ = 9.99 ;

				_settextposition(2+wPHACtr,55) ;
				_settextcolor(10) ;
				_outtext( szText2 ) ;
				_settextcolor(2) ;
				_outtext( szText3 ) ;
				_settextposition(3+wPHACtr,55) ;
				_settextcolor(14) ;
				sprintf( szText, "%3d %4d  %1d ", wEGY, wTOF, wID ) ;
				_outtext( szText ) ;
				strcpy( szText2, szText ) ;
				_settextcolor(6) ;
				if( drMass>0. && drMass<100. ) sprintf( szText, " %5.1f", drMass ) ;
				else sprintf( szText, "      " ) ;
				_outtext( szText ) ;
				strcpy( szText3, szText ) ;
				if( drMpQ>0.05 && drMpQ<9.9 ) sprintf( szText, "  %4.2f", drMpQ ) ;
				else sprintf( szText, "        " ) ;
				_outtext( szText ) ;
				strcat( szText3, szText ) ;

				if( wEGY ) {
					rEGYCnt++ ;
					rAvEGY = ( rAvEGY * (rEGYCnt-1.) + (float)wEGY ) / rEGYCnt ;
				}
				if( wTOF ) {
					rTOFCnt++ ;
					rAvTOF = ( rAvTOF * (rTOFCnt-1.) + (float)wTOF ) / rTOFCnt ;
				}
				if( drMass>0. && drMass<100. ) {
					rMassCnt++ ;
					rAvMass = ( rAvMass * (rMassCnt-1.) + (float)drMass ) / rMassCnt ;
				}
				if( drMpQ>0.0 && drMpQ<9.9 ) {
					rMpQCnt++ ;
					rAvMpQ = ( rAvMpQ * (rMpQCnt-1.) + (float)drMpQ ) / rMpQCnt ;
				}
				rAvID = ( rAvID * (rPHACnt-1.) + (float)wID ) / rPHACnt ;
				_settextposition(22,55) ;
				_settextcolor(2) ;
				sprintf( szText, "%3d %4d %3.1f ",  (WORD)rAvEGY, (WORD)rAvTOF, rAvID ) ;
				_outtext( szText ) ;
				if( rAvMass ) sprintf( szText, "%5.1f", rAvMass ) ;
				else sprintf( szText, "      " ) ;
				_settextposition(22,67) ;
				_outtext( szText ) ;
				if( rAvMpQ ) sprintf( szText, "  %4.2f", rAvMpQ ) ;
				_outtext( szText ) ;
			}

			if( wRecord && wPHA ) {
				if( fwrite( szPH, 2, 1, fp ) != 1 ) exit(-2) ;
				if( fwrite( &wEGY, 2, 1, fp ) != 1 ) exit(-2) ;
				if( fwrite( &wTOF, 2, 1, fp ) != 1 ) exit(-2) ;
				if( fwrite( &wID, 2, 1, fp ) != 1 ) exit(-2) ;
				dwRecorded++ ;
			}

/* ------------ Collect histogram if so requested ---------------- */

			if( wHist ) {
				if( !strncmp( strlwr(szType), "e", 1 ) ) {
					if( wTOF <= wThigh && wTOF >= wTlow ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) {
								dwCounts[wEGY]++ ;
								dwHistCtr++ ;
							}
						}
						else {
							dwCounts[wEGY]++ ;
							dwHistCtr++ ;
						}
					}
				}
				else if( !strncmp( strlwr(szType), "t", 1 ) ) {
					if( wEGY <= wEhigh && wEGY >= wElow ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) {
								dwCounts[wTOF]++ ;
								dwHistCtr++ ;
							}
						}
						else {
							dwCounts[wTOF]++ ;
							dwHistCtr++ ;
						}
					}
				}
				else if( !strncmp( strlwr(szType), "r", 1 ) ) {
					if( wEGY <= wEhigh && wEGY >= wElow ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) {
								dwCounts[wTOF]++ ;
								dwHistCtr++ ;
							}
						}
						else {
							dwCounts[wTOF]++ ;
							dwHistCtr++ ;
						}
					}
				}
				else if( !strncmp( strlwr(szType), "m", 1 ) ) {
					if( drMpQ <= drMpQhigh && drMpQ >= drMpQlow ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) {
								dwCounts[(WORD)(drMass*10.)]++ ;
								dwHistCtr++ ;
							}
						}
						else {
							dwCounts[(WORD)(drMass*10.)]++ ;
							dwHistCtr++ ;
						}
					}
				}
				else if( !strncmp( strlwr(szType), "q", 1 ) ) {
					if( drMass <= drMhigh && drMass >= drMlow ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) {
								dwCounts[(WORD)(drMpQ*100.)]++ ;
								dwHistCtr++ ;
							}
						}
						else {
							dwCounts[(WORD)(drMpQ*100.)]++ ;
							dwHistCtr++ ;
						}
					}
				}

/* ---------- Display number of events collected so far ---------- */

				if( !(dwHistCtr%10) && !wDisplay && !wHelp ) {
					_settextposition(21,60) ;
					_settextcolor(14) ;
					sprintf( szText, "Hist: %7ld", dwHistCtr++ ) ;
					_outtext( szText ) ;
				}

/* ----------------- Display histogram when ready ---------------- */

				if( (dwHistCtr > dwEvReq) || wNow ) {
					if( !strncmp( strlwr(szType), "r", 1 ) ) {
						dwHistCtr = 0 ;
						wPulser++ ;
						wTOF = wPulser ;
						fSetTof() ;
						printf( "Sending pulser level %u...\n", wTOF ) ;
						getch() ;
						if( wPulser >= wPhigh ) {
							SisHist() ;
							wHist = 0 ;
							printf( "\nDONE!" ) ;
							getch() ;
						}
					}
					else {
						SisHist() ;
						wHist = 0 ;
					}
				}
			}  //hist

/* --------------- Collect dotplot if so requested ---------------- */

			if( wDots ) {
				if( !strncmp( strlwr(szType), "e", 1 ) ) {
					if( strncmp( strlwr(szDType), "x", 1 ) ) {
						if( wID == wIDReq ) {
							SisDots() ;
						}
					}
					else {
						SisDots() ;
					}
				}
				else if( !strncmp( strlwr(szType), "m", 1 ) ) {
					if( strncmp( strlwr(szDType), "x", 1 ) ) {
						if( wID == wIDReq ) {
							SisDots() ;
						}
					}
					else {
						SisDots() ;
					}
				}
			}  //dots
			_settextcolor(15) ;

		}  //valid pha

//    else {
//       wNoPHA++ ;
//       _settextcolor(15) ;
//       _settextposition(25,1) ;
//       sprintf( szText, "%d", wNoPHA ) ;
//       _outtext( szText ) ;
//    }

	}  //while

}

/* ******************* ROUTINES *************************************
	******************************************************************

	fPHARead -  Routine to read PHA data from SWICS using Fred Wire's
					DPU Simulator card.

				-  wID = 0,1,2,3 if valid data;
						 = 0x223 if timeout (i.e. no valid data)

	fcw : 22 jul 93
	pdb : 30 sep 94   (changed addresses from 30n -> 22n)
	fcw : 19 oct 94   (added code for:
								1) ignore data if cnt ok not set
								2) start amp is now 10bits for non PM data
	fcw : 16 oct 95   changed to read SWICS pha data
								10 bits TOF, 8 bits energy, 2 bits ID
	fcw : 30 jan 96   New PHA data format

 * ***************************************************************** */

void near fPHARead() {

	if( wSim ) {
		wID = getrandom( 0,3 ) ;
		if( wID == 0 ) {
			wEGY = getrandom( 0,255 ) ;
			wTOF = getrandom( 0,1023 ) ;
		}
		else if( wID == 1 ) {
			wEGY = getrandom( 0,80 ) ;
			wTOF = getrandom( 0,300 ) ;
		}
		else if( wID == 2 ) {
			wEGY = getrandom( 80,160 ) ;
			wTOF = getrandom( 300,600 ) ;
		}
		else if( wID == 3 ) {
			wEGY = getrandom( 160, 255 ) ;
			wTOF = getrandom( 600,1023 ) ;
		}
	}
	else {
	_asm {
			mov   dx, 0x223   ;  wait for pha data
			mov   wID, dx     ;  set no data flag

			in    al, (dx)
			mov   bl, al      ;save for clock pulse count check
			and   al, 4       ;check pha available bit
			jz    rdphaex     ;bye bye; no data available

rdphaok: mov   dx, 0x228   ;  read wTOF
			in    ax, (dx)
			and   ax, 0x3ff
			mov   wTOF, ax

			mov   dx, 0x229   ;  read wEGY & ID
			in    ax, (dx)
			shr   ax, 1       ;  shift over 2 places
			shr   ax, 1
			sub   bh, bh
			mov   bl, al
			mov   wEGY, bx

			shr   ah, 1       ;  shift 2 lsbits over 2 places
			shr   ah, 1
			and   ah, 3
			mov   wID, ah
			mov   wID+1, 0

			mov   dx, 0x22d   ;  clr pha available bit
			in    al, (dx)

rdphaex: nop
	}
	}
}

/* ******************************************************************
	fCommand -  Routine to send commands to MTOF using Fred Wire's DPU
					Simulator card, and return 8 bits of hk data.

	fcw : 20 jul 93
			18 mar 96   (added code for dual range dpps reading)
 * **************************************************************** */

void near fCommand() {

	if( wSim ) {
		wHK = wCmd ;
	}
	else {

	_asm {
		mov   dx, 0x223   ;read status (wait for ready)
lp0:  in    al, (dx)
		and   al, 1
		jz    lp0

		mov   dx, 0x220   ;cmd/data addr
		mov   ax, wCmd    ;get cmd
		out   (dx), ax    ;send cmd/data

		mov   dx, 0x223   ;read status (wait for status to go busy)
lp1:  in    al, (dx)
		and   al, 1
		jnz   lp1

;     read status (wait for status to go not busy)
lp2:  in    al, (dx)
		and   al, 1
		jz    lp2

;  read data and store

		mov   ax, wCmd    ;check for read dpps
		cmp   ax, 14      ;code for read dpps
		jz do_dpps

;     do reg hk read
		mov   dx, 0x221   ;mid hk byte
		in    al, (dx)
		sub   ah,ah
		jmp   store_hk

do_dpps:
		mov   dx, 0x220   ;lo & mid hk byte
		in    ax, (dx)
		xchg  al,ah
		mov   bl, 1
		and   ah, 0x80
		jz    do_mul
		mov   bl, 8
do_mul:
		mul   bl
store_hk:
		mov   wHK, ax

	}
	}
}

/* ******************************************************************
	fRates - Routine to read rate accumulator data from MTOF using
				Fred Wire's DPU Simulator card.

	fcw : 20 jul 93
	pdb : 22 jul 93   took out delays
	fcw : 02-aug-93   added reads of ufsr, mult starts, & mult dcr's
	fcw : 18 oct 95   modified to read swics rates

 * **************************************************************** */

void near fRates() {

	if( wSim ) {
		wFSR = getrandom( 0,32767 ) ;
		wDCR = getrandom( 0,32767 ) ;
		wTCR = getrandom( 0,32767 ) ;
		wMSS = getrandom( 0,32767 ) ;
		wPROT = getrandom( 0,32767 ) ;
		wALFA = getrandom( 0,32767 ) ;
	}
	else {

	_asm {
		mov   dx, 0x220   ;send acc read and store cmd
		mov   ax, 0xf007
		out   (dx), ax

;  now wait 10msec for acc's to be read from bubble;
;  a command takes 580usec, so do 18 cmds, then read acc's

		mov   cx, 18

lp0:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp0

lp_wait_10ms:
		mov   ax, 0x0000  ;read a hk parameter and ignore data
		mov   dx, 0x220
		out   (dx), ax

lp1:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp1

		loop  lp_wait_10ms

;  now read acc's

;  1'st fsr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x0209
		out   (dx), ax

lp9:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp9

		mov   dx, 0x220   ;read nsr
		in    ax, (dx)
		mov   wFSR, ax

;  2'nd dcr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020a
		out   (dx), ax

lpa:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpa

		mov   dx, 0x220   ;read dcr
		in    ax, (dx)
		mov   wDCR, ax

;  3'rd tcr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020b
		out   (dx), ax

lpb:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpb

		mov   dx, 0x220   ;read tcr
		in    ax, (dx)
		mov   wTCR, ax

;  4'th mss rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020c
		out   (dx), ax

lpc:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpc

		mov   dx, 0x220   ;read mss rate
		in    ax, (dx)
		mov   wMSS, ax

;  5'th proton rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020d
		out   (dx), ax

lpd:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpd

		mov   dx, 0x220   ;read proton rate
		in    ax, (dx)
		mov   wPROT, ax

;  & last alpha rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020e
		out   (dx), ax

lpe:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpe

		mov   dx, 0x220   ;read alpha rate
		in    ax, (dx)
		mov   wALFA, ax

	}
	}
}

/* ******************************************************************
	fTime -  Routine to read real-time clock in order to have rates
				that are in counts/second.

	fcw : 21 jul 93
 * **************************************************************** */

void near fTime() {
	_asm {
	lp:   mov   ah, 2
			int   0x1a     ; get real-time clock second
			jc    lp
			mov   al, dh   ; change from bcd
			sub   ah, ah
			mov   bl, 16
			div   bl
			mov   bh, ah
			sub   ah, ah
			mov   bl, 10
			mul   bl
			add   al, bh
			mov   wSec, ax
	 }
}

/* ******************************************************************
	fSetTof -  Routine to set the EG&G delay generator delay via the
				serial port. Assumes the serial port is configured. Each
				character is sent with a delay of ~ 60 msec. The value to
				be sent is in wTOF, and is in tenths of nanoseconds.

	fcw : 13 feb 96
 * **************************************************************** */

void near fSetTof() {
	_asm {
			jmp   start

	delay:
			push  ax       ;save
			push  bx
			push  cx
			push  dx
			mov   ah, 0
			int   0x1a     ; get ticks value in dx
			mov   bx, dx   ; save value
	dl0:  int   0x1a     ; delay for 1 tick time
			cmp   dx, bx
			jz    dl0      ; wait till it changes
			pop   dx
			pop   cx
			pop   bx
			pop   ax
			ret

	send_char:
								; char in al
			call  delay
			mov   ah, 0x1  ; code to send char
			mov   dx, 1    ; use com port 2
			int   0x14     ; send it
			ret

	start:
			mov   ax, wTOF
			sub   dx, dx
			mov   bx, 10
			mov   cx, 0x30    ;'0'
			push  cx
			mov   cx, 1       ;1 char on stack

	lp0:  div   bx          ;quot in ax, rem in dx
			add   dx, 0x30    ;convert to ascii
			push  dx
			sub   dx, dx
			inc   cx
			or    ax, ax
			jnz   lp0

			mov   al, 0x41    ;'A'
			call  send_char

	lp1:  pop   ax       ;send value
			call  send_char
			loop  lp1

			mov   al, 0xa  ;lf
			call  send_char
			mov   al, 0x41 ;'A'
			call  send_char
			mov   al, 0xa  ;lf
			call  send_char
	 }
}

/* ******************************************************************
	fSetCOM2 -  Routine to set the baud rate of com2 to 19200
						same as mode com2:19,n,8,1
	fcw : 15 feb 96
 * **************************************************************** */

void near fSetCOM2() {
	_asm {
			mov   dx, 0x2fb
			mov   al, 0x80    ; set dlab bit to access baud rate reg
			out   (dx), al

			mov   ax, 0x6     ; 6 set 19200; 12=9600, 24=4800, etc.
			mov   dx, 0x2f8
			out   (dx), ax    ; send out 6

			mov   dx, 0x2fb   ; reset dlab bit
			mov   al, 0x3     ;  & set nbits=8, no parity, 1 stop bit
			out   (dx), al
	 }
}
