/* ******************************************************************

	TANTALUS.C - Replay program for SISYPHUS software.

	pdb : 16-Jul-95 (As DAEDALUS.C)
		   22-Nov-95
	sel : 27-Nov-95 changed to put gi info in PHA and Rate files
						 added DV step filtering
	sel : 28-Nov-95 gi info in PHA and rate files reformatted for KG

 * ******************************************************************/

#include <stdio.h>
#include <string.h>
#include <graph.h>
#include <time.h>
#include <bios.h>
#include <conio.h>

#define ESC ((char) 0x1B )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define DREAL double
#define BYTE unsigned char

DWORD dwCounts[1200], dwYmaxNew=0, dwRates=0, dwGIReq=0,
		dwRecorded=0, dwEvReq=0, dwRatReq=0, dwHistCtr=0, dwTrendCtr=0,
		near dwFSRtot=0, near dwDCRtot=0, near dwTCRtot=0,
		near dwMSStot=0, near dwPROTtot=0, near dwALFAtot=0 ;
int   iHead, iPHA, iRates, iHK, iCmds, iDVStep, iDVSFilter ;
WORD  wEGY, wTOF, wID, wCmd, near wSec=0, wLastSec=0, wLog=0, wRat=0,
		wSource=1, wXlow=0, wXhigh=1100, wTlow, wThigh, wXinc=1, wScan=0,
		wDisplay=0, wHist=0, wTrend=0, wPHA=0, wRates=0, wOpts=1, wDots=0,
		wDont=0, wVax=0, wSecReq=1, wParam=0, wIDReq=0, wElow, wEhigh, wDVS,
		wFSR, wDCR, wTCR, wMSS, wPROT, wALFA, wHelp=0, wRate[6], wGI=0 ;

BYTE  bHK, szName[40], szTitle[70], szText[80]="", szText2[80]="",
		szText3[80]="",
		szBuffer[100]="", szRate[80]="", szBegTime[10], szDate[10],
		szType[10]="", szID[3]="ACE", answer,
		*szTrends[32] = { 
		"  0 = +28V           ", " 16 = - 5V           ",
		"  1 = 20V AC         ", " 17 = - 5I           ",
		"  2 = +10V           ", " 18 = MCPPS          ",
		"  3 = + 5V           ", " 19 = PAPS           ",
		"  4 = - 5V           ", " 20 = DPPS           ",
		"  5 = T1             ", " 21 = FSR            ",
		"  6 = T2             ", " 22 = DCR            ",
		"  7 = +28I (Pri)     ", " 23 = TCR            ",
		"  8 = +28I (Sec)     ", " 24 = MSS            ",
		"  9 = + 5I           ", " 25 = PROT           ",
		" 10 = 20I AC         ", " 26 = ALFA           ",
		" 11 = Sync           ", " 27 =                ",
		" 12 = T1 (Bub)       ", " 28 =                ",
		" 13 = T2 (Bub)       ", " 29 =                ",
		" 14 = + 5V           ", " 30 =                ",
		" 15 = + 5I           ", " 31 =                " } ;

DREAL	drMass=0., drMpQ=0., drEGY, drTOF, drEpQ, drPAPS, drMlow, drMhigh,
		drMpQlow, drMpQhigh ;

REAL  rFudge=1., rOffset=0., rHK, rAvFSR=0., rAvDCR=0., rAvTCR=0.,
		rAvMSS=0., rAvPROT=0.,  rAvALFA=0., rRatCnt=0.,
		rXpos=0., rAverageQ=0., rAverageK=0.,
		rRadius=0., rTheta=0. ;

void sisHist() ;
void sisDots() ;
void Reset() ;
void RateAverage() ;
void near fTime() ;
void printGI (FILE *theFile, char *theString, short withTime);

FILE *infile, *pha, *h, *rat, *gi ;

int main( int argc, char *argv[] ) {

	WORD  i, j, c, wEvents=0, wCmdNum=0, wNow=0, wFirstTime=0, wRatCtr=0,
			wGndHK[11], wVfHK[10], wGHK[11], wVHK[10], wHK, wLev,
			wCalVoltage, wCalLev, wPHACtr=0, wRecord=0, wFile=0, wRefresh=0,
			wManual=0, wXpos=0, wMass=0, wMPQ=0, wNoHK=0, wPHAWords,
			wHKItems, wNMCtr=0 ;

	REAL  rGndCvt[11]={ 28./200., 20./200., 10./200., 5./200., -5./200.,
				1., 1., 2., 1./5.1, 1./1.89, 1./1.65 },
			rGndOff[11]={ 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 38./1.65 },
			rGHKLow[11]={ 27., 20., 9.5, 4.5, -5.5, 0., 0.,
				0., 0., 0., 0. },
			rGHKHigh[11]={ 32., 23., 10.5, 5.5, -4.5, 255., 255.,
				255., 255., 255., 255. },
			rVHKLow[10]={ 0., 0., 0., 0., 0., 0., 0., 0., 0., 0. },
			rVHKHigh[10]={255., 255., 255., 255., 255., 255., 255.,
				255., 28000., 9000. },
			rVfCvt[10]={ 1., 1., 1., 1., 1., 1., 1., 1., 150., 40. },
			rVfOff[10]={ 0., 0., 0., 0., 0., 0., 0., 0., 0., 0. },

			rTemp[256]={160.0, 154.7, 125.9, 110.6, 100.4, 92.8, 86.7, 81.8,
					77.5, 73.9, 70.6, 67.7, 65.1, 62.7, 60.6, 58.5,
					56.7, 54.9, 53.3, 51.7,
					50.3, 48.9, 47.6, 46.3, 45.1, 44.0, 42.9, 41.8,
					40.8, 39.8, 38.9, 38.0, 37.1, 36.3, 35.4, 34.6,
					33.8, 33.1, 32.4, 31.6, 30.9, 30.2, 29.6, 28.9,
					28.3, 27.7, 27.1, 26.5, 25.9, 25.3, 24.7, 24.2,
					23.6, 23.1, 22.6, 22.1, 21.6, 21.1, 20.6, 20.1,
					19.6, 19.2, 18.7, 18.2, 17.8, 17.3, 16.9, 16.5,
					16.0, 15.6, 15.2, 14.8, 14.4, 14.0, 13.6, 13.2,
					12.8, 12.4, 12.0, 11.7, 11.3, 10.9, 10.5, 10.2,
					9.8, 9.5, 9.1, 8.8, 8.4, 8.1, 7.7, 7.4,
					7.0, 6.7, 6.4, 6.0, 5.7, 5.4, 5.1, 4.7,
					4.4, 4.1, 3.8, 3.5, 3.2, 2.9, 2.5, 2.2,
					1.9, 1.6, 1.3, 1.0, 0.7, 0.4, 0.1, -0.2,
					-0.5, -0.8, -1.0, -1.3, -1.6, -1.9, -2.2, -2.5,
					-2.8, -3.1, -3.4, -3.6, -3.9, -4.2, -4.5, -4.8,
					-5.0, -5.3, -5.6, -5.9, -6.2, -6.4, -6.7, -7.0,
					-7.3, -7.5, -7.8, -8.1, -8.4, -8.6, -8.9, -9.2,
					-9.5, -9.7, -10.0, -10.3, -10.6, -10.8, -11.1, -11.4,
					-11.7, -11.9, -12.2, -12.5, -12.8, -13.0, -13.3, -13.6,
					-13.9, -14.1, -14.4, -14.7, -15.0, -15.3, -15.5, -15.8,
					-16.1, -16.4, -16.7, -16.9, -17.2, -17.5, -17.8, -18.1,
					-18.4, -18.7, -19.0, -19.2, -19.5, -19.8, -20.1, -20.4,
					-20.7, -21.0, -21.3, -21.6, -21.9, -22.2, -22.5, -22.8,
					-23.1, -23.5, -23.8, -24.1, -24.4, -24.7, -25.0, -25.4,
					-25.7, -26.0, -26.4, -26.7, -27.0, -27.4, -27.7, -28.1,
					-28.4, -28.8, -29.1, -29.5, -29.9, -30.2, -30.6, -31.0,
					-31.4, -31.8, -32.1, -32.5, -32.9, -33.4, -33.8, -34.2,
					-34.6, -35.1, -35.5, -35.9, -36.4, -36.9, -37.3, -37.8,
					-38.3, -38.8, -39.3, -39.9, -40.4, -41.0, -41.5, -42.1,
					-42.7, -43.3, -44.0, -44.6, -45.3, -46.0, -46.7, -47.5,
					-48.2, -49.1, -49.9, -50.8 } ;

	BYTE  szCommand[80], bYorN, *szString, szGIFile[20],
			szDType[10]="", szHType[10]="", szPHFile[20], szRatFile[20],
			szLev[5], szHist[40]="", szFlag[2]="", szTime2[10],
			szBlank[80]="                                                      ",
			szOldCommand1[20]="", szOldCommand2[20]="", szOldCommand3[20]="",
			szOldCommand4[20]="", szOldCommand5[20]="", szTime[10],
			szOldCommands[20]="", szCASYMS[120]="",
			szHome[15]="BEDTIME!!",
			szLunch[15]="LUNCHTIME!!",
			szDinner[15]="DINNERTIME!!!",

			*szGndHK[11] = {  "+28V      : %5.1f (%2x)",
				"20V AC    : %5.1f (%2x)", "+10V      : %5.1f (%2x)",
				"+ 5V      : %5.1f (%2x)", "- 5V      : %5.1f (%2x)",
				"T1        : %5.1f (%2x)", "T2        : %5.1f (%2x)",
				"+28I (Pri): %5.1f (%2x)", "+28I (Sec): %5.1f (%2x)",
				"+ 5I      : %5.1f (%2x)", "20I AC    : %5.1f (%2x)" },

			*szVfHK[10] = {   "Sync  : %5.1f (%2x)",
				"T1    : %5.1f (%2x)", "T2    : %5.1f (%2x)",
				"+ 5V  : %5.1f (%2x)", "+ 5I  : %5.1f (%2x)",
				"- 5V  : %5.1f (%2x)", "- 5I  : %5.1f (%2x)",
				"MCPPS : %5d (%2x)", "PAPS  : %5d (%2x)", "DPPS  : %5d (%2x)" } ;

// ------------------------------------------------------------------------

	_clearscreen(_GCLEARSCREEN) ;
	if( argc < 2 ) {
		printf( "Usage is: TANTALUS <filename> .  Try again.\n" ) ;
		exit(-1) ;
	}
	if( !strncmp( argv[2], "-", 1 ) ) wDont = 1 ;
	if( (infile = fopen( argv[1], "rb" )) == NULL ) {
		printf( "Error opening file: %40s", argv[1] ) ;
		exit(-1) ;
	}

// Read header...

	fread( szID, 3, 1, infile ) ;
	if( strncmp( szID, "ACE", 3 ) ) exit(-1) ;
	fread( &iHead, 2, 1, infile ) ;
	fread( &iPHA, 2, 1, infile ) ;
	fread( &iRates, 2, 1, infile ) ;
	fread( &iHK, 2, 1, infile ) ;
	fread( &iCmds, 2, 1, infile ) ;
	fread( szName, 40, 1, infile ) ;
	fread( szTitle, 70, 1, infile ) ;
	fread( szDate, 10, 1, infile ) ;

/* ------------------ Main Loop ---------------------------------- */

	while( 1 ) {
		fflush( stdin ) ;
		if( kbhit() ) {
			c = getch() ;
			switch( tolower(c) ) {

/* ----------------------- PHA -> ascii -------------------------- */

			case 'p' :
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
				printf( "Enter name of PHA file: " ) ;
				gets( szPHFile ) ;
// added 27 Nov to include GI info in PHA file
				printf( "Include GI information? (Y/N) " ) ;
				answer = getch() ;
				if ( toupper(answer) == 'Y')
				{
					wGI = 2;
					dwGIReq = 10000;
				}
				printf( "\nNumber of events to put into file? [0=all]: " ) ;
				fflush( stdin );
				scanf( "%ld", &dwEvReq ) ;
				if( !dwEvReq ) dwEvReq = 1000000. ;
				printf( "Enter DV step for filtering (-1 for all steps): ");
				fflush( stdin);
				scanf ( "%i", &iDVSFilter);
				pha = fopen( szPHFile, "w+" ) ;
				fprintf( pha, "%s\n%s\n", szName, szTitle ) ;
				if ( toupper(answer) == 'Y')
					fprintf( pha, "%s\t", "Alpha	Beta	Theta	Z	Energy	DVS	Time");
				fprintf( pha, "%s\n", "Energy	TOF	SSD ID");
				wPHA = 1 ;
				wPHACtr = 0 ;
			break ;

/* ----------------------- Rates -> ascii -------------------------- */

			case 'r' :
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
				printf( "Enter name of Rates file: " ) ;
				gets( szRatFile ) ;
// added 27 Nov to include GI info in PHA file
				printf( "Include GI information? (Y/N) " ) ;
				answer = getch() ;
				if ( toupper(answer) == 'Y')
				{
					wGI = 2;
					dwGIReq = 10000;
				}
				printf( "\nNumber of rate sets to put into file? [0=all]: " ) ;
				scanf( "%ld", &dwRatReq ) ;
				if( !dwRatReq ) dwRatReq = 1000000. ;
				printf( "Enter DV step for filtering (-1 for all steps): ");
				fflush( stdin);
				scanf ( "%i", &iDVSFilter);
				rat = fopen( szRatFile, "w+" ) ;
				fprintf( rat, "%s\n%s\n", szName, szTitle ) ;
				if (toupper(answer) == 'Y')
					fprintf(rat, "%s\t", "Alpha	Beta	Theta	Z	Energy	DVS");
				fprintf(rat, "%s\n", "Time	FSR	DCR	TCR	MSS	Proton	Alpha");
				wRat = 1 ;
				wRatCtr = 0 ;
			break ;

/* ----------------------- GI Info -> ascii -------------------------- */

			case 'g' :
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
				printf( "Enter name of GI Data file: " ) ;
				gets( szGIFile ) ;
				printf( "Number of sets to put into file? [0=all]: " ) ;
				scanf( "%ld", &dwGIReq ) ;
				if( !dwGIReq ) dwGIReq = 1000000. ;
				rat = fopen( szGIFile, "w+" ) ;
				fprintf( gi, "%s\n%s\n", szName, szTitle ) ;
				wGI = 1 ;
			break ;

/* ----------------------- Histogram ---------------------------- */

			case 'h' :
				wScan = 0 ;
				for( i=0; i<1200; i++ )
					dwCounts[i] = 0 ;
				_clearscreen(_GCLEARSCREEN) ;
				wHist = 1 ;
				dwHistCtr = 0 ;
				fflush( stdin ) ;
				_settextposition( 24,1 ) ;
				_outtext( szBlank ) ;
				_settextposition( 24,1 ) ;
				_outtext( "Type of histogram? [e, t, m, or q]: " ) ;
				gets( szType ) ;
				if( !strncmp( strlwr(szType), "e", 1 ) ) wSource = 0 ;
				else if( !strncmp( strlwr(szType), "t", 1 ) ) wSource = 1 ;
				else if( !strncmp( strlwr(szType), "m", 1 ) ) wSource = 2 ;
				else if( !strncmp( strlwr(szType), "q", 1 ) ) wSource = 3 ;
				_settextposition( 24,1 ) ;
				_outtext( szBlank ) ;
				_settextposition( 24,1 ) ;
				_outtext( "Which SSD? [1, 2, 3, U, or X (don't care)]: " ) ;
				gets( szDType ) ;
				if( !strncmp(szDType, "1", 1 ) ) {
					wIDReq = 1 ;
				}
				else if( !strncmp(szDType, "2", 1 ) ) {
					wIDReq = 2 ;
				}
				else if( !strncmp(szDType, "3", 1 ) ) {
					wIDReq = 3 ;
				}
				else if( !strncmp( strlwr(szDType), "u", 1 ) ) {
					wIDReq = 0 ;
				}
				else if( strncmp( strlwr(szDType), "x", 1 ) ) {
					printf( "Invalid entry.  Try again.\n" ) ;
					wHist = 0 ;
				}
				_settextposition( 24,1 ) ;
				_outtext( szBlank ) ;
				_settextposition( 24,1 ) ;
				_outtext( "Number of events? [0=all]: " ) ;
				scanf( "%ld", &dwEvReq ) ;
				if( !dwEvReq ) dwEvReq = 1000000. ;
				fflush( stdin ) ;

				if( !strncmp( strlwr(szType), "e", 1 ) ) {
					wSource = 0 ;
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "TOF window - Enter TOFlow, TOFhigh [0..1100]: " ) ;
					scanf( "%d, %d", &wTlow, &wThigh ) ;
					fflush( stdin ) ;
					wXlow = 0 ;
					wXhigh = 300 ;
				}
				else if( !strncmp( strlwr(szType), "t", 1 ) ) {
					wSource = 1 ;
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Energy window - Enter Elow, Ehigh [0..300]: " ) ;
					scanf( "%d, %d", &wElow, &wEhigh ) ;
					fflush( stdin ) ;
					wXlow = 0 ;
					wXhigh = 1100 ;
				}
				else if( !strncmp( strlwr(szType), "m", 1 ) ) {
					wSource = 2 ;
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "M/Q window - Enter M/Qlow, M/Qhigh [0..1100]: " ) ;
					scanf( "%f, %f", &drMpQlow, &drMpQhigh ) ;
					fflush( stdin ) ;
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Please enter PAPS voltage in volts, and DV step: " ) ;
					scanf( "%f, %d", &drPAPS, &wDVS ) ;
					fflush( stdin ) ;
					wXlow = 0 ;
					wXhigh = 300 ;
				}
				else if( !strncmp( strlwr(szType), "q", 1 ) ) {
					wSource = 3 ;
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Mass window - Enter Mlow, Mhigh [0..300]: " ) ;
					scanf( "%f, %f", &drMlow, &drMhigh ) ;
					fflush( stdin ) ;
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Please enter PAPS voltage in volts, and DV step: " ) ;
					scanf( "%f, %d", &drPAPS, &wDVS ) ;
					fflush( stdin ) ;
					wXlow = 0 ;
					wXhigh = 1100 ;
				}
				_clearscreen(_GCLEARSCREEN) ;
			break ;

/* ------------------------ Dotplots ---------------------------- */

			case 'd' :
				if( !wHist && !wTrend ) {
					_clearscreen(_GCLEARSCREEN) ;
					wDots = 1 ;
					fflush( stdin ) ;

					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Type of dotplot? [e or m]: " ) ;
					gets( szType ) ;

					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Which SSD? [1, 2, 3, U, or X (don't care)]: " ) ;
					gets( szDType ) ;
					if( !strncmp( szDType, "1", 1 ) ) {
						wIDReq = 1 ;
					}
					else if( !strncmp( szDType, "2", 1 ) ) {
						wIDReq = 2 ;
					}
					else if( !strncmp( szDType, "3", 1 ) ) {
						wIDReq = 3 ;
					}
					else if( !strncmp( strlwr(szDType), "u", 1 ) ) {
						wIDReq = 0 ;
					}
					else if( strncmp( strlwr(szDType), "x", 1 ) ) {
						printf( "Invalid entry.  Try again.\n" ) ;
					}
					_settextposition( 24,1 ) ;
					_outtext( szBlank ) ;
//					_settextposition( 24,1 ) ;
//					_outtext( "Number of events? [0=all]: " ) ;
//					scanf( "%ld", &dwEvReq ) ;
//					if( !dwEvReq ) dwEvReq = 1000000. ;
					fflush( stdin ) ;
					_clearscreen(_GCLEARSCREEN) ;
					wRefresh = 1 ;
				}
				else {
					wNow = 1 ;
				}
			break ;

/* ------------------ Trend PLot --------------------------------- */

			case 't' :
				for( i=0; i<1200; i++ )
					dwCounts[i] = 0 ;
				_clearscreen(_GCLEARSCREEN) ;
				wSource = 12 ;
				wTrend = 1 ;
				dwTrendCtr = 0 ;
				fflush( stdin ) ;
				_settextposition(1,1) ;
				_settextcolor(15) ;
				_outtext( "                       TREND PLOTS" ) ;
				_settextposition(3,1) ;
				_settextcolor(13) ;
				_outtext( "Ground-referenced HK   PAPS HK/Rates" ) ;
				_settextcolor(11) ;
				for( j=0; j<2; j++ ) {
					for( i=0; i<16; i++ ) {
						_settextposition(i+5,j*24) ;
						sprintf( szText, szTrends[2*i+j] ) ;
						_outtext( szText ) ;
					}
				}
				_settextposition(22,1) ;
				_outtext( "Enter parameter number: " ) ;
				scanf("%d", &wParam ) ;
				fflush( stdin ) ;
				printf( "\nNumber of readings? [0=all (up to 1000 that is)]: " ) ;
				scanf( "%ld", &dwEvReq ) ;
				if( !dwEvReq ) dwEvReq = 1000 ;
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
			break ;

/* ------------------------ Clear screen ------------------------- */

			case 'n' :
				_clearscreen(_GCLEARSCREEN) ;
			break ;

/* ---------------------- Display options ------------------------ */

			case 'o' :
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
				wOpts = 1 ;
			break ;

/* -------------------- Refresh rate averages --------------------- */

			case 'a' :
				fflush( stdin ) ;
				dwFSRtot=dwDCRtot=dwTCRtot=dwMSStot=dwPROTtot=dwALFAtot=0 ;
				rAvFSR=rAvDCR=rAvTCR=rAvMSS=rAvPROT=rAvALFA=0. ;
				rRatCnt = 0. ;
			break ;

/* ---------------- Toggle log/linear display -------------------- */

			case 'l' :
				_setvideomode(_DEFAULTMODE) ;
				if( wLog ) wLog = 0 ;
				else  wLog = 1 ;
				wDisplay = 0 ;
				sisHist() ;
			break ;

/* ---------------- Change display update rate ------------------- */

			case '0' :
				wSecReq = 0 ;
			break ;

			case '1' :
				wSecReq = 1 ;
			break ;

			case '3' :
				wSecReq = 3 ;
			break ;

			case '5' :
				wSecReq = 5 ;
			break ;

			case '9' :
				wSecReq = 9 ;
			break ;

/* ------ Save histogram in ascii file or Scan Data --------------- */

			case 's' :
				fflush( stdin ) ;
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Enter file name for histogram data: " ) ;
					gets( szHist ) ;
					h = fopen( szHist, "w+" ) ;
					fprintf( h, "%s\n", szHist ) ;
					for( i=0; i<1200; i++ )
						fprintf( h, "%4d   %7ld\n", i, dwCounts[i] ) ;
					printf( "Histogram recorded.\a" ) ;
					wDisplay = 0 ;
					sisHist() ;
				}
				else {
					if( wScan ) wScan = 0 ;
					else  {
						_clearscreen(_GCLEARSCREEN) ;
						wScan = 1 ;
					}
				}
			break ;

/* ---------------------- Rewind File --------------------------- */

			case 'z' :
				if( !wDisplay ) {
					Reset() ;
					_settextposition(24,1) ;
					_settextcolor(15) ;
					_outtext( "File rewound...\n" ) ;
				}
			break ;

/* ------------------- Change Channels/Bin ----------------------- */

			case 'b' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					_outtext( "Enter new channels/bin: " ) ;
					scanf( "%d", &wXinc ) ;
					wDisplay = 0 ;
					sisHist() ;
				}
			break ;

/* ------------------- Clear histogram ---------------------------- */

			case ESC :
				_setvideomode(_DEFAULTMODE) ;
				wHist = 0 ;
            wDots = 0 ;
				wTrend = 0 ;
				wDisplay = 0 ;
				dwHistCtr = 0 ;
				dwTrendCtr = 0 ;
				wXlow = 0 ;
				wXhigh = 1100 ;
				wXinc = 1 ;
				wNow = 0 ;
				wOpts = 1 ;
				for( i=0; i<1200; i++ )
					dwCounts[i] = 0 ;
			break ;

/* -------------- Rescale in X or Exit Program -------------------- */

			case 'x' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Enter Xlow and Xhigh: " ) ;
					scanf( "%d, %d", &wXlow, &wXhigh ) ;
					wDisplay = 0 ;
					sisHist() ;
				}
				else {
					_clearscreen(_GCLEARSCREEN) ;
					exit(0) ;
				}
			break ;

/* ----------------------- Rescale in Y ------------------------- */

			case 'y' :
				if( wDisplay ) {
					_setvideomode(_DEFAULTMODE) ;
					_settextposition(24,1) ;
					fflush( stdin ) ;
					_outtext( szBlank ) ;
					_settextposition( 24,1 ) ;
					_outtext( "Enter new maximum Y value: " ) ;
					scanf( "%ld", &dwYmaxNew ) ;
					if( dwYmaxNew ) dwYmaxNew-- ;
					wDisplay = 0 ;
					sisHist() ;
				}
			break ;

			}
		}
/* ------------------- DISPLAY OPTIONS --------------------------- */

		if( wOpts ) {
			_settextcolor(15) ;
			_settextposition(1,1) ;
			_outtext( "File name: " ) ;
			_settextcolor(11) ;
			sprintf( szText, "%s\n", szName ) ;
			_outtext( szText ) ;
			_settextcolor(15) ;
			_outtext( "Run title: " ) ;
			_settextcolor(11) ;
			sprintf( szText, "%s\n", szTitle ) ;
			_outtext( szText ) ;
			_settextcolor(10) ;
			_settextposition(3,30) ;
			_outtext( "USER OPTIONS" ) ;
			_settextposition(4,30) ;
			_settextcolor(7) ;
			_outtext( __DATE__ ) ;
			_settextcolor(14) ;
			_settextposition(6,22) ;
			_outtext( "h - histogram of E or TOF\n" ) ;
			_settextposition(7,22) ;
			_outtext( "     d - display histogram early\n" ) ;
			_settextposition(8,22) ;
			_outtext( "     b - change # channels/bin\n" ) ;
			_settextposition(9,22) ;
			_outtext( "     x - rescale x axis\n" ) ;
			_settextposition(10,22) ;
			_outtext( "     y - rescale y axis\n" ) ;
			_settextposition(11,22) ;
			_outtext( "     l - toggle between log and linear y-scale\n" ) ;
			_settextposition(12,22) ;
			_outtext( "     s - save histogram into an ascii file\n" ) ;
			_settextposition(13,22) ;
			_outtext( "   <esc> - clear histogram display\n" ) ;
			_settextposition(14,22) ;
			_outtext( "t - trend plot of HK or Rates\n" ) ;
			_settextposition(15,22) ;
			_outtext( "     (same sub-options as with h apply)\n" ) ;
			_settextposition(16,22) ;
			_outtext( "d - dotplot of E vs TOF or M vs M/Q\n" ) ;
			_settextposition(17,22) ;
			_outtext( "     (only some of the h and t sub-options apply)\n" ) ;
			_settextposition(18,22) ;
			_outtext( "p - save PHA data into ascii file\n" ) ;
			_settextposition(19,22) ;
			_outtext( "g - save GI information into an ascii file\n" ) ;
			_settextposition(20,22) ;
			_outtext( "s - toggle scan mode on/off\n" ) ;
			_settextposition(21,22) ;
			_outtext( "r - save Rates into an ascii file\n" ) ;
			_settextposition(22,22) ;
			_outtext( "n - new (clear) screen\n" ) ;
			_settextposition(23,22) ;
			_outtext( "o - show these options\n" ) ;
			_settextposition(24,22) ;
			_outtext( "z - Rewind file\n" ) ;
			_settextposition(25,22) ;
			_outtext( "x - exit program.\n" ) ;
			_settextcolor(15) ;
			wOpts = 0 ;
		}

/* --------------- PHA or HISTOGRAMS ----------------------------- */

		if( wPHA || wHist || wDots || wRat || (wGI == 1) ) {

// Read data...

			fread( szFlag, 2, 1, infile ) ;
			if( feof( infile ) ) Reset() ;

			if( !strncmp( szFlag, "CD", 2 ) ) {
				for( i=0; i<5; i++ ) {
					fread( szOldCommands, 20, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
			}
			else if( !strncmp( szFlag, "HK", 2 ) ) {
				for( i=0; i<21; i++ ) {
					fread( &wHKItems, 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
			}
			else if( !strncmp( szFlag, "RR", 2 ) ) {
				for( i=0; i<((iRates-10)/2); i++ ) {
					fread( &wRate[i], 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
				fread( szTime, 10, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				if( !wFirstTime ) {
					wFirstTime=1 ;
					strcpy( szBegTime, szTime ) ;
				}
				if( wRat ) {
					if( dwRates < dwRatReq ) {
						if( iDVSFilter == iDVStep ) {
							dwRates++;
							if ( wGI == 2 )
								printGI(rat, szCASYMS, 0);
							fprintf( rat, "%s\t", szTime ) ;
							for ( i=0; i<((iRates-10)/2); i++)
								fprintf( rat, "%u\t",  wRate[i] ) ;
							fprintf( rat, "\n");
						}
					}
					else {
						_clearscreen(_GCLEARSCREEN) ;
						printf( "Rate file completed!!\n" ) ;
						fclose( rat ) ;
						wRat = wGI = 0;
						dwRates = dwGIReq = 0;
					}
				} // if(wRat)
			} // "RR"
			else if( !strncmp( szFlag, "PH", 2 ) ) {
				fread( &wEGY, 2, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				fread( &wTOF, 2, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				fread( &wID, 2, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				wPHACtr++ ;

// Calculate E in keV and TOF in ns...

				if( wID == 1 ) drEGY = ( (double)wEGY-2.63 ) / 0.41 ;
				else if( wID == 2 ) drEGY = ( (double)wEGY-4.00 ) / 0.41 ;
				else if( wID == 3 ) drEGY = ( (double)wEGY-3.32 ) / 0.41 ;
				else if( wID == 0 ) drEGY = ( (double)wEGY+2.06 ) / 0.79 ;
				else {
					printf( "Whoa!  wID=%u !!\a", wID ) ;
					getch() ;
				}
				drTOF = ( (double)wTOF - 11.775 ) / 4.86 ;
				drEpQ = 0.4271 * (float)pow( 1.036547, (double)wDVS ) ;
				drMpQ = 1.9159E-5 * ( drEpQ + (drPAPS/1000.) - 1.5 ) * drTOF * drTOF ;

// Calculate Mass...

				if( drEGY>0.0 && drTOF>0.0 ) {
					drMass = exp( 5.8109 - 1.50052*log(drEGY) - 3.01352*log(drTOF)
							+ 0.471113*log(drEGY)*log(drTOF)
							+ 0.0804588*log(drEGY)*log(drEGY)
							+ 0.0731559*log(drTOF)*log(drTOF)*log(drTOF) ) ;
				}
				else drMass = -1. ;

				if( drMass > 100. ) drMass = 100. ;
				if( drMpQ > 9.99 ) drMpQ = 9.99 ;

// Histograms...

				if( wHist ) {
					if( !strncmp( strlwr(szType), "e", 1 ) ) {
						if( wTOF <= wThigh && wTOF >= wTlow ) {
							if( strncmp( strlwr(szDType), "x", 1 ) ) {
								if( wID == wIDReq ) {
									dwCounts[wEGY]++ ;
									dwHistCtr++ ;
								}
							}
							else {
								dwCounts[wEGY]++ ;
								dwHistCtr++ ;
							}
						}
					}
					else if( !strncmp( strlwr(szType), "t", 1 ) ) {
						if( wEGY <= wEhigh && wEGY >= wElow ) {
							if( strncmp( strlwr(szDType), "x", 1 ) ) {
								if( wID == wIDReq ) {
									dwCounts[wTOF]++ ;
									dwHistCtr++ ;
								}
							}
							else {
								dwCounts[wTOF]++ ;
								dwHistCtr++ ;
							}
						}
					}
				else if( !strncmp( strlwr(szType), "m", 1 ) ) {
					if( drMpQ <= drMpQhigh && drMpQ >= drMpQlow ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) {
								dwCounts[(WORD)(drMass*10.)]++ ;
								dwHistCtr++ ;
							}
						}
						else {
							dwCounts[(WORD)(drMass*10.)]++ ;
							dwHistCtr++ ;
						}
					}
				}
				else if( !strncmp( strlwr(szType), "q", 1 ) ) {
					if( drMass <= drMhigh && drMass >= drMlow ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) {
								dwCounts[(WORD)(drMpQ*100.)]++ ;
								dwHistCtr++ ;
							}
						}
						else {
							dwCounts[(WORD)(drMpQ*100.)]++ ;
							dwHistCtr++ ;
						}
					}
				}

/* ---------- Display number of events collected so far ---------- */

					if( !(dwHistCtr%10) ) {
						_settextposition(14,41) ;
						_settextcolor(14) ;
						sprintf( szText, "Hist: %7ld", dwHistCtr ) ;
						_outtext( szText ) ;
						_settextposition(15,43) ;
						_settextcolor(6) ;
						_outtext( szTime ) ;
					}

// Display histogram when ready...

					if( (dwHistCtr > dwEvReq) || wNow ) {
						sisHist() ;
						wHist = 0 ;
					}

				} //hist

// Dotplots...

				if( wDots ) {
					if( !strncmp( strlwr(szType), "e", 1 ) ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) sisDots() ;
						}
						else {
                     sisDots() ;
                  }
					}
					else if( !strncmp( strlwr(szType), "m", 1 ) ) {
						if( strncmp( strlwr(szDType), "x", 1 ) ) {
							if( wID == wIDReq ) sisDots() ;
						}
						else {
							sisDots() ;
						}
					}

				} //dots

/* -------------------- PHA -> ASCII ----------------------------- */

				else if( wPHA ) {
					if( dwRecorded < dwEvReq ) {
						if ( iDVStep == iDVSFilter ) {
							dwRecorded++;
							if ( wGI == 2 )
								printGI(pha, szCASYMS, 1);
							fprintf( pha, "%d\t%d\t%d\n", wEGY, wTOF, wID ) ;
						}
					}
					else {
						_clearscreen(_GCLEARSCREEN) ;
						printf( "\aPHA file completed!!\n" ) ;
						fclose( pha ) ;
						dwRecorded = dwGIReq = 0;
						wPHA = wGI = 0;
					}
				} // else if (wPHA)
			}
			else if( !strncmp( szFlag, "GI", 2 ) ) {
				fread( szCASYMS, 120, 1, infile ) ;
				if ( iDVSFilter > -1)
				{// determine DV step if filtering on DV step
					if (strstr(szCASYMS, "DVS:") > 0)
						sscanf(strstr(szCASYMS, "DVS:")+4, "%i", &iDVStep);
					else
						iDVStep = -2;
				}
				else
					iDVStep = -1;
			}
			else {
				sprintf( szText, "%d : szFlag = %s", ++wNMCtr, szFlag ) ;
				_settextposition(25,1) ;
				_settextcolor(14) ;
				_outtext( szText ) ;
			}
		} //pha or histogram

/* ---------------------- SCAN THROUGH FILE ----------------------- */

		if( wScan ) {

// Read and display PHA data...

			fread( szFlag, 2, 1, infile ) ;
			if( feof( infile ) ) Reset() ;

			if( !strncmp( szFlag, "PH", 2 ) ) {
				_settextcolor(15) ;
				_settextposition(2,55) ;
				_outtext( "EGY  TOF ID  MASS  M/Q" ) ;
				_settextcolor(10) ;
				fread( &wEGY, 2, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				fread( &wTOF, 2, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				fread( &wID, 2, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				wPHACtr++ ;

				if( wPHACtr > 19 ) {
					wPHACtr = 1 ;
					_settextposition(22,55) ;
					_settextcolor(10) ;
					_outtext( szText2 ) ;
					_outtext( szText3 ) ;
				}

// Calculate E in keV and TOF in ns...

				if( wID == 1 ) drEGY = ( (double)wEGY-2.63 ) / 0.41 ;
				else if( wID == 2 ) drEGY = ( (double)wEGY-4.00 ) / 0.41 ;
				else if( wID == 3 ) drEGY = ( (double)wEGY-3.32 ) / 0.41 ;
				else if( wID == 0 ) drEGY = ( (double)wEGY+2.06 ) / 0.79 ;
				else {
					printf( "Whoa!  wID=%u !!\a", wID ) ;
					getch() ;
				}
				drTOF = ( (double)wTOF - 11.775 ) / 4.86 ;
				drEpQ = 0.4271 * (float)pow( 1.036547, (double)wDVS ) ;
				drMpQ = 1.9159E-5 * ( drEpQ + (drPAPS/1000.) - 1.5 ) * drTOF * drTOF ;

// Calculate Mass...

				if( drEGY>0.0 && drTOF>0.0 ) {
					drMass = exp( 5.8109 - 1.50052*log(drEGY) - 3.01352*log(drTOF)
							+ 0.471113*log(drEGY)*log(drTOF)
							+ 0.0804588*log(drEGY)*log(drEGY)
							+ 0.0731559*log(drTOF)*log(drTOF)*log(drTOF) ) ;
				}
				else drMass = -1. ;

				if( drMass > 100. ) drMass = 100. ;
				if( drMpQ > 9.99 ) drMpQ = 9.99 ;

				_settextposition(2+wPHACtr,55) ;
				_settextcolor(10) ;
				_outtext( szText2 ) ;
				_settextcolor(2) ;
				_outtext( szText3 ) ;
				_settextposition(3+wPHACtr,55) ;
				_settextcolor(14) ;
				sprintf( szText, "%3d %4d  %1d ", wEGY, wTOF, wID ) ;
				_outtext( szText ) ;
				strcpy( szText2, szText ) ;
				_settextcolor(6) ;
				sprintf( szText, "%5.1f %5.2f", drMass, drMpQ ) ;
				_outtext( szText ) ;
				strcpy( szText3, szText ) ;
			}

// Read and display RATE data...

			else if( !strncmp( szFlag, "RR", 2 ) ) {
				for( i=0; i<((iRates-10)/2); i++ ) {
					fread( &wRate[i], 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
				fread( szTime, 10, 1, infile ) ;
				if( feof( infile ) ) Reset() ;

				wFSR = wRate[0] ;
				wDCR = wRate[1] ;
				wTCR = wRate[2] ;
				wMSS = wRate[3] ;
				wPROT = wRate[4] ;
				wALFA = wRate[5] ;
				rRatCnt++ ;


				_settextcolor(12) ;
				_settextposition(1,48) ;
				_outtext( szTime ) ;
				RateAverage() ;

				if( wSecReq ) {
					while( (wSec%wSecReq) || (wLastSec==wSec) ) {
						fTime() ;
					}
					wLastSec = wSec ;
				}
			}

// Read and display old commands...

			else if( !strncmp( szFlag, "CD", 2 ) ) {
				fread( szOldCommand1, 20, 1, infile ) ;
				fread( szOldCommand2, 20, 1, infile ) ;
				fread( szOldCommand3, 20, 1, infile ) ;
				fread( szOldCommand4, 20, 1, infile ) ;
				fread( szOldCommand5, 20, 1, infile ) ;
				_settextcolor(7) ;
				_settextposition(2,48) ;
				_outtext( szOldCommand1 ) ;
				_settextposition(3,48) ;
				_outtext( szOldCommand2 ) ;
				_settextposition(4,48) ;
				_outtext( szOldCommand3 ) ;
				_settextposition(5,48) ;
				_outtext( szOldCommand4 ) ;
				_settextposition(6,48) ;
				_outtext( szOldCommand5 ) ;
			}

// Read and display HK data...

			else if( !strncmp( szFlag, "HK", 2 ) ) {
				_settextcolor(15) ;
				_settextposition(1,1) ;
				_outtext( "   CDT HK   " ) ;
				_settextcolor(13) ;
				for( i=0; i<11; i++ ) {
					fread( &wHK, 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
					wGHK[i] = wHK ;
					rHK = (REAL)(wHK) * rGndCvt[i] + rGndOff[i] ;
					sprintf( szText, szGndHK[i], rHK, wHK ) ;
					if( (i==5) || (i==6) ) {
						sprintf( szText, szGndHK[i], rTemp[wHK], wHK ) ;
					}
					_settextposition(i+2,1) ;
					_outtext( szText ) ;
				}
				_settextcolor(15) ;
				_settextposition(1,27) ;
				_outtext( "   PAPS HK      " ) ;
				_settextcolor(13) ;
				for( i=0; i<10; i++ ) {
					fread( &wHK, 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
					wVHK[i] = wHK ;
					rHK = (REAL)(wHK) * rVfCvt[i] + rVfOff[i] ;
					if( i==7 || i==8 || i==9 )
						sprintf( szText, szVfHK[i], (WORD)rHK, wHK ) ;
					else
						sprintf( szText, szVfHK[i], rHK, wHK ) ;
					_settextposition(i+2,27) ;
					_outtext( szText ) ;
				}
				_settextposition(12,40) ;
				_settextcolor(12) ;
				_outtext( szName ) ;
			}
			else if( !strncmp( szFlag, "GI", 2 ) ) {
				fread( szCASYMS, 120, 1, infile ) ;
				if ( iDVSFilter > -1)
				{// determine DV step if filtering on DV step
					if (strstr(szCASYMS, "DVS:") > 0)
						sscanf(strstr(szCASYMS, "DVS:")+4, "%i", &iDVStep);
					else
						iDVStep = -2;
				}
				else
					iDVStep = -1;
				if( wGI == 1 ) {
					fprintf( gi, "%s\n", szCASYMS ) ;
					if( feof( gi ) ) {
						wGI = 0 ;
						printf( "Rate file completed!!\n" ) ;
						fclose( gi ) ;
						Reset() ;
					}
				} // gi data file

			}
			else {
				sprintf( szText, "%d : szFlag = %s", ++wNMCtr, szFlag ) ;
				_settextposition(25,1) ;
				_settextcolor(13) ;
				_outtext( szText ) ;
			}
		} //scan

/* ------------------------- TRENDS ---------------------------------- */

		if( wTrend ) {

			fread( szFlag, 2, 1, infile ) ;
			if( feof( infile ) ) Reset() ;

			if( !strncmp( szFlag, "PH", 2 ) ) {
				for( i=0; i<3; i++ ) {
					fread( &wPHAWords, 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
			}
			else if( !strncmp( szFlag, "RR", 2 ) ) {
				for( i=0; i<((iRates-10)/2); i++ ) {
					fread( &wRate[i], 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
				fread( szTime, 10, 1, infile ) ;
				if( feof( infile ) ) Reset() ;
				wFSR = wRate[0] ;
				wDCR = wRate[1] ;
				wTCR = wRate[2] ;
				wMSS = wRate[3] ;
				wPROT = wRate[4] ;
				wALFA = wRate[5] ;
				rRatCnt++ ;
				for( i=0; i<((iRates-10)/2); i++ ) {
					if( wParam == (i+21) )
						dwCounts[dwTrendCtr++] = (long)wRate[i] ;
				}
			}
			else if( !strncmp( szFlag, "CD", 2 ) ) {
				for( i=0; i<5; i++ ) {
					fread( szOldCommands, 20, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
				}
			}
			else if( !strncmp( szFlag, "HK", 2 ) ) {
				for( i=0; i<11; i++ ) {
					fread( &wHK, 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
					rHK = (REAL)(wHK) * rGndCvt[i] + rGndOff[i] ;
					if( rHK<0. ) rHK = rHK * -1. ;
					if( i==wParam ) dwCounts[dwTrendCtr++] = (DWORD)rHK ;
				}
				for( i=0; i<10; i++ ) {
					fread( &wHK, 2, 1, infile ) ;
					if( feof( infile ) ) Reset() ;
					rHK = (REAL)(wHK) * rVfCvt[i] ;
					if( rHK<0. ) rHK = rHK * -1. ;
					j = i+11 ;
					if( j==wParam ) dwCounts[dwTrendCtr++] = (DWORD)rHK ;
				}
			}
			else if( !strncmp( szFlag, "GI", 2 ) ) {
				fread( szCASYMS, 120, 1, infile ) ;
				if ( iDVSFilter > -1)
				{// determine DV step if filtering on DV step
					if (strstr(szCASYMS, "DVS:") > 0)
						sscanf(strstr(szCASYMS, "DVS:")+4, "%i", &iDVStep);
					else
						iDVStep = -2;
				}
				else // set DV step to -1 so filtering ignores it
					iDVStep = -1;

			}
			else {
				sprintf( szText, "%d : szFlag = %s", ++wNMCtr, szFlag ) ;
				_settextposition(25,1) ;
				_settextcolor(13) ;
				_outtext( szText ) ;
			}

			if( !(dwTrendCtr%10) ) {
				_settextposition(13,25) ;
				_settextcolor(13) ;
				sprintf( szText, "Trend Plot: %7ld", dwTrendCtr ) ;
				_outtext( szText ) ;
			}

			if( (dwTrendCtr>dwEvReq) || wNow ) {
				sisHist() ;
				wTrend = 0 ;
				wScan = 0 ;
			}

		} //trend

	} //while(1)

}

void Reset() {

	extern WORD wHist, wTrend, wRates, wPHA, wScan ;
	extern int	iHead, iPHA, iRates, iHK, iCmds ;
	extern BYTE szName[40], szTitle[70], szDate[10], szID[3] ;

	printf( "\a" ) ;
	rewind( infile ) ;
	fread( szID, 3, 1, infile ) ;
	if( strncmp( szID, "ACE", 3 ) ) exit(-1) ;
	fread( &iHead, 2, 1, infile ) ;
	fread( &iPHA, 2, 1, infile ) ;
	fread( &iRates, 2, 1, infile ) ;
	fread( &iHK, 2, 1, infile ) ;
	fread( &iCmds, 2, 1, infile ) ;
	fread( szName, 40, 1, infile ) ;
	fread( szTitle, 70, 1, infile ) ;
	fread( szDate, 10, 1, infile ) ;
	if( wHist || wTrend ) sisHist() ;
	else if( wDots ) sisDots() ;
	wRates = wPHA = wTrend = wHist = wDots = wScan = 0 ;

}

void RateAverage() {

	int i, status ;

	_settextcolor(15) ;
	_settextposition(14,4) ;
	sprintf( szText, "Rate Averages (%ld samples)   ",
			(DWORD)rRatCnt ) ;
	_outtext( szText ) ;

	_settextcolor(8) ;
	_settextposition(13,6) ;
	sprintf( szText, __DATE__ ) ;
	_outtext( szText ) ;
	_settextcolor(11) ;

	dwFSRtot += (long)wFSR ;
	rAvFSR = ( rAvFSR * (rRatCnt-1.) + (float)wFSR ) / rRatCnt ;
	_settextposition(15,1) ;
	sprintf( szText, " FSR: %6d  ( Avg = %9.3f  Tot = %9ld )  ",
			wFSR, rAvFSR, dwFSRtot ) ;
	_outtext( szText ) ;

	dwDCRtot += (long)wDCR ;
	rAvDCR = ( rAvDCR * (rRatCnt-1.) + (float)wDCR ) / rRatCnt ;
	_settextposition(16,1) ;
	sprintf( szText, " DCR: %6d  ( Avg = %9.3f  Tot = %9ld )  ",
			wDCR, rAvDCR, dwDCRtot ) ;
	_outtext( szText ) ;

	dwTCRtot += (long)wTCR ;
	rAvTCR = ( rAvTCR * (rRatCnt-1.) + (float)wTCR ) / rRatCnt ;
	_settextposition(17,1) ;
	sprintf( szText, " TCR: %6d  ( Avg = %9.3f  Tot = %9ld )  ",
			wTCR, rAvTCR, dwTCRtot ) ;
	_outtext( szText ) ;

	dwMSStot += (long)wMSS ;
	rAvMSS = ( rAvMSS * (rRatCnt-1.) + (float)wMSS ) / rRatCnt ;
	_settextposition(18,1) ;
	sprintf( szText, "MSS : %6d  ( Avg = %9.3f  Tot = %9ld )  ",
			wMSS, rAvMSS, dwMSStot ) ;
	_outtext( szText ) ;

	dwPROTtot += (long)wPROT ;
	rAvPROT = ( rAvPROT * (rRatCnt-1.) + (float)wPROT ) / rRatCnt ;
	_settextposition(19,1) ;
	sprintf( szText, "PROT: %6d  ( Avg = %9.3f  Tot = %9ld )  ",
			wPROT, rAvPROT, dwPROTtot ) ;
	_outtext( szText ) ;

	dwALFAtot += (long)wALFA ;
	rAvALFA = ( rAvALFA * (rRatCnt-1.) + (float)wALFA ) / rRatCnt ;
	_settextposition(20,1) ;
	sprintf( szText, "ALFA: %6d  ( Avg = %9.3f  Tot = %9ld )  ",
			wALFA, rAvALFA, dwALFAtot ) ;
	_outtext( szText ) ;

//   Send out rates to vax if requested...

}

/* ******************************************************************
	fTime -  Routine to read real-time clock in order to have rates
				that are in counts/second.

	fcw : 21 jul 93
 * **************************************************************** */

void near fTime() {
	_asm {
	lp:   mov   ah, 2
			int   0x1a     ; get real-time clock second
			jc    lp
			mov   al, dh   ; change from bcd
			sub   ah, ah
			mov   bl, 16
			div   bl
			mov   bh, ah
			sub   ah, ah
			mov   bl, 10
			mul   bl
			add   al, bh
			mov   wSec, ax
	 }
}

void printGI (FILE *theFile, char *theString, short withTime)
{
	char 		*strPtr;
	short		cntr, DVStep;

	strPtr = theString;
	for (cntr = 0; cntr < 5; cntr++)
	{
		float theValue;
	
		strPtr = strstr(strPtr, ":"); // alpha thru energy
		strPtr++;
		if (*strPtr == ' ')
			theValue = -999;
		else
			sscanf(strPtr, "%f", &theValue);
		fprintf(theFile, "%5.2f\t", theValue);
	}
	strPtr = strstr(strPtr, ":"); // alpha
	strPtr++;
	if (*strPtr == ' ')
		DVStep = -999;
	else
		sscanf(strPtr, "%i", &DVStep);
	fprintf(theFile, "%i\t", DVStep);
	if (withTime == 1)
	{
		strPtr = strstr(strPtr, ":");
		fprintf(theFile, "%s\t", strPtr+1);
	}
}