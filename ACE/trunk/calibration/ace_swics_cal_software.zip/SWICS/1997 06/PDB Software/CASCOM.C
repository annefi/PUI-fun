/* Routines to command the CASYMS from a PC Quick C 2.5 program */
/* using a RS-232 interface to the Mikrovax.                    */
/* Authors: Raoul Paerli and Reinald Kallenbach                 */

#include <c:\qc25\include\string.h>
#include <c:\qc25\include\bios.h>
#include <c:\qc25\include\stdio.h>
#include <c:\qc25\include\conio.h>
#include <c:\qc25\include\io.h>

#define BYTE unsigned char
unsigned status;
BYTE test[20];

void com1_ini ()
	{
	  _bios_serialcom( _COM_INIT, 0,  _COM_4800 | _COM_CHR8 |
		 _COM_NOPARITY | _COM_STOP1 ) ;
	}

void send_str_vax ( BYTE vaxstr[20] )
	{ 
	  int i;
	  int imax;
	  imax = strlen( vaxstr );
	  for (i = 0; i<imax+1; i++)
	  {
		 status = _bios_serialcom( _COM_SEND, 0, vaxstr[i] ) ;
	  }
	}

/* void receive_str_vax ( BYTE vaxstr[20] ) */

void set_ion_energy ( BYTE energy_eV[20] )
	{
	 send_str_vax ( "a" );
	 send_str_vax ( energy_eV );
	}

void read_TTpos () /* ( BYTE TTpos[20] ) */
	{
	 send_str_vax ( "d" );
/*    receive_str_vax ( TTpos ); */
	}

void move_TT_alpha ( BYTE alpha_deg[20] )
	{
	 send_str_vax ( "c" );
	 send_str_vax ( "1" );
	 send_str_vax ( "0" );
	 send_str_vax ( alpha_deg );
	 send_str_vax ( "50" );
	}

void move_TT_beta ( BYTE beta_deg[20] )
	{
	 send_str_vax ( "c" );
	 send_str_vax ( "1" );
	 send_str_vax ( "1" );
	 send_str_vax ( beta_deg );
	 send_str_vax ( "50" );
	}

void move_TT_z ( BYTE z_mm[20] )
	{
	 send_str_vax ( "c" );
	 send_str_vax ( "1" );
	 send_str_vax ( "1" );
	 send_str_vax ( z_mm );
	 send_str_vax ( "50" );
	}

void move_TT_theta ( BYTE theta_deg[20] )
	{
	 send_str_vax ( "c" );
	 send_str_vax ( "1" );
	 send_str_vax ( "3" );
	 send_str_vax ( theta_deg );
	 send_str_vax ( "50" );
	}

void move_TT ( BYTE alpha_deg[20], BYTE beta_deg[20], BYTE z_mm[20],
			 BYTE theta_deg[20] )
	{
	 send_str_vax ( "c" );
	 send_str_vax ( "4" );
	 send_str_vax ( "0" );
	 send_str_vax ( "1" );
	 send_str_vax ( "2" );
	 send_str_vax ( "3" );
	 send_str_vax ( alpha_deg );
	 send_str_vax ( beta_deg );
	 send_str_vax ( z_mm );
	 send_str_vax ( theta_deg );
	 send_str_vax ( "50" );
	 send_str_vax ( "50" );
	 send_str_vax ( "50" );
	 send_str_vax ( "50" );
	}

void move_TT_abs ( BYTE alpha_deg[20], BYTE beta_deg[20], BYTE z_mm[20],
			BYTE theta_deg[20] )
	{
	 send_str_vax ( "c" );
	 send_str_vax ( "3" );
	 send_str_vax ( "0" );
	 send_str_vax ( "1" );
	 send_str_vax ( "2" );
	 send_str_vax ( alpha_deg );
	 send_str_vax ( beta_deg );
	 send_str_vax ( z_mm );
	 send_str_vax ( theta_deg );
	 send_str_vax ( "50" );
	 send_str_vax ( "50" );
	 send_str_vax ( "50" );
	}

void read_beam_monitor ( void ) /* ( BYTE beam_monitor[20] ) */
	{
	 send_str_vax ( "e" );
/*    receive_str_vax ( beam_monitor ); */
	}

void BS_position ( BYTE pos_y[20] , BYTE pos_z[20] )
	{
	 send_str_vax ( "h" );
	 send_str_vax ( pos_y );
	 send_str_vax ( pos_z );
	}

void BS_origin ()
	{
	 send_str_vax ( "f" );
	}

void BS_wait ()
	{
	 send_str_vax ( "g" );
	}

void read_BS_position () /* ( BYTE BS_position[20] ) */
	{
	 send_str_vax ( "i" );
/*    receive_str_vax ( BS_position ); */
	}

void read_BS_CEM () /* ( BYTE CEM[20] ) */
	{
	 send_str_vax ( "j" );
/*    receive_str_vax ( CEM ); */
	}

void read_BS_Fara () /* ( BYTE Fara[20] ) */
	{
	 send_str_vax ( "k" );
/*    receive_str_vax ( Fara ); */
	}

void read_Chamb_pT () /* ( BYTE pressure[20], BYTE Temperature[20] ) */
	{
	 send_str_vax ( "l" );
/*    receive_str_vax ( pressure );
	 receive_str_vax ( Temperature ); */
	}

void read_source () /* ( BYTE pressure[20], BYTE emission[20] ) */
	{
	 send_str_vax ( "m" );
/*    receive_str_vax ( pressure );
	 receive_str_vax ( emission );  */
	}

void reset_ion_energy ()
	{
	 send_str_vax ( "n" );
	}

void exit_GI ()
	{
	 send_str_vax ( "z" );
	}


