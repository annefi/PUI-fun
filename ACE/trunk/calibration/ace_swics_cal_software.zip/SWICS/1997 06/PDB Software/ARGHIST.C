/* *********************************************************************

   ARGHIST.C - A histogram display program for the ICARUS software.

   pdb : 18-Jul-93
			13-Dec-94	Expanded trend capability
			14-Dec-94	Tweaking...
			19-Dec-94	Trying to output labels for trends...
			11-Jan-95   Added new label for Ion position histogram  SEL
			01-Jul-95	Y rescale modification
			15-Jul-95	Changed displayed time from plot-time to record-time
			25-Jul-95	Added date recorded

   ********************************************************************* */

#include <stdio.h>
#include <graph.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>

#define ESC ( (char)0x1b )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define DREAL double
#define BYTE unsigned char

unsigned char font1[20] = "t'tms rmn'h8w6b" ;
unsigned char font2[20] = "t'tms rmn'h12w9b" ;
unsigned char font3[20] = "t'tms rmn'h16w12b" ;

ArgHist() {

	extern DWORD	dwCounts[4200], dwYmaxNew ;
	extern WORD		wDisplay, wXlow, wXhigh, wXinc, wLog,
						wTlow, wThigh, wDont, wParam, wIDReq ;
	extern REAL		rFudge, rOffset ;
	extern BYTE		szName[20], szTitle[80], szBegTime[10], szDate[10],
						*szTrends[48], szType[10] ;

	enum COLOR { black, blue, green, cyan, red, magenta, brown, white,
		dark_gray, light_blue, light_green, light_cyan,
		light_red, light_magenta, yellow, bright_white } ;

	DREAL	drVariance=0., drVarNum=0., drSigma=0., drFWHM=0., dcts, a ;

	DWORD	dwYtop, dwYval, dwBin=0, dwCts=0, decades=0, dwSum, dwNum,
			dwYmax=0, dwYmaxN=0, dwYmaxAuto=0, dwTotal=0, dwPeak=0 ;

	WORD	i, j, k, c, g, gg, wXrange, wXgrid, wLineStyle, wMode, wMlow,
			wMhigh, wXval, ix, iy, iarg ;

	int	iXpos, iYpos, iXpos0, iYpos0 ;

	REAL	rYhigh, rXslope, rYslope, rMean=0. ;

	BYTE	szText[80]="", ylabels[10]="",
			ysize[10]="", xlabels[10]="", szXinc[10]="", szFudge[10]="",
			szOffset[10], szTlow[10], szThigh[10], szNum[10],
			*szXlabel[19] =  {	"NEUT  Pos k1/(k1+k2)*1000",
										"ION Pos k2/(k1+k2)*1000  ",
										"  NEUTRAL tof Channel #  ",
										"    ION tof Channel #    ",
										"       NEUTRAL k1        ",
										"         ION k1          ",
										"       NEUTRAL k2        ",
										"         ION k2          ",
										" Neutral START Amplitude ",
										"   Ion START Amplitude   ",
										" NEUTRAL Stop Amplitude  ",
										"   ION Stop Amplitude    ",
										"PM R q1/(q1+q2+q3) * 1000",
										"PM T q2/(q1+q2+q3) * 1000",
										"         PM q1           ",
										"         PM q2           ",
										"         PM q3           ",
										"   PM  (q1+q2+q3)/3      ",
										"   YOUR  AD  HERE        " } ;

	if( !wDisplay )
		wDisplay = 1 ;

/* ------------- Calculate moments of the distribution ------------ */

	if( !wDont ) {
		_clearscreen(_GCLEARSCREEN) ;
		printf( "Thinking...\n" ) ;
		wMlow = wXlow ;
		wMhigh = wXhigh ;
		for( k=0; k<2; k++ ) {
			dwYmaxN	= 0 ;
			dwSum	= 0 ;
			dwNum	= 0 ;
			for( i=wMlow; i<=wMhigh; i++ ) {
				dwSum += dwCounts[i] ;
				dwNum += dwCounts[i] * i ;
				if( dwCounts[i] >= dwYmaxN ) {
					dwYmaxN	= dwCounts[i] ;
					wMode	= i ;
				}
			}
			if( k == 0 ) dwTotal = dwSum ;
			if( dwSum > 0 )
				rMean	= (float)dwNum / (float)dwSum + 0.5 ;
			else
				rMean	= -99. ;
			drVarNum = 0. ;
			for( j=wMlow; j<=wMhigh; j++ ) {
				drVarNum += (double)dwCounts[j] * pow( fabs( (double)j - (double)rMean ), 2 ) ;
			}
			if( dwSum > 1 ) {
				drVariance = drVarNum / (double)(dwSum - 1) ;
				drSigma	= sqrt( drVariance ) ;
			}
			else {
				drVariance = -99. ;
				drSigma	= -99. ;
				break ;
			}
			drFWHM	= 2.354 * drSigma ;

			printf( "For %d to %d, Mean: %f   Sigma: %lf   FWHM: %lf\n",
				wMlow, wMhigh, rMean, drSigma, drFWHM ) ;

			wMlow = (WORD)( rMean - (REAL)drSigma*3. ) ;
			if( wMlow < 0 ) wMlow = 0 ;
			wMhigh = (WORD)( rMean + (REAL)drSigma*3. ) ;
			if( wMhigh > 4100 ) wMhigh = 4100 ;
		}
		wMlow = (WORD)( rMean - (REAL)drSigma*2. ) ;
		if( wMlow < 0 ) wMlow = 0 ;
		wMhigh = (WORD)( rMean + (REAL)drSigma*2. ) ;
		if( wMhigh > 4100 ) wMhigh = 4100 ;
		if( dwTotal ) {
			for( i=wMlow; i<=wMhigh; i++ )
				dwPeak += dwCounts[i] ;
		}
	}

/* ------------------ Calculate slopes, etc... ------------------- */

	for( i=wXlow; i<=wXhigh; i+=wXinc ) {
		dwBin = 0 ;
		for( j=0; j<wXinc; j++ )
			dwBin += dwCounts[i+j] ;
		if( dwBin > dwYmaxAuto ) dwYmaxAuto = dwBin ;
	}

/* ------------ Calculate slopes and Y-scale ------------------ */

	if( dwYmaxNew == 0 ) {
		rYhigh = (float) dwYmaxAuto ;
		dwYtop = ( (DWORD)(rYhigh/10.) + 1 ) * 10 ;
	}
	else {
		dwYtop = dwYmaxNew + 1 ;
	}
	wXgrid = (WORD)( (float)( wXhigh - wXlow ) / 10. + 0.5 ) ;
	if( wXgrid <= 0 ) wXgrid = 1 ;
	wXrange = 10 * wXgrid ;
	wXhigh = wXrange + wXlow ;
	rXslope = 500./(float)(wXrange) ;
	if( wLog )
		decades = (DWORD)( log10( (double)dwYtop ) + 1 ) ;
	else
		decades = dwYtop ;
	rYslope = 400./(REAL)decades ;

/* ------------ Enter video mode and draw a border -------------- */

	_setvideomode(_VRES16COLOR) ;
	_rectangle( _GBORDER, 99,39,601,441 ) ;

/* -------------------------------------------------------------
   Draw background grid lines in dark grey
   ------------------------------------------------------------- */
	wLineStyle = _getlinestyle() ;
	for( ix=150; ix<=550; ix=ix+50 ) {
		_moveto( ix, 36 ) ;
		_lineto( ix, 39 ) ;
		_setcolor( dark_gray ) ;
		_setlinestyle( 0xAAAA ) ;
		_lineto( ix, 441 ) ;
		_setlinestyle( 0xFFFF ) ;
		_setcolor( light_red ) ;
		_lineto( ix, 444 ) ;
	}
	if( !wLog ) {
		for( iy=80; iy<=400; iy=iy+40 ) {
			_moveto( 96, iy ) ;
			_lineto( 99, iy ) ;
			_setcolor( dark_gray ) ;
			_setlinestyle( 0xAAAA ) ;
			_lineto( 601, iy ) ;
			_setlinestyle( 0xFFFF ) ;
			_setcolor( light_red ) ;
			_lineto( 604, iy ) ;
		}
	}
	else {
		for( j=0; j<decades; j++ ) {
			_moveto( 96, 440-(400/(WORD)decades)*j ) ;
			_setcolor( dark_gray ) ;
			for( i=1; i<10; i++ ) {
				a = (double)i ;
				iy = (int)( (440-(400/decades)*j) - (log10(a)*(400/decades)) ) ;
				if( i == 1 )
					_moveto( 93, iy ) ;
				else
					_moveto( 96, iy ) ;
				_lineto( 99, iy ) ;
				_setcolor( dark_gray ) ;
				_setlinestyle( 0xAAAA ) ;
				_lineto( 601, iy ) ;
				_setlinestyle( 0xFFFF ) ;
				_setcolor( light_red ) ;
				_lineto( 604, iy ) ;
			}
		}
	}
	_setlinestyle( wLineStyle ) ;

/* -------------------------------------------------------------
   register all available fonts
   ------------------------------------------------------------- */

	if(_registerfonts( "tmsrb.fon" ) == -1 )
		printf( "\aFONTS are not available" ) ;
	else {

/* -------------------------------------------------------------
   add tic mark labels
   ------------------------------------------------------------- */

		_setfont( font2 ) ;
		_setcolor( light_red ) ;
		for( g=0; g<=10; g++ ) {
			wXval = wXlow + ( g * wXgrid );
			itoa( wXval, xlabels, 10 ) ;
			_moveto( (g*50)+101-(3*strlen( xlabels )), 445 ) ;
			_outgtext( xlabels ) ;
		}
		if( !wLog ) {
			for( gg=0; gg<=10; gg++ ) {
				dwYval = dwYtop - ( (DWORD)gg * ( (REAL)dwYtop / 10. ) ) ;
				ltoa( dwYval, ylabels, 10 ) ;
				_moveto( ( 95 - 5 * strlen( ylabels ) ), 35+(gg*40) ) ;
				_outgtext( ylabels ) ;
			}
		}
		else {
			for( i=1; i<decades; i++ ) {
				a = (double)i ;
				_moveto( 70, 435-(i*400/(WORD)decades) ) ;
				gcvt( pow( 10., a ), 7, szNum ) ;
				_outgtext( szNum ) ;
			}
		}

/* -------------------------------------------------------------
   put current date in lower right corner
   ------------------------------------------------------------- */

		_setcolor( light_cyan );
		sprintf( szText, "%8s on %8s", szBegTime, szDate ) ;
		_moveto( 500, 462 );
		_outgtext( szText );

/* -------------------------------------------------------------
   put current parameters in top left corner
   ------------------------------------------------------------- */

		_setfont( font2 ) ;
		_setcolor( light_green ) ;

		_moveto( 3, 50 ) ;
		sprintf( szText, "Ch/Bin: %7d", wXinc ) ;
		_outgtext( szText ) ;
		_moveto( 3, 62 ) ;
		sprintf( szText, "Factor: %7.2f", rFudge ) ;
		_outgtext( szText ) ;
		_moveto( 3, 74 ) ;
		sprintf( szText, "Offset: %7.2f", rOffset ) ;
		_outgtext( szText ) ;

		sprintf( szText, "Mean: %7.2f", rMean ) ;
		_moveto( 3, 94 ) ;
		_outgtext( szText ) ;
		sprintf( szText, "Sigma: %7.2lf", drSigma ) ;
		_moveto( 3, 106 ) ;
		_outgtext( szText ) ;
		sprintf( szText, "Total: %7.2ld", dwTotal ) ;
		_moveto( 3, 126 ) ;
		_outgtext( szText ) ;
		sprintf( szText, "Peak: %7ld", dwPeak ) ;
		_moveto( 3, 138 ) ;
		_outgtext( szText ) ;
		sprintf( szText, "Backgr: %7ld", (dwTotal-dwPeak) ) ;
		_moveto( 3, 150 ) ;
		_outgtext( szText ) ;
		sprintf( szText, "Yslope: %7.2f", rYslope ) ;
		_moveto( 3, 162 ) ;
		_outgtext( szText ) ;

		if( !strncmp( strlwr( szType ), "e", 1 ) ) {
			_moveto( 3, 182 ) ;
			sprintf( szText, " Tlow: %7d", wTlow ) ;
			_outgtext( szText ) ;
			_moveto( 3, 194 ) ;
			sprintf( szText, "Thigh: %7d", wThigh ) ;
			_outgtext( szText ) ;
		}

/* -------------------------------------------------------------
   put title along the top and add the X- and Y-axis labels
   ------------------------------------------------------------- */

		_setfont( font3 ) ;
		_setcolor( bright_white );
		_moveto( 100, 20 );
		_outgtext( szTitle ) ;
		_moveto( 250, 460 );

		_moveto( 10, 217 );
		_outgtext( "COUNTS" );
		_setcolor( light_cyan ) ;
		_moveto( 100, 460 );
		_outgtext( szName ) ;

		_unregisterfonts() ;
	}

/* -------------------------------------------------------------
   Now draw histogram
   ------------------------------------------------------------- */

	_setcolor( yellow ) ;
	iXpos0 = 100 ;
	iYpos0 = 440 ;
	for( i=wXlow; i<=wXhigh; i+=wXinc ) {
		dwCts = 0 ;
		for( j=0; j<wXinc; j++ )
			dwCts += dwCounts[i+j] ;
		iXpos = ( (int)( ( i - wXlow + wXinc ) * rXslope ) + 100 ) ;
		if( wLog ) {
			dcts = (double)dwCts ;
			if( dcts <= 0. ) dcts = 1. ;
			iYpos = ( 440 - (int)( log10(dcts)*(double)rYslope ) ) ;
		}
		else
			iYpos = ( 440 - (int)( (REAL)dwCts * rYslope ) ) ;
		if( iYpos<40 )
			iYpos = 37 ;
		if( iYpos>440 )
			iYpos = 442 ;
		_moveto( iXpos0, iYpos0 ) ;
		_lineto( iXpos0, iYpos ) ;
		_lineto( iXpos, iYpos ) ;
		iXpos0 = iXpos ;
		iYpos0 = iYpos ;
	}

}
