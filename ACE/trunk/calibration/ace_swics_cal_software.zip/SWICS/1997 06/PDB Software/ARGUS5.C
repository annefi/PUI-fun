//
//              ARGUS5.C
//
//              pdb : 19-Nov-95
//                              20-Nov-95
//                                 rka : 22-Nov-95

#include <math.h>
#include <sys\timeb.h>
#include <stdio.h>
#include <string.h>
#include <graph.h>
#include <time.h>

#define ESC ((char) 0x1B )
#define WORD unsigned int
#define DWORD unsigned long
#define REAL float
#define BYTE unsigned char
#define getrandom( min, max ) ((rand() % (int)(((max)+1) - (min))) + (min))

int   iHead=140, iPHA=6, iRates=22, iHK=42, iCmds=100, iDVS=0 ;
WORD  near wTOF, near wID, near wEGY, wMass, wMPQ, wSource=0, wLev=0,
		near wSecReq=1, near wCmd, near wSec, near wSim=0, near wNumSecs,
		wLastSec=0, wLog=0, wDont=0, wIDReq=0, wHelp=0, wDisplay=0,
		near wFSR, near wDCR, near wTCR, near wMSS, near wPROT, near wALFA ;
BYTE  near bHK, szTitle[70], szName[40]="", szID[3]="ACE",
		szBegTime[10], szDate[10], szType[10] ;

void near fPHARead() ;
void near fCommand() ;
void near fRates() ;
void near fTime() ;
void near delay() ;

FILE *fp ;

int main( int argc, char *argv[] ) {

	time_t ltime ;
	DWORD   dwRecorded=0, dwFSRsum, dwDCRsum, dwTCRsum, dwMSSsum,
			dwPROTsum, dwALFAsum, oldltime=0 ;

	WORD  i, j, c, wEvents=0, wRates=0, wGndHK[12], wVfHK[10], wHK, wOpts=1,
			wHKcvt, wPHACtr=0, wRecord=0, wFile=0,  wRefresh=0, wParam=0,
			wBeep=0, wDone=0, wCASYMS=0, wTarget=0, wHKCtr=0, wDelay=0 ;

	int     iCtr = 0 ;

	REAL  rHK, rOutMin, rOutMax, rOutInc, rMidMin, rMidMax, rMidInc, rInnMin,
			rInnMax,        rInnInc, out, mid, inn, a, b, th, z, e , dpps ,
			rRelMin , rRelMax, rRelInc ;

	BYTE  szText[80]="", szCommand[80], bYorN, *szString, szTime[10],
			szDType[10]="", szLev[5], g, szAlpha[20]="", szBeta[20]="",
			szTheta[20]="", szZeta[20]="", szEIon[20]="", bMorA,
			szCASYMS[120]="", szComment[120]="CASYMS Information Recorded - ",
			szBuffer[50]="",
			szBlank[80]="                                                      ",
			szText2[80]="", szCmd[2]="CD", szGI[2]="GI",
			szHist[40]="", szHK[2]="HK", szRR[2]="RR", szPH[2]="PH",
			szOldCommand1[20]="", szOldCommand2[20]="", szOldCommand3[20]="",
			szOldCommand4[20]="", szOldCommand5[20]="" ;

	_clearscreen(_GCLEARSCREEN) ;
	if( argc > 1 ) wSim = 1 ;
	srand( (unsigned)time( NULL ) ) ;

/* ------------------ Main Loop ---------------------------------- */

	_strtime( szBegTime ) ;
	_strdate( szDate ) ;

	while( 1 ) {
		fflush( stdin ) ;
		if( kbhit() ) {
			c = getch() ;

			switch( tolower(c) ) {

			case 'o' :
				fflush( stdin ) ;
				_clearscreen(_GCLEARSCREEN) ;
				wOpts = 1 ;
			break ;

			case 'x' :
				exit(0) ;
			break ;

/* ---------------------- Control CASYMS -------------------------- */

			case 'g' :
				_setvideomode(_DEFAULTMODE) ;
				_settextcolor(15) ;
				_settextposition(1,30) ;
				_outtext( "CASYMS CONTROL" ) ;
				fflush( stdin ) ;
				_settextcolor(10) ;
				_settextposition(5,1) ;
				_outtext( "Manual or Automatic control? [m or a]: " ) ;
				bMorA = getch() ;

// Manual control of CASYMS...

				if( tolower(bMorA) == 'm' ) {
			 while(!wDone) {
					_clearscreen(_GCLEARSCREEN) ;
					_settextposition(1,30) ;
					_settextcolor(15) ;
					_outtext( "MANUAL CONTROL OF CASYMS" ) ;
					com1_ini() ;
					fflush(stdin) ;
					_settextcolor(10) ;
					_settextposition(5,1) ;
					_outtext( "Change Alpha, Beta, Theta, Zeta, E, or eXit? [a/b/t/z/e/x]: " ) ;
					g = getch() ;
					switch( tolower(g) ) {
						case 'a' :                                      // alpha
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change alpha to what value? [eg. 5.3]: " ) ;
							gets( szAlpha ) ;
							move_TT_alpha( szAlpha ) ;
						break ;
						case 'b' :                                      // beta
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change beta to what value? [eg. 5.3]: " ) ;
							gets( szBeta ) ;
							move_TT_beta( szBeta ) ;
						break ;
						case 't' :                                      // theta
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change theta to what value? [eg. 5.3]: " ) ;
							gets( szTheta ) ;
							move_TT_theta( szTheta ) ;
						break ;
						case 'z' :                                      // zeta
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change zeta to what value? [eg. 5.3]: " ) ;
							gets( szZeta ) ;
							move_TT_z( szZeta ) ;
						break ;
						case 'e' :                                      // ion energy
							fflush(stdin) ;
							_settextposition(6,1) ;
							_outtext( "Change ion energy to what value? [eg. 35.21]: " ) ;
							gets( szEIon ) ;
							set_ion_energy( szEIon ) ;
						break ;
							case 'x' :                                      // exit
								wDone = 1 ;
							break ;
					}
					}

// read CASYMS information

					read_BS_Fara() ;
					read_Chamb_pT() ;
					read_source() ;
					BS_wait() ;
					_strtime( szTime ) ;
					send_time( szTime ) ;
					_settextposition(25,1) ;
					_settextcolor(15) ;
					sprintf( szCASYMS, "a:%s b:%s th:%s z:%s E:%s @:%s",
						szAlpha, szBeta, szTheta, szZeta, szEIon, szTime ) ;
					_outtext( szCASYMS ) ;
					wDone = 0 ;
				}

// Automatic Control of CASYMS...

				else if( tolower(bMorA) == 'a' ) {
					_clearscreen(_GCLEARSCREEN) ;
					_settextposition(1,30) ;
					_settextcolor(15) ;
					_outtext( "AUTOMATIC CONTROL OF CASYMS" ) ;
					com1_ini() ;
					fflush(stdin) ;
					_settextcolor(14) ;
					_settextposition(5,1) ;
					_outtext( "Geometry factor, eFficiency, or Energy scan or eXit? [g/f/e/x]: " ) ;
					g = getch() ;
					wCASYMS = 1 ;
					switch( tolower(g) ) {
						case 'g' :
						fflush(stdin) ;
						_settextposition(6,1) ;
						_outtext( "Outer loop is Theta. Enter min, max, inc: " ) ;
							scanf( "%f, %f, %f", &rOutMin, &rOutMax, &rOutInc ) ;
							_settextposition(7,1) ;
							_outtext( "Middle loop is Beta. Enter min, max, inc: " ) ;
							scanf( "%f, %f, %f", &rMidMin, &rMidMax, &rMidInc ) ;
							_settextposition(8,1) ;
							_outtext( "Inner loop is Energy. Enter min, max, inc: " ) ;
							scanf( "%f, %f, %f", &rInnMin, &rInnMax, &rInnInc ) ;

// Prepare to record data ...

							wRecord = 1 ;
							dwRecorded = 0 ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "Enter file name: " ) ;
							gets( szName ) ;
							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							fflush( stdin ) ;
							_settextposition(25,1) ;
							_outtext( "Enter run title: " ) ;
							gets( szTitle ) ;
							fp = fopen( szName, "w+b" ) ;
							fwrite( szID, 3, 1, fp ) ;
							fwrite( &iHead, 2, 1, fp ) ;
							fwrite( &iPHA, 2, 1, fp ) ;
							fwrite( &iRates, 2, 1, fp ) ;
							fwrite( &iHK, 2, 1, fp ) ;
							fwrite( &iCmds, 2, 1, fp ) ;
							fwrite( szName, 40, 1, fp ) ;
							fwrite( szTitle, 70, 1, fp ) ;
							fwrite( szDate, 10, 1, fp ) ;
							fwrite( szGI, 2, 1, fp ) ;
							fwrite( szCASYMS, 120, 1, fp ) ;
							com1_ini() ;
					break ;

					case 'f' :
						fflush(stdin) ;
						_settextposition(6,1) ;
						_outtext( "Outer loop is Theta. Enter min, max, inc: " ) ;
							scanf( "%f, %f, %f", &rOutMin, &rOutMax, &rOutInc ) ;
							_settextposition(7,1) ;
							_outtext( "Middle loop is nominal beam energy. Enter min, max, inc: " ) ;
							scanf( "%f, %f, %f", &rMidMin, &rMidMax, &rMidInc ) ;
							_settextposition(8,1) ;
							_outtext( "Inner loop is relative energy. Enter min (0.9), max (1.1), inc (0.02): " ) ;
							scanf( "%f, %f, %f", &rRelMin, &rRelMax, &rRelInc ) ;

// Prepare to record data ...

							wRecord = 1 ;
							dwRecorded = 0 ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "Enter file name: " ) ;
							gets( szName ) ;
							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							fflush( stdin ) ;
							_settextposition(25,1) ;
							_outtext( "Enter run title: " ) ;
							gets( szTitle ) ;
							fp = fopen( szName, "w+b" ) ;
							fwrite( szID, 3, 1, fp ) ;
							fwrite( &iHead, 2, 1, fp ) ;
							fwrite( &iPHA, 2, 1, fp ) ;
							fwrite( &iRates, 2, 1, fp ) ;
							fwrite( &iHK, 2, 1, fp ) ;
							fwrite( &iCmds, 2, 1, fp ) ;
							fwrite( szName, 40, 1, fp ) ;
							fwrite( szTitle, 70, 1, fp ) ;
							fwrite( szDate, 10, 1, fp ) ;
							fwrite( szGI, 2, 1, fp ) ;
							fwrite( szCASYMS, 120, 1, fp ) ;
							com1_ini() ;
					break ;

					case 'e' :
						fflush(stdin) ;
						_settextposition(6,1) ;
						_outtext( "Outer loop is nominal beam Energy. Enter min, max, inc: " ) ;
							scanf( "%f, %f, %f", &rOutMin, &rOutMax, &rOutInc ) ;
							_settextposition(7,1) ;
							_outtext( "Middle loop is beta. Enter min, max, inc: " ) ;
							scanf( "%f, %f, %f", &rMidMin, &rMidMax, &rMidInc ) ;
							_settextposition(8,1) ;
							_outtext( "I. l. is rel. beam Energy. Enter min(0.9), max(1.1), inc(0.01): " ) ;
							scanf( "%f, %f, %f", &rRelMin, &rRelMax, &rRelInc ) ;

// Prepare to record data ...

							wRecord = 1 ;
							dwRecorded = 0 ;
							_settextposition(25,1) ;
							fflush( stdin ) ;
							_outtext( "Enter file name: " ) ;
							gets( szName ) ;
							_settextposition(25,1) ;
							_outtext( szBlank ) ;
							fflush( stdin ) ;
							_settextposition(25,1) ;
							_outtext( "Enter run title: " ) ;
							gets( szTitle ) ;
							fp = fopen( szName, "w+b" ) ;
							fwrite( szID, 3, 1, fp ) ;
							fwrite( &iHead, 2, 1, fp ) ;
							fwrite( &iPHA, 2, 1, fp ) ;
							fwrite( &iRates, 2, 1, fp ) ;
							fwrite( &iHK, 2, 1, fp ) ;
							fwrite( &iCmds, 2, 1, fp ) ;
							fwrite( szName, 40, 1, fp ) ;
							fwrite( szTitle, 70, 1, fp ) ;
							fwrite( szDate, 10, 1, fp ) ;
							fwrite( szGI, 2, 1, fp ) ;
							fwrite( szCASYMS, 120, 1, fp ) ;
							com1_ini() ;
					break ;

		  case 'x' :
		  break ;

				} //which type of scan

				} //auto

				else {
					printf( "\a" ) ;
					exit(-1) ;
				}
			break ;
				
			} //switch

		} //kbhit

/* ---------------------- OPTIONS ------------------------------ */

		if( wOpts ) {
			_settextcolor(15) ;
			_settextposition(4,30) ;
			_outtext( "USER OPTIONS\n" ) ;
			_settextposition(5,30) ;
			_settextcolor(7) ;
			_outtext( __DATE__ ) ;
			_settextcolor(14) ;
			_settextposition(7,22) ;
			_outtext( "g - GI interface to CASYMS\n" ) ;
			_settextposition(8,22) ;
			_outtext( "     m - Manual control\n" ) ;
			_settextposition(9,22) ;
			_outtext( "     a - Automatic scans\n" ) ;
			_settextposition(10,22) ;
			_outtext( "o - show these options\n" ) ;
			_settextposition(11,22) ;
			_outtext( "x - exit program.\n" ) ;
			_settextcolor(15) ;
			wOpts = 0 ;
		}

/* ----------------------- AUTOMATED SCANS --------------------- */

		if( wCASYMS ) {
			_settextposition(25,1) ;

			for( out=rOutMin; out<=rOutMax; out+=rOutInc ) {
				gcvt( out, 5, szBuffer ) ;
				switch( tolower(g) ) {
					case 'g' :
						move_TT_theta( szBuffer ) ;
						strncpy( szTheta, szBuffer, 20 ) ;
					break ;

					case 'f' :
						move_TT_theta( szBuffer ) ;
						strncpy( szTheta, szBuffer, 20 ) ;
					break ;

					case 'e' :
						dpps = log (out/445.88)/log(1.03618) ;
						wLev = (WORD)dpps ;
						rInnMin = rRelMin*out ;
						rInnMax = rRelMax*out ;
						rInnInc = rRelInc*out ;
						if( wLev>127 ) wLev+=103 ;
						if( wLev<256 ) {
							wCmd = 0x0900 + wLev ;
							fCommand() ;
						}
						else printf( "\a" ) ;
					break ;
				}
				for( mid=rMidMin; mid<=rMidMax; mid+=rMidInc ) {
					switch( tolower(g) ) {

					case 'g' :
						gcvt( mid, 5, szBuffer ) ;
						move_TT_beta( szBuffer ) ;
						strncpy( szBeta, szBuffer, 20 ) ;
					break ;

					case 'f' :
						dpps = log (mid/445.88)/log(1.03618) ;
						wLev = (WORD)dpps ;
						rInnMin = rRelMin*mid ;
						rInnMax = rRelMax*mid ;
						rInnInc = rRelInc*mid ;
						if( wLev>127 ) wLev+=103 ;
						if( wLev<256 ) {
							wCmd = 0x0900 + wLev ;
							fCommand() ;
						}
						else printf( "\a" ) ;
					break ;

					case 'e' :
						gcvt( mid, 5, szBuffer ) ;
						move_TT_beta( szBuffer ) ;
						strncpy( szBeta, szBuffer, 20 ) ;
					break ;

					}    //switch ( tolower(g) )
					for( inn=rInnMin; inn<=rInnMax; inn+=rInnInc ) {
						gcvt( inn, 5, szBuffer ) ;
						set_ion_energy( szBuffer ) ;
						strncpy( szEIon, szBuffer, 20 ) ;

// read CASYMS info...
						time( &ltime ) ;
						if( ltime>=oldltime+1800 ) {
							oldltime = ltime ;
							BS_origin() ;
							read_BS_CEM() ;
							fTime() ;
							wTarget = wSec + 59 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
							read_BS_CEM() ;
							fTime() ;
							wTarget = wSec + 6 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
							read_BS_CEM() ;
							fTime() ;
							wTarget = wSec + 6 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
							read_BS_Fara() ;
							fTime() ;
							wTarget = wSec + 6 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
							read_BS_Fara() ;
							fTime() ;
							wTarget = wSec + 6 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
							read_BS_Fara() ;
							fTime() ;
							wTarget = wSec + 6 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
							read_Chamb_pT() ;
							read_source() ;
							BS_wait() ;
							fTime() ;
							wTarget = wSec + 30 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
//                                                      move_TT( szAlpha, szBeta, szZeta, szTheta ) ;
							fTime() ;
							wTarget = wSec + 60 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
							_strtime( szTime ) ;
							send_time( szTime ) ;
							if( wRecord ) {
								strcat( szComment, szTime ) ;
								fwrite( szGI, 2, 1, fp ) ;
								fwrite( szComment, 120, 1, fp ) ;
								sprintf( szComment, "%s", "CASYMS Information Recorded - ") ;
							}
						}

				sprintf( szCASYMS, "a:%s b:%s th:%s z:%s E:%s DVS:%d @:%s",
						szAlpha, szBeta, szTheta, szZeta, szEIon, wLev, szTime ) ;
						_settextposition(25,1) ;
						_outtext( szCASYMS ) ;
				if( wRecord ) {
					fwrite( szGI, 2, 1, fp ) ;
					fwrite( szCASYMS, 120, 1, fp ) ;
				}

// wait 10 seconds...
							fTime() ;
							wTarget = wSec + 10 ;
							if( wTarget > 59 ) wTarget -= 60 ;
							while( wSec!=wTarget ) {
								fTime() ;
							}
// Reset accumulators...
							wCmd = 0xf000 ;
							fCommand() ;

// Collect and record data for 59 seconds...
							wTarget = wSec + 59 ;
							if( wTarget > 59 ) wTarget -= 60 ;

							iCtr = 0 ;
							dwFSRsum=dwDCRsum=dwTCRsum=dwMSSsum=dwPROTsum=dwALFAsum=0 ;
							while( wSec!=wTarget ) {
								if( kbhit() )
									if( (c=getch()) == 'x' ) exit(-1) ;

								fTime() ;
								if( !(wSec%wSecReq) && (wSec != wLastSec) ) {
									wLastSec = wSec ;
// HK...
									if( wRecord )
										fwrite( szHK, 2, 1, fp ) ;

									for( i=0; i<12; i++ ) {                // ground-ref HK
										wCmd = i ;
										fCommand() ;
										wHK = (WORD)bHK ;
										if( wRecord && (i!=5) )
											fwrite( &wHK, 2, 1, fp ) ;
									}
									for( i=0; i<8; i++ ) {                 // Vf-ref HK
										wCmd = 512+i ;
										fCommand() ;
										wHK = (WORD)bHK ;
										if( wRecord )
											fwrite( &wHK, 2, 1, fp ) ;
									}
									wCmd = 12 ;
									fCommand() ;
									wHK = (WORD)bHK ;
									if( wRecord )
										fwrite( &wHK, 2, 1, fp ) ;

									wCmd = 14 ;
									fCommand() ;
									wHK = (WORD)bHK ;
									if( wRecord )
										fwrite( &wHK, 2, 1, fp ) ;
// RATES...
									fRates() ;

									if( wRecord && iCtr ) {
										_strtime( szTime ) ;
										fwrite( szRR, 2, 1, fp ) ;
										fwrite( &wFSR, 2, 1, fp ) ;
										fwrite( &wDCR, 2, 1, fp ) ;
										fwrite( &wTCR, 2, 1, fp ) ;
										fwrite( &wMSS, 2, 1, fp ) ;
										fwrite( &wPROT, 2, 1, fp ) ;
										fwrite( &wALFA, 2, 1, fp ) ;
										fwrite( szTime, 10, 1, fp ) ;
									}
									if( iCtr ) {
										dwFSRsum += (DWORD)wFSR ;
										dwDCRsum += (DWORD)wDCR ;
										dwTCRsum += (DWORD)wTCR ;
										dwMSSsum += (DWORD)wMSS ;
										dwPROTsum += (DWORD)wPROT ;
										dwALFAsum += (DWORD)wALFA ;
									}
									iCtr++ ;

								} //wsec...
// PHA...
								fPHARead() ;
								if( wID < 4 ) {               // no PHA ready if ID=0x223
									wPHACtr++ ;
									if( wRecord ) {
										fwrite( szPH, 2, 1, fp ) ;
										fwrite( &wEGY, 2, 1, fp ) ;
										fwrite( &wTOF, 2, 1, fp ) ;
										fwrite( &wID, 2, 1, fp ) ;
										dwRecorded++ ;
									}
								}
								fTime() ;

							} // recording for 16 seconds...

							_settextposition(1,1) ;
							_settextcolor(15) ;
							_outtext("      FSR        DCR        TCR        MSS       PROT       ALFA" ) ;
							_settextcolor(11) ;
			  _settextposition(2,1) ;
							sprintf( szText, "%10ld %10ld %10ld %10ld %10ld %10ld\n", dwFSRsum,
									dwDCRsum, dwTCRsum, dwMSSsum, dwPROTsum, dwALFAsum ) ;
							_outtext( szText ) ;
							_settextposition(25,1) ;
							_settextcolor(14) ;

						} // energy
					} // beta
				} // theta

			wCASYMS = 0 ;
			wRecord = 0 ;
			exit_GI() ;

		} // casyms

	} // while

} // main

/* ******************* ROUTINES *************************************
	******************************************************************

	fPHARead -  Routine to read PHA data from SWICS using Fred Wire's
					DPU Simulator card.

				-  wID = 0,1,2,3 if valid data;
						 = 0x223 if timeout (i.e. no valid data)

	fcw : 22 jul 93
	pdb : 30 sep 94   (changed addresses from 30n -> 22n)
	fcw : 19 oct 94   (added code for:
								1) ignore data if cnt ok not set
								2) start amp is now 10bits for non PM data
	fcw : 16 oct 95   changed to read SWICS pha data
								10 bits TOF, 8 bits energy, 2 bits ID

 * ***************************************************************** */

void near fPHARead() {

	if( wSim ) {
		wID = getrandom( 0,3 ) ;
		if( wID == 0 ) {
			wEGY = getrandom( 0,255 ) ;
			wTOF = getrandom( 0,1023 ) ;
		}
		else if( wID == 1 ) {
			wEGY = getrandom( 0,80 ) ;
			wTOF = getrandom( 0,300 ) ;
		}
		else if( wID == 2 ) {
			wEGY = getrandom( 80,160 ) ;
			wTOF = getrandom( 300,600 ) ;
		}
		else if( wID == 3 ) {
			wEGY = getrandom( 160, 255 ) ;
			wTOF = getrandom( 600,1023 ) ;
		}
	}
	else {
	_asm {
			mov   dx, 0x223   ;  wait for pha data
			mov   wID, dx     ;  set no data flag

			in    al, (dx)
			mov   bl, al      ;save for clock pulse count check
			and   al, 4       ;check pha available bit
			jz    rdphaex     ;bye bye; no data available

rdphaok: mov   dx, 0x228   ;  read wTOF
			in    ax, (dx)
			mov   bl,ah       ;  save 2 lsbits of energy
			and   ax, 0x3ff
			mov   wTOF, ax

			mov   dx, 0x22a   ;  read wEGY & ID
			in    ax, (dx)
			and   ah, 0x3     ;  mask ID bits in ah
			mov   wID, ah
			mov   wID+1, 0
			and   ax, 0x3f    ;  mask 6 msbits of energy in ax
			shl   ax, 1       ;  shift over 2 places
			shl   ax, 1
			shr   bl, 1       ;  shift 2 lsbits over 2 places
			shr   bl, 1
			and   bl, 3
			or    al, bl      ;  combine them
			mov   wEGY, ax

			mov   dx, 0x22f   ;  clr pha available bit
			in    al, (dx)

rdphaex: nop
	}
	}
}

/* ******************************************************************
	fCommand -  Routine to send commands to MTOF using Fred Wire's DPU
					Simulator card, and return 8 bits of hk data.

	fcw : 20 jul 93
 * **************************************************************** */

void near fCommand() {

	if( wSim ) {
		bHK = (BYTE)wCmd ;
	}
	else {

	_asm {
		mov   dx, 0x223   ;read status (wait for ready)
lp0:  in    al, (dx)
		and   al, 1
		jz    lp0

		mov   dx, 0x220   ;cmd/data addr
		mov   ax, wCmd    ;get cmd
		out   (dx), ax    ;send cmd/data

		mov   ax,1000   ;wait for status to go false
lp01: dec   ax
		jnz   lp01

		mov   dx, 0x223   ;read status (wait for ready)
lp1:  in    al, (dx)
		and   al, 1
		jz    lp1

;  read data and store

		mov   dx, 0x221   ;mid hk byte
		in    al, (dx)
		sub   ah, ah
		mov   bHK, ax
	}
	}
}

/* ******************************************************************
	fRates - Routine to read rate accumulator data from MTOF using
				Fred Wire's DPU Simulator card.

	fcw : 20 jul 93
	pdb : 22 jul 93   took out delays
	fcw : 02-aug-93   added reads of ufsr, mult starts, & mult dcr's
	fcw : 18 oct 95   modified to read swics rates

 * **************************************************************** */

void near fRates() {

	if( wSim ) {
		wFSR = getrandom( 0,32767 ) ;
		wDCR = getrandom( 0,32767 ) ;
		wTCR = getrandom( 0,32767 ) ;
		wMSS = getrandom( 0,32767 ) ;
		wPROT = getrandom( 0,32767 ) ;
		wALFA = getrandom( 0,100 ) ;
	}
	else {

	_asm {
		mov   dx, 0x220   ;send acc read and store cmd
		mov   ax, 0xf007
		out   (dx), ax

;  now wait 10msec for acc's to be read from bubble;
;  a command takes 580usec, so do 18 cmds, then read acc's

		mov   cx, 18

lp0:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp0

lp_wait_10ms:
		mov   ax, 0x0000  ;read a hk parameter and ignore data
		mov   dx, 0x220
		out   (dx), ax

lp1:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp1

		loop  lp_wait_10ms

;  now read acc's

;  1'st fsr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x0209
		out   (dx), ax

lp9:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lp9

		mov   dx, 0x220   ;read nsr
		in    ax, (dx)
		mov   wFSR, ax

;  2'nd dcr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020a
		out   (dx), ax

lpa:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpa

		mov   dx, 0x220   ;read dcr
		in    ax, (dx)
		mov   wDCR, ax

;  3'rd tcr
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020b
		out   (dx), ax

lpb:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpb

		mov   dx, 0x220   ;read tcr
		in    ax, (dx)
		mov   wTCR, ax

;  4'th mss rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020c
		out   (dx), ax

lpc:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpc

		mov   dx, 0x220   ;read mss rate
		in    ax, (dx)
		mov   wMSS, ax

;  5'th proton rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020d
		out   (dx), ax

lpd:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpd

		mov   dx, 0x220   ;read proton rate
		in    ax, (dx)
		mov   wPROT, ax

;  & last alpha rate
		mov   dx, 0x220   ;send acc read cmd
		mov   ax, 0x020e
		out   (dx), ax

lpe:  mov   dx, 0x223
		in    al, (dx)
		and   al, 1
		jz    lpe

		mov   dx, 0x220   ;read alpha rate
		in    ax, (dx)
		mov   wALFA, ax

	}
	}
}

/* ******************************************************************
	fTime -  Routine to read real-time clock in order to have rates
				that are in counts/second.

	fcw : 21 jul 93
 * **************************************************************** */

void near fTime() {
	_asm {
	lp:   mov   ah, 2
			int   0x1a     ; get real-time clock second
			jc    lp
			mov   al, dh   ; change from bcd
			sub   ah, ah
			mov   bl, 16
			div   bl
			mov   bh, ah
			sub   ah, ah
			mov   bl, 10
			mul   bl
			add   al, bh
			mov   wSec, ax
	 }
}

